import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HALO · Founding Wings",
  description: "Archangel Contractors Founding Wings operations console"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
