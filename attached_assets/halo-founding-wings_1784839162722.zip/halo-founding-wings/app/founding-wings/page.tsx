import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { FoundingWingsDashboard } from "@/components/founding-wings/dashboard";
import { getFoundingWingsDashboard } from "@/lib/founding-wings/services/dashboard-service";

export const dynamic = "force-dynamic";

export default async function FoundingWingsPage({
  searchParams
}: {
  searchParams: Promise<{ tenant?: string }>;
}) {
  const params = await searchParams;
  const slug = params.tenant || process.env.DEMO_TENANT_SLUG || "archangel-contractors";
  const tenant = await prisma.tenant.findUnique({ where: { slug } });
  if (!tenant) notFound();
  const data = await getFoundingWingsDashboard(tenant.id);
  return <FoundingWingsDashboard data={data} />;
}
