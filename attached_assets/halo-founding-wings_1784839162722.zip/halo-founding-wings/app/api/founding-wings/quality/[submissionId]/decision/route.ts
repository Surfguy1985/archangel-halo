import { ReviewStatus } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { assertHaloAdmin } from "@/lib/founding-wings/integrations/auth";
import { decideQualitySubmission } from "@/lib/founding-wings/services/quality-service";

const DecisionSchema = z.object({
  status: z.enum([ReviewStatus.PASS, ReviewStatus.NEEDS_REVIEW, ReviewStatus.FAIL]),
  reason: z.string().min(5).max(2000),
  finalScore: z.number().min(0).max(100).optional()
});

export async function POST(request: NextRequest, { params }: { params: Promise<{ submissionId: string }> }) {
  try {
    const context = await assertHaloAdmin(request);
    const { submissionId } = await params;
    const submission = await prisma.qualitySubmission.findUniqueOrThrow({ where: { id: submissionId }, include: { job: true } });
    if (submission.job.tenantId !== context.tenantId) throw new Error("FORBIDDEN");
    const body = DecisionSchema.parse(await request.json());
    return NextResponse.json(await decideQualitySubmission({ submissionId, actorId: context.userId, ...body }));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
