import { NextRequest, NextResponse } from "next/server";
import { assertHaloAdmin } from "@/lib/founding-wings/integrations/auth";
import { reviewQualitySubmission } from "@/lib/founding-wings/services/quality-service";
import { prisma } from "@/lib/db";

export const maxDuration = 120;

export async function POST(request: NextRequest, { params }: { params: Promise<{ submissionId: string }> }) {
  try {
    const context = await assertHaloAdmin(request);
    const { submissionId } = await params;
    const submission = await prisma.qualitySubmission.findUniqueOrThrow({ where: { id: submissionId }, include: { job: true } });
    if (submission.job.tenantId !== context.tenantId) throw new Error("FORBIDDEN");
    return NextResponse.json(await reviewQualitySubmission(submissionId));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
