import { NextRequest, NextResponse } from "next/server";
import { assertHaloAdmin } from "@/lib/founding-wings/integrations/auth";
import { processHaloEvent } from "@/lib/founding-wings/services/event-service";

export async function POST(request: NextRequest) {
  try {
    const context = await assertHaloAdmin(request);
    const body = await request.json();
    if (body.tenantId !== context.tenantId) throw new Error("FORBIDDEN");
    return NextResponse.json(await processHaloEvent(body));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
