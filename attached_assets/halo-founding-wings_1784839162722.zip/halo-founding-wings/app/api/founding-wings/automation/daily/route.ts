import { NextRequest, NextResponse } from "next/server";
import { assertHaloAdmin } from "@/lib/founding-wings/integrations/auth";
import { runDailyAutomation } from "@/lib/founding-wings/services/daily-automation";

export const maxDuration = 300;

export async function POST(request: NextRequest) {
  try {
    const context = await assertHaloAdmin(request);
    return NextResponse.json(await runDailyAutomation(context.tenantId));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 500 });
  }
}
