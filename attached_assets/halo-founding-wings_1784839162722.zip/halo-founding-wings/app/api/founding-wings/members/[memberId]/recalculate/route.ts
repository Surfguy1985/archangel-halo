import { AuditActorType } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";
import { assertHaloAdmin } from "@/lib/founding-wings/integrations/auth";
import { recalculateMemberScore } from "@/lib/founding-wings/services/member-service";
import { prisma } from "@/lib/db";

export async function POST(request: NextRequest, { params }: { params: Promise<{ memberId: string }> }) {
  try {
    const context = await assertHaloAdmin(request);
    const { memberId } = await params;
    const member = await prisma.crewMember.findUniqueOrThrow({ where: { id: memberId } });
    if (member.tenantId !== context.tenantId) throw new Error("FORBIDDEN");
    const result = await recalculateMemberScore(memberId, AuditActorType.ADMIN);
    return NextResponse.json(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
