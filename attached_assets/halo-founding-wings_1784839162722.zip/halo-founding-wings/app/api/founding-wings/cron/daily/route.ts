import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { assertCron } from "@/lib/founding-wings/integrations/auth";
import { runDailyAutomation } from "@/lib/founding-wings/services/daily-automation";

export const maxDuration = 300;

export async function GET(request: NextRequest) {
  try {
    assertCron(request);
    const tenants = await prisma.tenant.findMany({ select: { id: true, slug: true } });
    const results = [];
    for (const tenant of tenants) {
      try {
        results.push({ tenant: tenant.slug, ...(await runDailyAutomation(tenant.id)) });
      } catch (error) {
        results.push({ tenant: tenant.slug, status: "FAILED", error: error instanceof Error ? error.message : "Unknown error" });
      }
    }
    return NextResponse.json({ results });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 500 });
  }
}
