import { NextRequest, NextResponse } from "next/server";
import { assertHaloAdmin } from "@/lib/founding-wings/integrations/auth";
import { getFoundingWingsDashboard } from "@/lib/founding-wings/services/dashboard-service";

export async function GET(request: NextRequest) {
  try {
    const context = await assertHaloAdmin(request);
    return NextResponse.json(await getFoundingWingsDashboard(context.tenantId));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
