import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { assertHaloAdmin } from "@/lib/founding-wings/integrations/auth";
import { getProgramConfig, updateProgramConfig } from "@/lib/founding-wings/services/config-service";

const ConfigPatchSchema = z.record(z.string(), z.unknown());

export async function GET(request: NextRequest) {
  try {
    const context = await assertHaloAdmin(request);
    return NextResponse.json(await getProgramConfig(context.tenantId));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const context = await assertHaloAdmin(request);
    const patch = ConfigPatchSchema.parse(await request.json());
    return NextResponse.json(await updateProgramConfig(context.tenantId, patch));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
