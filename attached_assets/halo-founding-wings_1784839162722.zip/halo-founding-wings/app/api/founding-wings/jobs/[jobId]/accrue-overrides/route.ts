import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { assertHaloAdmin } from "@/lib/founding-wings/integrations/auth";
import { createJobOverrideAccruals } from "@/lib/founding-wings/services/override-service";

export async function POST(request: NextRequest, { params }: { params: Promise<{ jobId: string }> }) {
  try {
    const context = await assertHaloAdmin(request);
    const { jobId } = await params;
    const job = await prisma.job.findUniqueOrThrow({ where: { id: jobId } });
    if (job.tenantId !== context.tenantId) throw new Error("FORBIDDEN");
    return NextResponse.json({ accruals: await createJobOverrideAccruals(jobId) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: message === "UNAUTHORIZED" ? 401 : 400 });
  }
}
