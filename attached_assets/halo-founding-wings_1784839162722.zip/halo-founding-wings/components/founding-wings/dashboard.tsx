type DashboardData = Awaited<ReturnType<typeof import("@/lib/founding-wings/services/dashboard-service").getFoundingWingsDashboard>>;

function money(value: string) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(value));
}

function date(value: Date | string | null) {
  if (!value) return "Not scheduled";
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(new Date(value));
}

export function FoundingWingsDashboard({ data }: { data: DashboardData }) {
  const stats = [
    ["Active crew", data.stats.activeMembers],
    ["Founding Wings", data.stats.foundingMembers],
    ["Platinum", data.stats.platinumMembers],
    ["Quality queue", data.stats.pendingQuality],
    ["Guardian Reserve", money(data.stats.heldReserve)],
    ["Ready overrides", money(data.stats.readyOverrideAmount)]
  ];

  return (
    <main className="shell">
      <header className="hero">
        <div>
          <div className="eyebrow">Archangel Contractors · HALO CRM</div>
          <h1>Founding Wings</h1>
          <p>AI-operated quality, job priority, Wingline overrides, and Guardian Reserve accountability.</p>
        </div>
        <div className="badge">Build the company. Build your legacy.</div>
      </header>

      <section className="stats">
        {stats.map(([label, value]) => (
          <div className="card" key={String(label)}>
            <div className="stat-label">{label}</div>
            <div className="stat-value">{value}</div>
          </div>
        ))}
      </section>

      <section className="grid">
        <div className="card">
          <div className="section-head">
            <h2>Halo Leaderboard</h2>
            <span>Quality determines access</span>
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Member</th><th>Halo</th><th>Tier</th><th>Wingline</th><th>Reserve</th></tr></thead>
              <tbody>
                {data.members.map((member) => (
                  <tr key={member.id}>
                    <td>
                      <div className="name">{member.name}</div>
                      <div className="sub">{member.founderNumber ? `Founder #${member.founderNumber}` : member.founderStatus.replaceAll("_", " ")}</div>
                    </td>
                    <td><div className="score">{member.currentHaloScore.toFixed(1)}</div><div className="sub">{Math.round(member.scoreConfidence * 100)}% confidence</div></td>
                    <td><span className={`pill ${member.currentTier}`}>{member.currentTier}</span></td>
                    <td>{member.recruitCount} recruit{member.recruitCount === 1 ? "" : "s"}</td>
                    <td>{money(member.reserveAccount?.heldBalance ?? "0")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="stack">
          <div className="card">
            <div className="section-head"><h2>First Flight Jobs</h2><span>{data.jobs.length} active</span></div>
            {data.jobs.length === 0 && <div className="empty">No active jobs.</div>}
            {data.jobs.map((job) => (
              <div className="job" key={job.id}>
                <div className="job-line"><div><div className="job-title">{job.name}</div><div className="sub">{job.priority.replaceAll("_", " ")} · {job.status.replaceAll("_", " ")}</div></div><span className="pill">{date(job.startsAt)}</span></div>
                {job.eligibilityDecisions.map((decision, index) => (
                  <div className="candidate" key={`${job.id}-${index}`}><span>{decision.member.name} · {decision.member.currentHaloScore.toFixed(1)}</span><span>{decision.window.replaceAll("_", " ")}</span></div>
                ))}
              </div>
            ))}
          </div>

          <div className="card">
            <div className="section-head"><h2>AI Operations Log</h2><span>Auditable by design</span></div>
            {data.recentActivity.map((activity) => (
              <div className="activity" key={activity.id}>
                <strong>{activity.action.replaceAll("_", " ")}</strong>
                <p>{activity.reason || activity.entityType} · {date(activity.createdAt)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
