# HALO Founding Wings

A production-oriented Next.js/TypeScript module for Archangel Contractors' **Founding Wings** program.

It automates:

- Halo Score calculation and tiering
- First Flight premium-job eligibility and ranking
- Wingline direct-recruit overrides
- Guardian Reserve holds, quality adjustments, releases, and Quality Kickers
- AI review of before/during/after job evidence
- Daily score refreshes, quality queues, reserve settlements, and job matching
- Full audit logging and idempotent HALO event ingestion
- A dark-mode operations dashboard

## System principle

**AI interprets evidence and explains risk. Deterministic code decides scores, eligibility, and money.**

This makes every consequential decision reproducible and auditable. High-confidence clean quality submissions can auto-pass. Ambiguous, critical, or low-confidence cases are escalated instead of silently penalizing a crew member.

## Architecture

```text
HALO CRM events
   │
   ▼
/api/founding-wings/events ── idempotency receipt
   │
   ├── score engine ───────── Halo Score + tier snapshots
   ├── eligibility engine ─── First Flight windows + ranking
   ├── quality AI ─────────── photo/checklist review + escalation
   ├── override engine ────── 5% / 3% / 1% + quality multiplier
   ├── Guardian Reserve ───── 80% ready / 20% held / release or debit
   └── audit + notifications

Daily cron
   ├── refresh stale scores
   ├── review pending quality evidence
   ├── settle due reserves
   ├── evaluate open jobs
   └── produce AI operator brief
```

## Fast install into an existing HALO Next.js app

1. Copy these folders into HALO:

```text
app/api/founding-wings
app/founding-wings
components/founding-wings
lib/founding-wings
```

2. Merge the models and enums from `prisma/schema.prisma` into HALO's existing Prisma schema. If HALO already has Tenant, User, Job, Crew, Assignment, Incident, or Audit models, map the foreign keys rather than duplicating those core records.

3. Install dependencies:

```bash
npm install openai zod @prisma/client
npm install -D prisma vitest tsx
```

4. Set environment variables from `.env.example`.

5. Generate and migrate:

```bash
npx prisma generate
npx prisma migrate dev --name founding_wings
```

6. Seed the demo tenant:

```bash
npm run db:seed
```

7. Open:

```text
/founding-wings?tenant=archangel-contractors
```

## HALO authentication adapter

Replace `lib/founding-wings/integrations/auth.ts` with HALO's existing session and role checks. The included internal-header adapter is intentionally simple so the feature can run behind HALO's trusted backend immediately.

Required internal headers:

```text
x-halo-internal-secret
x-halo-tenant-id
x-halo-user-id
x-halo-role: ADMIN | MANAGER | SYSTEM
```

## Event ingestion

POST to `/api/founding-wings/events`.

### Assignment completed

```json
{
  "eventId": "evt_assignment_000001",
  "tenantId": "TENANT_ID",
  "type": "ASSIGNMENT_COMPLETED",
  "payload": {
    "assignmentId": "ASSIGNMENT_ID",
    "onTime": true,
    "attended": true,
    "communicationRating": 4.8,
    "professionalismRating": 5
  }
}
```

### Job completed

```json
{
  "eventId": "evt_job_000001",
  "tenantId": "TENANT_ID",
  "type": "JOB_COMPLETED",
  "payload": {
    "jobId": "JOB_ID",
    "completedAt": "2026-07-23T18:00:00.000Z"
  }
}
```

### Payment collected

```json
{
  "eventId": "evt_payment_000001",
  "tenantId": "TENANT_ID",
  "type": "PAYMENT_COLLECTED",
  "payload": {
    "jobId": "JOB_ID",
    "grossRevenue": 25000,
    "directCosts": 16000,
    "collectedAt": "2026-07-24T18:00:00.000Z"
  }
}
```

### Incident reported

```json
{
  "eventId": "evt_incident_000001",
  "tenantId": "TENANT_ID",
  "type": "INCIDENT_REPORTED",
  "payload": {
    "jobId": "JOB_ID",
    "memberId": "MEMBER_ID",
    "incidentType": "CALLBACK",
    "severity": 2,
    "description": "Kitchen cabinet fronts required a return visit.",
    "cost": 125
  }
}
```

Every `eventId` is unique per tenant. Retrying the same event is safe.

## Quality evidence submission

Create a `QualitySubmission` with before/during/after photo URLs and checklist data, then call:

```text
POST /api/founding-wings/quality/:submissionId/review
```

AI output is constrained to structured JSON and validated with Zod. `store: false` is used for the OpenAI request. Use signed, short-lived storage URLs and follow your own privacy/data-retention policies. Admin exceptions can be recorded through `POST /api/founding-wings/quality/:submissionId/decision`; every override is audited.

## Halo Score

The score is 100 points:

| Category | Points |
|---|---:|
| Quality | 35 |
| Reliability | 25 |
| Professionalism | 15 |
| Safety | 15 |
| Team contribution | 10 |

New members use a Bayesian prior so one job cannot create a misleading 100 or 0. The confidence score rises as the completed-job sample grows.

Default tiers:

| Tier | Score |
|---|---:|
| Platinum | 95–100 |
| Gold | 90–94.99 |
| Silver | 85–89.99 |
| Training | 75–84.99 |
| Grounded | Below 75 |

## First Flight eligibility

A member is eligible only when all required conditions pass:

- Active and available
- Not grounded
- Meets the job's minimum Halo Score
- Has required skills and active certifications
- Is below job-capacity limits
- Has no unresolved critical safety, damage, or customer incident

Eligible job windows:

1. Platinum Founding Wings
2. Gold Founding Wings
3. Remaining qualified Founding Wings
4. Open Flight for all other qualified crew

## Wingline override

Default direct-recruit rates:

- Months 0–17: 5% of allocated gross profit
- Months 18–35: 3%
- Month 36 onward: 1% Legacy Override

Quality multipliers:

- 95–100: 1.25×
- 90–94.99: 1.10×
- 85–89.99: 1.00×
- 75–84.99: 0.50×
- Below 75: 0×

Gross profit is allocated across completed sponsored assignments using `profitShareWeight`; the same job profit is never counted in full for every recruit.

## Guardian Reserve

- 80% of the calculated override becomes READY.
- 20% enters the Guardian Reserve.
- After the job's quality window, unresolved callbacks/rework/damage block release.
- Verified corrective-work cost can debit no more than that job's reserve.
- Clean jobs release the reserve and add the configurable Quality Kicker.

No reserve account can become negative.

## Daily automation

`vercel.json` calls the secured route once daily:

```text
GET /api/founding-wings/cron/daily
Authorization: Bearer CRON_SECRET
```

The supplied schedule is `0 11 * * *` (11:00 UTC). Adjust it for your operating schedule. Vercel cron schedules use UTC.

## Payments

The module intentionally creates ledger states (`READY`, `HELD`, `AVAILABLE`, `ADJUSTED`, `PAID`) rather than directly moving cash. Connect `lib/founding-wings/integrations/payments.ts` to HALO's payroll, ACH, contractor-pay, or Stripe Connect flow.

Recommended approval policy:

- Auto-export ordinary READY payouts below a configured threshold.
- Require an admin approval for unusually large payouts, manual adjustments, or exceptions.
- Never edit an accrual silently; create an audit entry and adjustment ledger transaction.

## Production hardening checklist

- Replace the header auth adapter with HALO RBAC.
- Use signed photo URLs and malware-safe upload handling.
- Add database row-level tenant protections if your Postgres architecture supports them.
- Connect the ledger adapter and payout reconciliation.
- Connect HALO's human review screen to `POST /api/founding-wings/quality/:submissionId/decision`.
- Add notification channels: push, SMS, email, WhatsApp, or in-app.
- Run legal/CPA review of worker classification, wage deductions, bonus language, tax reporting, and the final Founding Wings agreement.
- Calibrate score thresholds on real Archangel data before allowing automatic suspension or loss of work access.

## Core tests

```bash
npm test
```

Included test coverage:

- Halo Score quality and confidence behavior
- Premium-job eligibility and missing requirements
- 5% / 3% / 1% override behavior
- Quality multipliers
- Guardian Reserve release, bonus, and capped rework debit

## Important files

```text
lib/founding-wings/core/score-engine.ts
lib/founding-wings/core/eligibility-engine.ts
lib/founding-wings/core/override-engine.ts
lib/founding-wings/core/guardian-reserve.ts
lib/founding-wings/ai/quality-reviewer.ts
lib/founding-wings/services/daily-automation.ts
lib/founding-wings/services/event-service.ts
prisma/schema.prisma
```


## Runtime configuration API

```text
GET   /api/founding-wings/config
PATCH /api/founding-wings/config
```

The PATCH body can contain a partial nested configuration. HALO merges it with the active rules and increments the configuration version.
