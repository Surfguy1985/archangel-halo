export interface ReadyPayout {
  accrualId: string;
  memberId: string;
  amount: string;
  memo: string;
}

/**
 * Connect this to HALO's ledger, Stripe Connect, ACH, payroll, or contractor-pay system.
 * The Founding Wings module creates auditable READY ledger entries; it never silently moves cash.
 */
export async function sendReadyPayoutsToHaloLedger(payouts: ReadyPayout[]): Promise<void> {
  if (!payouts.length) return;
  const endpoint = process.env.HALO_LEDGER_WEBHOOK_URL;
  if (!endpoint) return;

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${process.env.HALO_LEDGER_WEBHOOK_SECRET || ""}`
    },
    body: JSON.stringify({ source: "FOUNDING_WINGS", payouts })
  });

  if (!response.ok) throw new Error(`HALO ledger webhook failed with ${response.status}.`);
}
