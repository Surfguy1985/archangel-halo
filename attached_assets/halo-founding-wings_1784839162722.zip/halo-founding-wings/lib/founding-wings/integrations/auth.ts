import type { NextRequest } from "next/server";

export interface HaloRequestContext {
  tenantId: string;
  userId: string;
  role: "ADMIN" | "MANAGER" | "SYSTEM";
}

/**
 * Replace this adapter with HALO's existing session/RBAC implementation.
 * The header fallback lets the module run immediately behind a trusted internal gateway.
 */
export async function assertHaloAdmin(request: NextRequest): Promise<HaloRequestContext> {
  const secret = request.headers.get("x-halo-internal-secret");
  if (!process.env.HALO_INTERNAL_API_SECRET || secret !== process.env.HALO_INTERNAL_API_SECRET) {
    throw new Error("UNAUTHORIZED");
  }

  const tenantId = request.headers.get("x-halo-tenant-id");
  const userId = request.headers.get("x-halo-user-id") || "system";
  const role = (request.headers.get("x-halo-role") || "SYSTEM") as HaloRequestContext["role"];
  if (!tenantId) throw new Error("TENANT_REQUIRED");
  if (!new Set(["ADMIN", "MANAGER", "SYSTEM"]).has(role)) throw new Error("FORBIDDEN");

  return { tenantId, userId, role };
}

export function assertCron(request: NextRequest): void {
  const authorization = request.headers.get("authorization");
  if (!process.env.CRON_SECRET || authorization !== `Bearer ${process.env.CRON_SECRET}`) {
    throw new Error("UNAUTHORIZED");
  }
}
