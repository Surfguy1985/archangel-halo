import { AssignmentStatus, AuditActorType, OverrideStatus, PayoutStatus, ReserveTransactionType, ReviewStatus } from "@prisma/client";
import { prisma } from "@/lib/db";
import { calculateOverride } from "../core/override-engine";
import { centsToDecimal, decimalToCents, monthsBetween } from "../core/math";
import { getProgramConfig } from "./config-service";

export async function createJobOverrideAccruals(jobId: string) {
  const job = await prisma.job.findUniqueOrThrow({
    where: { id: jobId },
    include: {
      assignments: {
        where: { status: AssignmentStatus.COMPLETE },
        include: { member: true }
      },
      qualitySubmissions: {
        include: { review: true },
        orderBy: { submittedAt: "desc" },
        take: 1
      }
    }
  });

  if (!job.collectedAt || job.grossProfit == null) throw new Error("Overrides require collected payment and gross profit.");
  if (job.qualitySubmissions[0]?.review?.status !== ReviewStatus.PASS) throw new Error("Overrides require a passed quality review.");

  const config = await getProgramConfig(job.tenantId);
  const grossProfitCents = decimalToCents(job.grossProfit.toString());
  if (grossProfitCents < config.overrides.minimumGrossProfitCents) return [];

  const sponsoredAssignments = job.assignments.filter((assignment) => assignment.member.sponsorId);
  const totalWeight = job.assignments.reduce((sum, assignment) => sum + Math.max(0, assignment.profitShareWeight), 0);
  if (totalWeight <= 0) return [];

  const created = [];
  for (const assignment of sponsoredAssignments) {
    const recruit = assignment.member;
    const sponsorId = recruit.sponsorId;
    if (!sponsorId) continue;

    const allocatedGrossProfitCents = Math.round(
      grossProfitCents * (Math.max(0, assignment.profitShareWeight) / totalWeight)
    );
    const relationshipMonths = monthsBetween(recruit.sponsorSince ?? recruit.joinedAt, job.collectedAt);
    const override = calculateOverride(
      {
        allocatedGrossProfitCents,
        sponsorRelationshipMonths: relationshipMonths,
        recruitHaloScore: recruit.currentHaloScore,
        reservePercent: config.overrides.reservePercent
      },
      config
    );
    if (override.grossOverrideCents <= 0) continue;

    const qualityWindowEndsAt = new Date(
      job.collectedAt.getTime() + job.qualityWindowDays * 24 * 60 * 60 * 1000
    );

    const accrual = await prisma.$transaction(async (tx) => {
      const existing = await tx.overrideAccrual.findUnique({
        where: { jobId_sponsorId_recruitId: { jobId, sponsorId, recruitId: recruit.id } }
      });
      if (existing) return existing;

      const account = await tx.guardianReserveAccount.upsert({
        where: { memberId: sponsorId },
        update: { heldBalance: { increment: centsToDecimal(override.reserveAmountCents) } },
        create: {
          tenantId: job.tenantId,
          memberId: sponsorId,
          heldBalance: centsToDecimal(override.reserveAmountCents)
        }
      });

      const record = await tx.overrideAccrual.create({
        data: {
          tenantId: job.tenantId,
          jobId,
          sponsorId,
          recruitId: recruit.id,
          allocatedGrossProfit: centsToDecimal(allocatedGrossProfitCents),
          baseRate: override.baseRate,
          qualityMultiplier: override.qualityMultiplier,
          grossOverride: centsToDecimal(override.grossOverrideCents),
          immediateAmount: centsToDecimal(override.immediateAmountCents),
          reserveAmount: centsToDecimal(override.reserveAmountCents),
          status: OverrideStatus.HELD,
          immediateStatus: PayoutStatus.READY,
          qualityWindowEndsAt
        }
      });

      await tx.guardianReserveTransaction.create({
        data: {
          tenantId: job.tenantId,
          accountId: account.id,
          memberId: sponsorId,
          overrideAccrualId: record.id,
          type: ReserveTransactionType.HOLD,
          amount: centsToDecimal(override.reserveAmountCents),
          balanceAfter: account.heldBalance,
          note: `Guardian Reserve hold for ${job.name}.`
        }
      });

      await tx.notification.create({
        data: {
          tenantId: job.tenantId,
          memberId: sponsorId,
          type: "OVERRIDE_EARNED",
          title: "Wingline override earned",
          body: `$${centsToDecimal(override.immediateAmountCents)} is ready and $${centsToDecimal(override.reserveAmountCents)} entered Guardian Reserve.`,
          data: { jobId, recruitId: recruit.id, overrideAccrualId: record.id }
        }
      });

      await tx.auditLog.create({
        data: {
          tenantId: job.tenantId,
          actorType: AuditActorType.SYSTEM,
          action: "OVERRIDE_ACCRUED",
          entityType: "OverrideAccrual",
          entityId: record.id,
          after: {
            baseRate: override.baseRate,
            qualityMultiplier: override.qualityMultiplier,
            grossOverrideCents: override.grossOverrideCents,
            immediateAmountCents: override.immediateAmountCents,
            reserveAmountCents: override.reserveAmountCents
          },
          reason: "Completed, collected, quality-approved recruit work."
        }
      });

      return record;
    });

    created.push(accrual);
  }

  return created;
}
