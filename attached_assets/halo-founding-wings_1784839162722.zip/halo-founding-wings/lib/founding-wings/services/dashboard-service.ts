import { prisma } from "@/lib/db";

export async function getFoundingWingsDashboard(tenantId: string) {
  const [members, jobs, pendingQuality, reserveTotals, readyOverrides, recentActivity] = await Promise.all([
    prisma.crewMember.findMany({
      where: { tenantId, status: "ACTIVE" },
      select: {
        id: true,
        name: true,
        founderNumber: true,
        founderStatus: true,
        currentHaloScore: true,
        currentTier: true,
        scoreConfidence: true,
        draftTokens: true,
        recruits: { where: { status: "ACTIVE" }, select: { id: true } },
        reserveAccount: { select: { heldBalance: true, releasedBalance: true, debitedBalance: true } }
      },
      orderBy: [{ currentHaloScore: "desc" }, { name: "asc" }],
      take: 100
    }),
    prisma.job.findMany({
      where: { tenantId, status: { in: ["OPEN", "ASSIGNED", "IN_PROGRESS", "QUALITY_REVIEW"] } },
      select: {
        id: true,
        name: true,
        priority: true,
        status: true,
        requiredHaloScore: true,
        startsAt: true,
        dueAt: true,
        eligibilityDecisions: {
          where: { eligible: true },
          orderBy: { rankScore: "desc" },
          take: 3,
          select: { rankScore: true, window: true, member: { select: { name: true, currentHaloScore: true } } }
        }
      },
      orderBy: [{ priority: "desc" }, { startsAt: "asc" }],
      take: 50
    }),
    prisma.qualitySubmission.count({ where: { job: { tenantId }, reviewStatus: { in: ["PENDING", "NEEDS_REVIEW"] } } }),
    prisma.guardianReserveAccount.aggregate({
      where: { tenantId },
      _sum: { heldBalance: true, releasedBalance: true, debitedBalance: true }
    }),
    prisma.overrideAccrual.aggregate({
      where: { tenantId, immediateStatus: "READY" },
      _sum: { immediateAmount: true },
      _count: true
    }),
    prisma.auditLog.findMany({
      where: { tenantId },
      orderBy: { createdAt: "desc" },
      take: 12,
      select: { id: true, action: true, entityType: true, reason: true, createdAt: true, actorType: true }
    })
  ]);

  return {
    stats: {
      activeMembers: members.length,
      foundingMembers: members.filter((member) => member.founderStatus !== "NONE").length,
      platinumMembers: members.filter((member) => member.currentTier === "PLATINUM").length,
      pendingQuality,
      heldReserve: reserveTotals._sum.heldBalance?.toString() ?? "0.00",
      releasedReserve: reserveTotals._sum.releasedBalance?.toString() ?? "0.00",
      readyOverrideCount: readyOverrides._count,
      readyOverrideAmount: readyOverrides._sum.immediateAmount?.toString() ?? "0.00"
    },
    members: members.map((member) => ({
      ...member,
      recruitCount: member.recruits.length,
      recruits: undefined,
      reserveAccount: member.reserveAccount
        ? {
            heldBalance: member.reserveAccount.heldBalance.toString(),
            releasedBalance: member.reserveAccount.releasedBalance.toString(),
            debitedBalance: member.reserveAccount.debitedBalance.toString()
          }
        : null
    })),
    jobs,
    recentActivity
  };
}
