import { AssignmentStatus, IncidentType, JobStatus } from "@prisma/client";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { createJobOverrideAccruals } from "./override-service";
import { recalculateMemberScore } from "./member-service";

const EventSchema = z.discriminatedUnion("type", [
  z.object({
    eventId: z.string().min(8),
    tenantId: z.string().min(1),
    type: z.literal("JOB_COMPLETED"),
    payload: z.object({ jobId: z.string(), completedAt: z.string().datetime().optional() })
  }),
  z.object({
    eventId: z.string().min(8),
    tenantId: z.string().min(1),
    type: z.literal("PAYMENT_COLLECTED"),
    payload: z.object({
      jobId: z.string(),
      grossRevenue: z.number().nonnegative(),
      directCosts: z.number().nonnegative(),
      collectedAt: z.string().datetime().optional()
    })
  }),
  z.object({
    eventId: z.string().min(8),
    tenantId: z.string().min(1),
    type: z.literal("INCIDENT_REPORTED"),
    payload: z.object({
      jobId: z.string().optional(),
      memberId: z.string().optional(),
      incidentType: z.nativeEnum(IncidentType),
      severity: z.number().int().min(1).max(5),
      description: z.string().min(1),
      cost: z.number().nonnegative().optional()
    })
  }),
  z.object({
    eventId: z.string().min(8),
    tenantId: z.string().min(1),
    type: z.literal("ASSIGNMENT_COMPLETED"),
    payload: z.object({
      assignmentId: z.string(),
      onTime: z.boolean(),
      attended: z.boolean(),
      communicationRating: z.number().min(0).max(5),
      professionalismRating: z.number().min(0).max(5)
    })
  })
]);

export async function processHaloEvent(raw: unknown) {
  const event = EventSchema.parse(raw);
  const existing = await prisma.eventReceipt.findUnique({
    where: { tenantId_eventId: { tenantId: event.tenantId, eventId: event.eventId } }
  });
  if (existing) return { duplicate: true, receiptId: existing.id };

  const result = await prisma.$transaction(async (tx) => {
    const receipt = await tx.eventReceipt.create({
      data: { tenantId: event.tenantId, eventId: event.eventId, eventType: event.type, payload: event as object }
    });

    if (event.type === "JOB_COMPLETED") {
      await tx.job.update({
        where: { id: event.payload.jobId },
        data: { status: JobStatus.QUALITY_REVIEW, completedAt: event.payload.completedAt ? new Date(event.payload.completedAt) : new Date() }
      });
    }

    if (event.type === "PAYMENT_COLLECTED") {
      await tx.job.update({
        where: { id: event.payload.jobId },
        data: {
          grossRevenue: event.payload.grossRevenue.toFixed(2),
          directCosts: event.payload.directCosts.toFixed(2),
          grossProfit: (event.payload.grossRevenue - event.payload.directCosts).toFixed(2),
          collectedAt: event.payload.collectedAt ? new Date(event.payload.collectedAt) : new Date()
        }
      });
    }

    if (event.type === "INCIDENT_REPORTED") {
      await tx.incident.create({
        data: {
          tenantId: event.tenantId,
          jobId: event.payload.jobId,
          memberId: event.payload.memberId,
          type: event.payload.incidentType,
          severity: event.payload.severity,
          description: event.payload.description,
          cost: event.payload.cost?.toFixed(2)
        }
      });
    }

    if (event.type === "ASSIGNMENT_COMPLETED") {
      await tx.assignment.update({
        where: { id: event.payload.assignmentId },
        data: {
          status: AssignmentStatus.COMPLETE,
          completedAt: new Date(),
          onTime: event.payload.onTime,
          attended: event.payload.attended,
          communicationRating: event.payload.communicationRating,
          professionalismRating: event.payload.professionalismRating
        }
      });
    }

    return receipt;
  });

  if (event.type === "PAYMENT_COLLECTED") {
    try {
      await createJobOverrideAccruals(event.payload.jobId);
    } catch (error) {
      // Quality may not be approved yet. The daily automation or quality approval flow can retry safely.
      if (!(error instanceof Error) || !error.message.includes("quality review")) throw error;
    }
  }

  if (event.type === "ASSIGNMENT_COMPLETED") {
    const assignment = await prisma.assignment.findUniqueOrThrow({ where: { id: event.payload.assignmentId } });
    await recalculateMemberScore(assignment.memberId);
  }

  if (event.type === "INCIDENT_REPORTED" && event.payload.memberId) {
    await recalculateMemberScore(event.payload.memberId);
  }

  return { duplicate: false, receiptId: result.id };
}
