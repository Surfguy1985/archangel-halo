import { prisma } from "@/lib/db";
import { DEFAULT_CONFIG, mergeConfig, validateConfig, type FoundingWingsConfig } from "../config";

export async function getProgramConfig(tenantId: string): Promise<FoundingWingsConfig> {
  const record = await prisma.programConfig.findUnique({ where: { tenantId } });
  return mergeConfig(DEFAULT_CONFIG, record?.config);
}

export async function ensureProgramConfig(tenantId: string): Promise<FoundingWingsConfig> {
  await prisma.programConfig.upsert({
    where: { tenantId },
    update: {},
    create: { tenantId, config: DEFAULT_CONFIG as object }
  });
  return getProgramConfig(tenantId);
}


export async function updateProgramConfig(tenantId: string, patch: unknown): Promise<FoundingWingsConfig> {
  const current = await getProgramConfig(tenantId);
  const next = validateConfig(mergeConfig(current, patch));
  await prisma.programConfig.upsert({
    where: { tenantId },
    update: { config: next as object, version: { increment: 1 } },
    create: { tenantId, config: next as object }
  });
  return next;
}
