import { AssignmentStatus, AuditActorType, IncidentType, JobStatus } from "@prisma/client";
import { prisma } from "@/lib/db";
import { evaluateEligibility } from "../core/eligibility-engine";
import type { CertificationRecord } from "../core/types";
import { getProgramConfig } from "./config-service";

export async function evaluateMemberForJob(jobId: string, memberId: string) {
  const [job, member] = await Promise.all([
    prisma.job.findUniqueOrThrow({ where: { id: jobId } }),
    prisma.crewMember.findUniqueOrThrow({ where: { id: memberId } })
  ]);

  if (job.tenantId !== member.tenantId) throw new Error("Cross-tenant eligibility evaluation blocked.");
  if (![JobStatus.OPEN, JobStatus.ASSIGNED, JobStatus.DRAFT].includes(job.status)) {
    throw new Error(`Job ${jobId} is not open for eligibility evaluation.`);
  }

  const config = await getProgramConfig(job.tenantId);
  const [activeJobCount, unresolvedCriticalIncidentCount] = await Promise.all([
    prisma.assignment.count({
      where: {
        memberId,
        status: { in: [AssignmentStatus.ACCEPTED, AssignmentStatus.IN_PROGRESS, AssignmentStatus.SUBMITTED] }
      }
    }),
    prisma.incident.count({
      where: {
        memberId,
        resolvedAt: null,
        severity: { gte: config.eligibility.criticalIncidentSeverity },
        type: { in: [IncidentType.SAFETY, IncidentType.DAMAGE, IncidentType.CUSTOMER_COMPLAINT] }
      }
    })
  ]);

  const result = evaluateEligibility(
    {
      status: member.status,
      founderStatus: member.founderStatus,
      haloScore: member.currentHaloScore,
      tier: member.currentTier,
      tradeSkills: member.tradeSkills,
      certifications: (member.certifications ?? []) as unknown as CertificationRecord[],
      activeJobCount,
      maxConcurrentJobs: member.maxConcurrentJobs,
      isAvailable: member.isAvailable,
      unresolvedCriticalIncidentCount,
      draftTokens: member.draftTokens
    },
    {
      requiredHaloScore: job.requiredHaloScore,
      requiredSkills: job.requiredSkills,
      requiredCertifications: job.requiredCertifications,
      priority: job.priority
    }
  );

  const expiresAt = new Date(Date.now() + config.eligibility.decisionTtlHours * 60 * 60 * 1000);
  return prisma.eligibilityDecision.upsert({
    where: { jobId_memberId: { jobId, memberId } },
    update: {
      eligible: result.eligible,
      window: result.window,
      rankScore: result.rankScore,
      reasons: result.reasons,
      missingRequirements: result.missingRequirements,
      decidedBy: AuditActorType.SYSTEM,
      decidedAt: new Date(),
      expiresAt
    },
    create: {
      tenantId: job.tenantId,
      jobId,
      memberId,
      eligible: result.eligible,
      window: result.window,
      rankScore: result.rankScore,
      reasons: result.reasons,
      missingRequirements: result.missingRequirements,
      decidedBy: AuditActorType.SYSTEM,
      expiresAt
    }
  });
}

export async function evaluateAllMembersForJob(jobId: string) {
  const job = await prisma.job.findUniqueOrThrow({ where: { id: jobId } });
  const members = await prisma.crewMember.findMany({
    where: { tenantId: job.tenantId, status: "ACTIVE" },
    select: { id: true }
  });

  const decisions = [];
  for (const member of members) decisions.push(await evaluateMemberForJob(jobId, member.id));

  return decisions.sort((left, right) => {
    if (left.eligible !== right.eligible) return left.eligible ? -1 : 1;
    return right.rankScore - left.rankScore;
  });
}
