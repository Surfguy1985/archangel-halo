import { AutomationStatus } from "@prisma/client";
import { prisma } from "@/lib/db";
import { createOperatorBrief } from "../ai/operator";
import { getProgramConfig } from "./config-service";
import { evaluateAllMembersForJob } from "./eligibility-service";
import { settleDueGuardianReserves } from "./guardian-reserve-service";
import { recalculateMemberScore } from "./member-service";
import { reviewQualitySubmission } from "./quality-service";
import { createJobOverrideAccruals } from "./override-service";

export async function runDailyAutomation(tenantId: string) {
  const run = await prisma.automationRun.create({
    data: { tenantId, kind: "DAILY_FOUNDING_WINGS", status: AutomationStatus.RUNNING }
  });
  const config = await getProgramConfig(tenantId);
  const result: Record<string, unknown> = {};
  let actionsRun = 0;

  try {
    const staleBefore = new Date(Date.now() - config.score.staleAfterHours * 60 * 60 * 1000);
    const members = await prisma.crewMember.findMany({
      where: {
        tenantId,
        status: "ACTIVE",
        OR: [{ scoreUpdatedAt: null }, { scoreUpdatedAt: { lt: staleBefore } }]
      },
      select: { id: true },
      take: config.automation.maxMembersPerRun
    });
    for (const member of members) {
      await recalculateMemberScore(member.id);
      actionsRun += 1;
    }
    result.scoreRefreshes = members.length;

    const pending = await prisma.qualitySubmission.findMany({
      where: { job: { tenantId }, reviewStatus: "PENDING" },
      select: { id: true },
      orderBy: { submittedAt: "asc" },
      take: config.automation.maxQualityReviewsPerRun
    });
    if (process.env.FOUNDING_WINGS_AI_ENABLED !== "false") {
      for (const submission of pending) {
        await reviewQualitySubmission(submission.id);
        actionsRun += 1;
      }
    }
    result.qualityReviews = process.env.FOUNDING_WINGS_AI_ENABLED !== "false" ? pending.length : 0;

    const overrideReadyJobs = await prisma.job.findMany({
      where: {
        tenantId,
        collectedAt: { not: null },
        grossProfit: { not: null },
        qualitySubmissions: { some: { review: { status: "PASS" } } }
      },
      select: { id: true },
      take: config.automation.maxJobsPerRun
    });
    let overrideJobsProcessed = 0;
    for (const job of overrideReadyJobs) {
      await createJobOverrideAccruals(job.id);
      overrideJobsProcessed += 1;
      actionsRun += 1;
    }
    result.overrideJobsProcessed = overrideJobsProcessed;

    const reserveSettlements = await settleDueGuardianReserves(tenantId);
    actionsRun += reserveSettlements.length;
    result.reserveSettlements = reserveSettlements;

    const jobs = await prisma.job.findMany({
      where: { tenantId, status: "OPEN" },
      select: { id: true },
      take: config.automation.maxJobsPerRun
    });
    for (const job of jobs) {
      await evaluateAllMembersForJob(job.id);
      actionsRun += 1;
    }
    result.jobsEvaluated = jobs.length;

    if (
      config.automation.enableAiOperator &&
      process.env.FOUNDING_WINGS_AI_ENABLED !== "false" &&
      process.env.OPENAI_API_KEY
    ) {
      result.operatorBrief = await createOperatorBrief(tenantId);
      actionsRun += 1;
    }

    await prisma.automationRun.update({
      where: { id: run.id },
      data: {
        status: AutomationStatus.SUCCEEDED,
        completedAt: new Date(),
        actionsPlanned: members.length + pending.length + overrideReadyJobs.length + reserveSettlements.length + jobs.length + 1,
        actionsRun,
        result: result as object
      }
    });

    return { runId: run.id, status: "SUCCEEDED", actionsRun, result };
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown automation error";
    await prisma.automationRun.update({
      where: { id: run.id },
      data: {
        status: actionsRun > 0 ? AutomationStatus.PARTIAL : AutomationStatus.FAILED,
        completedAt: new Date(),
        actionsRun,
        result: result as object,
        error: message
      }
    });
    throw error;
  }
}
