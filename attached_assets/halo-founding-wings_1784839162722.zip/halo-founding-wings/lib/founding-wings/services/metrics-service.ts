import { AssignmentStatus, IncidentType, JobPriority } from "@prisma/client";
import { prisma } from "@/lib/db";
import type { ScoreInput } from "../core/types";

export async function buildScoreInput(memberId: string, lookbackDays: number): Promise<ScoreInput> {
  const since = new Date(Date.now() - lookbackDays * 24 * 60 * 60 * 1000);

  const [assignments, incidents, activeQualityRecruitCount] = await Promise.all([
    prisma.assignment.findMany({
      where: {
        memberId,
        createdAt: { gte: since },
        status: { in: [AssignmentStatus.ACCEPTED, AssignmentStatus.IN_PROGRESS, AssignmentStatus.SUBMITTED, AssignmentStatus.COMPLETE] }
      },
      include: {
        job: {
          include: {
            qualitySubmissions: {
              include: { review: true },
              orderBy: { submittedAt: "desc" },
              take: 1
            }
          }
        }
      }
    }),
    prisma.incident.findMany({
      where: { memberId, occurredAt: { gte: since } }
    }),
    prisma.crewMember.count({
      where: {
        sponsorId: memberId,
        status: "ACTIVE",
        currentHaloScore: { gte: 85 }
      }
    })
  ]);

  const completed = assignments.filter((assignment) => assignment.status === AssignmentStatus.COMPLETE);
  const reviews = completed
    .map((assignment) => assignment.job.qualitySubmissions[0]?.review)
    .filter((review): review is NonNullable<typeof review> => Boolean(review));

  return {
    inspectionScores: reviews.map((review) => review.finalScore),
    customerRatings: completed.map((assignment) => assignment.job.customerRating).filter((value): value is number => value != null),
    callbackCount: incidents.filter((incident) => incident.type === IncidentType.CALLBACK || incident.type === IncidentType.REWORK).length,
    damageCount: incidents.filter((incident) => incident.type === IncidentType.DAMAGE).length,
    completedJobCount: completed.length,
    acceptedAssignmentCount: assignments.length,
    onTimeCount: assignments.filter((assignment) => assignment.onTime === true).length,
    onTimeMeasuredCount: assignments.filter((assignment) => assignment.onTime != null).length,
    attendedCount: assignments.filter((assignment) => assignment.attended === true).length,
    attendanceMeasuredCount: assignments.filter((assignment) => assignment.attended != null).length,
    communicationRatings: assignments.map((assignment) => assignment.communicationRating).filter((value): value is number => value != null),
    professionalismRatings: assignments.map((assignment) => assignment.professionalismRating).filter((value): value is number => value != null),
    safetyScores: reviews.map((review) => review.safetyScore),
    safetyIncidentCount: incidents.filter((incident) => incident.type === IncidentType.SAFETY).length,
    activeQualityRecruitCount,
    completedRescueMissionCount: completed.filter((assignment) => assignment.job.priority === JobPriority.SAVE_THE_MISSION).length
  };
}
