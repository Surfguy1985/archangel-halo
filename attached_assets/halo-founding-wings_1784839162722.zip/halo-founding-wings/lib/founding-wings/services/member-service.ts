import { AuditActorType } from "@prisma/client";
import { prisma } from "@/lib/db";
import { calculateHaloScore } from "../core/score-engine";
import { getProgramConfig } from "./config-service";
import { buildScoreInput } from "./metrics-service";

export async function recalculateMemberScore(
  memberId: string,
  actorType: AuditActorType = AuditActorType.SYSTEM
) {
  const member = await prisma.crewMember.findUniqueOrThrow({ where: { id: memberId } });
  const config = await getProgramConfig(member.tenantId);
  const scoreInput = await buildScoreInput(memberId, config.score.lookbackDays);
  const result = calculateHaloScore(scoreInput, config);

  return prisma.$transaction(async (tx) => {
    const updated = await tx.crewMember.update({
      where: { id: memberId },
      data: {
        currentHaloScore: result.totalScore,
        currentTier: result.tier,
        scoreConfidence: result.confidence,
        scoreUpdatedAt: new Date()
      }
    });

    await tx.haloScoreSnapshot.create({
      data: {
        tenantId: member.tenantId,
        memberId,
        totalScore: result.totalScore,
        tier: result.tier,
        confidence: result.confidence,
        qualityPoints: result.points.quality,
        reliabilityPoints: result.points.reliability,
        professionalismPoints: result.points.professionalism,
        safetyPoints: result.points.safety,
        teamPoints: result.points.team,
        sampleSize: result.sampleSize,
        reasons: result.reasons
      }
    });

    await tx.auditLog.create({
      data: {
        tenantId: member.tenantId,
        actorType,
        action: "HALO_SCORE_RECALCULATED",
        entityType: "CrewMember",
        entityId: memberId,
        before: {
          score: member.currentHaloScore,
          tier: member.currentTier,
          confidence: member.scoreConfidence
        },
        after: {
          score: result.totalScore,
          tier: result.tier,
          confidence: result.confidence,
          points: result.points
        },
        reason: result.reasons.join(" ") || "Scheduled score refresh."
      }
    });

    if (member.currentTier !== result.tier) {
      await tx.notification.create({
        data: {
          tenantId: member.tenantId,
          memberId,
          type: "TIER_CHANGED",
          title: `Halo status updated: ${result.tier}`,
          body: `Your Halo Score is now ${result.totalScore.toFixed(1)}.`,
          data: { previousTier: member.currentTier, newTier: result.tier, score: result.totalScore }
        }
      });
    }

    return { member: updated, result };
  });
}
