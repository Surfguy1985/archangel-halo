import { AuditActorType, IncidentType, OverrideStatus, ReserveTransactionType } from "@prisma/client";
import { prisma } from "@/lib/db";
import { settleGuardianReserve } from "../core/guardian-reserve";
import { centsToDecimal, decimalToCents } from "../core/math";
import { getProgramConfig } from "./config-service";

export async function settleDueGuardianReserves(tenantId: string, now = new Date()) {
  const config = await getProgramConfig(tenantId);
  const due = await prisma.overrideAccrual.findMany({
    where: {
      tenantId,
      status: OverrideStatus.HELD,
      qualityWindowEndsAt: { lte: now }
    },
    include: {
      job: { include: { incidents: true } },
      sponsor: true
    },
    orderBy: { qualityWindowEndsAt: "asc" }
  });

  const results = [];
  for (const accrual of due) {
    const unresolved = accrual.job.incidents.filter((incident) =>
      [IncidentType.CALLBACK, IncidentType.REWORK, IncidentType.DAMAGE, IncidentType.CUSTOMER_COMPLAINT].includes(incident.type) &&
      !incident.resolvedAt
    );
    if (unresolved.length) {
      results.push({ accrualId: accrual.id, status: "WAITING_ON_INCIDENT_RESOLUTION" });
      continue;
    }

    const eligibleReworkCostCents = accrual.job.incidents
      .filter((incident) =>
        incident.memberId === accrual.recruitId &&
        [IncidentType.CALLBACK, IncidentType.REWORK, IncidentType.DAMAGE].includes(incident.type)
      )
      .reduce((sum, incident) => sum + (incident.cost ? decimalToCents(incident.cost.toString()) : 0), 0);

    const settlement = settleGuardianReserve({
      reserveAmountCents: decimalToCents(accrual.reserveAmount.toString()),
      eligibleReworkCostCents,
      qualityBonusPercent: config.overrides.qualityBonusPercentOfReserve
    });

    const result = await prisma.$transaction(async (tx) => {
      const account = await tx.guardianReserveAccount.findUniqueOrThrow({ where: { memberId: accrual.sponsorId } });
      const currentHeldCents = decimalToCents(account.heldBalance.toString());
      const nextHeldCents = Math.max(0, currentHeldCents - decimalToCents(accrual.reserveAmount.toString()));
      const nextReleasedCents = decimalToCents(account.releasedBalance.toString()) + settlement.totalAvailableCents;
      const nextDebitedCents = decimalToCents(account.debitedBalance.toString()) + settlement.debitCents;

      const updatedAccount = await tx.guardianReserveAccount.update({
        where: { id: account.id },
        data: {
          heldBalance: centsToDecimal(nextHeldCents),
          releasedBalance: centsToDecimal(nextReleasedCents),
          debitedBalance: centsToDecimal(nextDebitedCents)
        }
      });

      if (settlement.debitCents > 0) {
        await tx.guardianReserveTransaction.create({
          data: {
            tenantId,
            accountId: account.id,
            memberId: accrual.sponsorId,
            overrideAccrualId: accrual.id,
            type: ReserveTransactionType.REWORK_DEBIT,
            amount: centsToDecimal(-settlement.debitCents),
            balanceAfter: updatedAccount.heldBalance,
            note: "Guardian Reserve quality adjustment for verified corrective work."
          }
        });
      }

      if (settlement.releaseCents > 0) {
        await tx.guardianReserveTransaction.create({
          data: {
            tenantId,
            accountId: account.id,
            memberId: accrual.sponsorId,
            overrideAccrualId: accrual.id,
            type: ReserveTransactionType.RELEASE,
            amount: centsToDecimal(settlement.releaseCents),
            balanceAfter: updatedAccount.heldBalance,
            note: "Guardian Reserve released after the quality window."
          }
        });
      }

      if (settlement.bonusCents > 0) {
        await tx.guardianReserveTransaction.create({
          data: {
            tenantId,
            accountId: account.id,
            memberId: accrual.sponsorId,
            overrideAccrualId: accrual.id,
            type: ReserveTransactionType.QUALITY_BONUS,
            amount: centsToDecimal(settlement.bonusCents),
            balanceAfter: updatedAccount.heldBalance,
            note: "No-callback Quality Kicker."
          }
        });
      }

      const updated = await tx.overrideAccrual.update({
        where: { id: accrual.id },
        data: {
          status: settlement.debitCents > 0 ? OverrideStatus.ADJUSTED : OverrideStatus.AVAILABLE,
          reserveBonus: centsToDecimal(settlement.bonusCents),
          reserveDebit: centsToDecimal(settlement.debitCents),
          reserveReleasedAt: now
        }
      });

      await tx.notification.create({
        data: {
          tenantId,
          memberId: accrual.sponsorId,
          type: "GUARDIAN_RESERVE_SETTLED",
          title: settlement.debitCents ? "Guardian Reserve adjusted" : "Guardian Reserve released",
          body: settlement.debitCents
            ? `$${centsToDecimal(settlement.releaseCents)} released after a $${centsToDecimal(settlement.debitCents)} verified quality adjustment.`
            : `$${centsToDecimal(settlement.totalAvailableCents)} released, including the Quality Kicker.`,
          data: { accrualId: accrual.id, ...settlement }
        }
      });

      await tx.auditLog.create({
        data: {
          tenantId,
          actorType: AuditActorType.SYSTEM,
          action: "GUARDIAN_RESERVE_SETTLED",
          entityType: "OverrideAccrual",
          entityId: accrual.id,
          after: settlement,
          reason: settlement.debitCents ? "Verified corrective work existed." : "Quality window passed without eligible rework cost."
        }
      });

      return updated;
    });

    results.push({ accrualId: accrual.id, status: result.status, settlement });
  }

  return results;
}
