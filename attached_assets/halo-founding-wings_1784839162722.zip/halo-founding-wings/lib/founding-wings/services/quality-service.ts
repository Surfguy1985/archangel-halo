import { AuditActorType, ReviewStatus } from "@prisma/client";
import { prisma } from "@/lib/db";
import { reviewQualityEvidence } from "../ai/quality-reviewer";
import { getProgramConfig } from "./config-service";
import { createJobOverrideAccruals } from "./override-service";

async function retryOverridesAfterPass(jobId: string, collectedAt: Date | null): Promise<void> {
  if (!collectedAt) return;
  await createJobOverrideAccruals(jobId);
}

export async function reviewQualitySubmission(submissionId: string) {
  const submission = await prisma.qualitySubmission.findUniqueOrThrow({
    where: { id: submissionId },
    include: { job: true, review: true }
  });
  if (submission.review) return submission.review;

  const config = await getProgramConfig(submission.job.tenantId);
  const ai = await reviewQualityEvidence({
    job: {
      name: submission.job.name,
      description: submission.job.description,
      requiredSkills: submission.job.requiredSkills
    },
    checklist: submission.checklist,
    notes: submission.notes,
    beforePhotoUrls: submission.beforePhotoUrls,
    duringPhotoUrls: submission.duringPhotoUrls,
    afterPhotoUrls: submission.afterPhotoUrls,
    maxImages: config.quality.maxImagesPerReview
  });

  const weightedScore =
    ai.completenessScore * 0.35 +
    ai.craftsmanshipScore * 0.35 +
    ai.propertyProtectionScore * 0.15 +
    ai.safetyScore * 0.15;

  let finalStatus: ReviewStatus = ReviewStatus.NEEDS_REVIEW;
  if (
    ai.recommendedStatus === "PASS" &&
    ai.confidence >= config.quality.autoPassConfidence &&
    !ai.criticalConcern &&
    ai.anomalyRisk < 0.35
  ) {
    finalStatus = ReviewStatus.PASS;
  } else if (
    ai.recommendedStatus === "FAIL" &&
    ai.criticalConcern &&
    config.quality.autoFailCritical &&
    ai.confidence >= 0.9
  ) {
    finalStatus = ReviewStatus.FAIL;
  }

  const review = await prisma.$transaction(async (tx) => {
    const created = await tx.qualityReview.create({
      data: {
        submissionId,
        status: finalStatus,
        finalScore: Math.round(weightedScore * 100) / 100,
        completenessScore: ai.completenessScore,
        craftsmanshipScore: ai.craftsmanshipScore,
        propertyProtectionScore: ai.propertyProtectionScore,
        safetyScore: ai.safetyScore,
        anomalyRisk: ai.anomalyRisk,
        confidence: ai.confidence,
        criticalConcern: ai.criticalConcern,
        summary: ai.summary,
        concerns: ai.concerns,
        evidence: ai.evidence,
        aiModel: process.env.OPENAI_QUALITY_MODEL || "gpt-5-mini",
        decidedBy: AuditActorType.AI
      }
    });

    await tx.qualitySubmission.update({
      where: { id: submissionId },
      data: { reviewStatus: finalStatus }
    });

    await tx.job.update({
      where: { id: submission.jobId },
      data: { status: finalStatus === ReviewStatus.PASS ? "COMPLETE" : "QUALITY_REVIEW" }
    });

    await tx.auditLog.create({
      data: {
        tenantId: submission.job.tenantId,
        actorType: AuditActorType.AI,
        action: "QUALITY_EVIDENCE_REVIEWED",
        entityType: "QualitySubmission",
        entityId: submissionId,
        after: {
          status: finalStatus,
          score: weightedScore,
          confidence: ai.confidence,
          criticalConcern: ai.criticalConcern,
          concerns: ai.concerns
        },
        reason: ai.summary
      }
    });

    return created;
  });

  if (finalStatus === ReviewStatus.PASS) await retryOverridesAfterPass(submission.jobId, submission.job.collectedAt);
  return review;
}

export async function decideQualitySubmission(input: {
  submissionId: string;
  status: ReviewStatus;
  reason: string;
  actorId: string;
  finalScore?: number;
}) {
  const submission = await prisma.qualitySubmission.findUniqueOrThrow({
    where: { id: input.submissionId },
    include: { job: true, review: true }
  });
  const score = Math.max(0, Math.min(100, input.finalScore ?? submission.review?.finalScore ?? 0));

  const review = await prisma.$transaction(async (tx) => {
    const updated = submission.review
      ? await tx.qualityReview.update({
          where: { submissionId: input.submissionId },
          data: {
            status: input.status,
            finalScore: score,
            summary: input.reason,
            decidedBy: AuditActorType.ADMIN,
            approvedById: input.actorId,
            reviewedAt: new Date()
          }
        })
      : await tx.qualityReview.create({
          data: {
            submissionId: input.submissionId,
            status: input.status,
            finalScore: score,
            completenessScore: score,
            craftsmanshipScore: score,
            propertyProtectionScore: score,
            safetyScore: score,
            anomalyRisk: 0,
            confidence: 1,
            criticalConcern: input.status === ReviewStatus.FAIL,
            summary: input.reason,
            concerns: input.status === ReviewStatus.PASS ? [] : [input.reason],
            evidence: { manualDecision: true },
            decidedBy: AuditActorType.ADMIN,
            approvedById: input.actorId
          }
        });

    await tx.qualitySubmission.update({
      where: { id: input.submissionId },
      data: { reviewStatus: input.status }
    });
    await tx.job.update({
      where: { id: submission.jobId },
      data: { status: input.status === ReviewStatus.PASS ? "COMPLETE" : "QUALITY_REVIEW" }
    });
    await tx.auditLog.create({
      data: {
        tenantId: submission.job.tenantId,
        actorType: AuditActorType.ADMIN,
        actorId: input.actorId,
        action: "QUALITY_DECISION_OVERRIDDEN",
        entityType: "QualitySubmission",
        entityId: input.submissionId,
        before: submission.review ? { status: submission.review.status, finalScore: submission.review.finalScore } : undefined,
        after: { status: input.status, finalScore: score },
        reason: input.reason
      }
    });
    return updated;
  });

  if (input.status === ReviewStatus.PASS) await retryOverridesAfterPass(submission.jobId, submission.job.collectedAt);
  return review;
}
