import { z } from "zod";
import { getOpenAI } from "./openai";

const QualityReviewResultSchema = z.object({
  recommendedStatus: z.enum(["PASS", "NEEDS_REVIEW", "FAIL"]),
  completenessScore: z.number().min(0).max(100),
  craftsmanshipScore: z.number().min(0).max(100),
  propertyProtectionScore: z.number().min(0).max(100),
  safetyScore: z.number().min(0).max(100),
  anomalyRisk: z.number().min(0).max(1),
  confidence: z.number().min(0).max(1),
  criticalConcern: z.boolean(),
  summary: z.string().min(1).max(1200),
  concerns: z.array(z.string().max(300)).max(12),
  evidence: z.object({
    visibleCompletionSignals: z.array(z.string().max(300)).max(12),
    missingEvidence: z.array(z.string().max(300)).max(12),
    possibleDuplicateOrMismatchedImages: z.array(z.string().max(300)).max(12)
  })
});

export type AIQualityReviewResult = z.infer<typeof QualityReviewResultSchema>;

const responseJsonSchema = {
  type: "object",
  additionalProperties: false,
  required: [
    "recommendedStatus",
    "completenessScore",
    "craftsmanshipScore",
    "propertyProtectionScore",
    "safetyScore",
    "anomalyRisk",
    "confidence",
    "criticalConcern",
    "summary",
    "concerns",
    "evidence"
  ],
  properties: {
    recommendedStatus: { type: "string", enum: ["PASS", "NEEDS_REVIEW", "FAIL"] },
    completenessScore: { type: "number", minimum: 0, maximum: 100 },
    craftsmanshipScore: { type: "number", minimum: 0, maximum: 100 },
    propertyProtectionScore: { type: "number", minimum: 0, maximum: 100 },
    safetyScore: { type: "number", minimum: 0, maximum: 100 },
    anomalyRisk: { type: "number", minimum: 0, maximum: 1 },
    confidence: { type: "number", minimum: 0, maximum: 1 },
    criticalConcern: { type: "boolean" },
    summary: { type: "string" },
    concerns: { type: "array", items: { type: "string" } },
    evidence: {
      type: "object",
      additionalProperties: false,
      required: ["visibleCompletionSignals", "missingEvidence", "possibleDuplicateOrMismatchedImages"],
      properties: {
        visibleCompletionSignals: { type: "array", items: { type: "string" } },
        missingEvidence: { type: "array", items: { type: "string" } },
        possibleDuplicateOrMismatchedImages: { type: "array", items: { type: "string" } }
      }
    }
  }
} as const;

export async function reviewQualityEvidence(input: {
  job: {
    name: string;
    description?: string | null;
    requiredSkills: string[];
  };
  checklist: unknown;
  notes?: string | null;
  beforePhotoUrls: string[];
  duringPhotoUrls: string[];
  afterPhotoUrls: string[];
  maxImages: number;
}): Promise<AIQualityReviewResult> {
  const client = getOpenAI();
  const images = [
    ...input.beforePhotoUrls.map((url) => ({ stage: "BEFORE", url })),
    ...input.duringPhotoUrls.map((url) => ({ stage: "DURING", url })),
    ...input.afterPhotoUrls.map((url) => ({ stage: "AFTER", url }))
  ].slice(0, input.maxImages);

  const content: Array<Record<string, unknown>> = [
    {
      type: "input_text",
      text: JSON.stringify({
        job: input.job,
        checklist: input.checklist,
        notes: input.notes,
        imageStages: images.map(({ stage }, index) => ({ image: index + 1, stage }))
      })
    },
    ...images.map(({ url }) => ({ type: "input_image", image_url: url, detail: "high" }))
  ];

  const response = await client.responses.create({
    model: process.env.OPENAI_QUALITY_MODEL || "gpt-5-mini",
    store: false,
    instructions: [
      "You are Archangel Contractors' quality-control reviewer.",
      "Evaluate only visible and supplied evidence. Never invent hidden defects or certify code compliance from a photo.",
      "Compare before, during, and after evidence; detect incomplete areas, mismatched stages, reused images, damage, unsafe practices, and missing checklist proof.",
      "PASS requires strong evidence and no material concern. NEEDS_REVIEW is required when evidence is ambiguous, incomplete, low-confidence, or could affect pay or discipline.",
      "FAIL is a recommendation only for clear, material failure. Human review policy may still override it.",
      "Keep the summary factual and concise."
    ].join(" "),
    input: [{ role: "user", content }] as never,
    text: {
      format: {
        type: "json_schema",
        name: "archangel_quality_review",
        strict: true,
        schema: responseJsonSchema
      }
    }
  });

  const parsed = JSON.parse(response.output_text);
  return QualityReviewResultSchema.parse(parsed);
}
