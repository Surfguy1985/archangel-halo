import { z } from "zod";
import { prisma } from "@/lib/db";
import { getOpenAI } from "./openai";

const OperatorBriefSchema = z.object({
  executiveSummary: z.string().min(1).max(1500),
  risks: z.array(z.object({ severity: z.enum(["LOW", "MEDIUM", "HIGH"]), title: z.string(), detail: z.string() })).max(12),
  recommendedActions: z.array(z.object({ priority: z.number().int().min(1).max(100), action: z.string(), reason: z.string() })).max(20),
  celebration: z.array(z.string()).max(8)
});

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["executiveSummary", "risks", "recommendedActions", "celebration"],
  properties: {
    executiveSummary: { type: "string" },
    risks: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["severity", "title", "detail"],
        properties: {
          severity: { type: "string", enum: ["LOW", "MEDIUM", "HIGH"] },
          title: { type: "string" },
          detail: { type: "string" }
        }
      }
    },
    recommendedActions: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["priority", "action", "reason"],
        properties: {
          priority: { type: "integer", minimum: 1, maximum: 100 },
          action: { type: "string" },
          reason: { type: "string" }
        }
      }
    },
    celebration: { type: "array", items: { type: "string" } }
  }
} as const;

export async function createOperatorBrief(tenantId: string) {
  const [members, pendingReviews, openJobs, heldReserves, incidents] = await Promise.all([
    prisma.crewMember.findMany({
      where: { tenantId, status: "ACTIVE" },
      select: { name: true, currentHaloScore: true, currentTier: true, founderStatus: true, scoreConfidence: true },
      orderBy: { currentHaloScore: "desc" },
      take: 100
    }),
    prisma.qualitySubmission.count({ where: { job: { tenantId }, reviewStatus: "PENDING" } }),
    prisma.job.findMany({
      where: { tenantId, status: "OPEN" },
      select: { name: true, priority: true, requiredHaloScore: true, eligibilityDecisions: { where: { eligible: true }, select: { id: true } } },
      take: 50
    }),
    prisma.overrideAccrual.aggregate({
      where: { tenantId, status: "HELD" },
      _sum: { reserveAmount: true },
      _count: true
    }),
    prisma.incident.findMany({
      where: { tenantId, resolvedAt: null },
      select: { type: true, severity: true, description: true },
      orderBy: { severity: "desc" },
      take: 30
    })
  ]);

  const client = getOpenAI();
  const response = await client.responses.create({
    model: process.env.OPENAI_OPERATOR_MODEL || "gpt-5-mini",
    store: false,
    instructions: [
      "You are HALO's Founding Wings operations chief.",
      "Analyze the supplied program snapshot and create a concise operating brief.",
      "Do not invent data. Do not recommend changing compensation for protected traits or subjective personality judgments.",
      "Prioritize quality, safety, customer commitments, fair access, reserve risk, and recognizing excellent work.",
      "The deterministic HALO rules engine—not you—makes final eligibility and money decisions."
    ].join(" "),
    input: JSON.stringify({ members, pendingReviews, openJobs, heldReserves, incidents }),
    text: { format: { type: "json_schema", name: "founding_wings_operator_brief", strict: true, schema } }
  });

  return OperatorBriefSchema.parse(JSON.parse(response.output_text));
}
