# HALO Integration Checklist

## 1. Map existing HALO entities

- `Tenant` → HALO organization/account
- `CrewMember.externalUserId` → HALO user/contractor ID
- `Job.externalJobId` → HALO job ID
- `Assignment` → HALO job assignment
- `Incident` → HALO QA/customer issue
- `Notification` → HALO notification center
- `AuditLog` → HALO audit/event log

## 2. Connect event producers

Emit these events from HALO:

- `ASSIGNMENT_COMPLETED`
- `JOB_COMPLETED`
- `PAYMENT_COLLECTED`
- `INCIDENT_REPORTED`

## 3. Add quality upload UI

Required evidence:

- Before photos
- During-work photos
- After photos
- Checklist
- Crew notes
- Customer/property-manager signoff when available

## 4. Add human exception queue

Build actions for:

- Approve AI-escalated quality submission
- Fail with documented reason
- Request new evidence
- Resolve incident
- Manual score correction with expiration
- Manual reserve adjustment with audit reason

## 5. Connect payout ledger

Export:

- Immediate override `READY` entries
- Released Guardian Reserve entries
- Quality Kicker entries
- Debit/adjustment entries

Reconcile external payout IDs back to `OverrideAccrual.immediateStatus` and your payout ledger.

## 6. Tune rules

Change `ProgramConfig.config` instead of hardcoding:

- Score weights and thresholds
- Lookback period
- Override rates
- Reserve percentage
- Quality window
- AI confidence threshold
- Job capacity and critical incident policy

## 7. Launch safely

Start in shadow mode for 30–60 days:

- Calculate decisions without automatically changing access or pay.
- Compare AI reviews with supervisor reviews.
- Measure false positives, false negatives, callback rates, and demographic fairness.
- Adjust thresholds.
- Turn on automatic approvals in stages.
