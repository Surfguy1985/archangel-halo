import { describe, expect, it } from "vitest";
import { DEFAULT_CONFIG } from "@/lib/founding-wings/config";
import { calculateHaloScore } from "@/lib/founding-wings/core/score-engine";

const excellent = {
  inspectionScores: [98, 97, 99, 96],
  customerRatings: [5, 5, 4.9, 5],
  callbackCount: 0,
  damageCount: 0,
  completedJobCount: 4,
  acceptedAssignmentCount: 4,
  onTimeCount: 4,
  onTimeMeasuredCount: 4,
  attendedCount: 4,
  attendanceMeasuredCount: 4,
  communicationRatings: [5, 5, 5, 5],
  professionalismRatings: [5, 5, 5, 5],
  safetyScores: [100, 98, 100, 99],
  safetyIncidentCount: 0,
  activeQualityRecruitCount: 5,
  completedRescueMissionCount: 4
};

describe("Halo Score", () => {
  it("rewards excellent quality and leadership", () => {
    const result = calculateHaloScore(excellent, DEFAULT_CONFIG);
    expect(result.totalScore).toBeGreaterThanOrEqual(95);
    expect(result.tier).toBe("PLATINUM");
  });

  it("reduces quality for callbacks", () => {
    const clean = calculateHaloScore(excellent, DEFAULT_CONFIG);
    const callbacks = calculateHaloScore({ ...excellent, callbackCount: 3 }, DEFAULT_CONFIG);
    expect(callbacks.totalScore).toBeLessThan(clean.totalScore);
    expect(callbacks.reasons.join(" ")).toContain("Callbacks");
  });

  it("keeps confidence low and tier provisional for a new member", () => {
    const result = calculateHaloScore({ ...excellent, completedJobCount: 1, acceptedAssignmentCount: 1 }, DEFAULT_CONFIG);
    expect(result.confidence).toBeLessThan(0.5);
    expect(result.tier).toBe("TRAINING");
  });
});
