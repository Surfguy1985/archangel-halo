import { describe, expect, it } from "vitest";
import { DEFAULT_CONFIG } from "@/lib/founding-wings/config";
import { calculateOverride } from "@/lib/founding-wings/core/override-engine";
import { settleGuardianReserve } from "@/lib/founding-wings/core/guardian-reserve";

describe("Wingline overrides", () => {
  it("calculates a 5% override with platinum multiplier and 20% reserve", () => {
    const result = calculateOverride(
      { allocatedGrossProfitCents: 100_000, sponsorRelationshipMonths: 6, recruitHaloScore: 97, reservePercent: 0.2 },
      DEFAULT_CONFIG
    );
    expect(result.grossOverrideCents).toBe(6250);
    expect(result.immediateAmountCents).toBe(5000);
    expect(result.reserveAmountCents).toBe(1250);
  });

  it("pauses overrides below a 75 Halo Score", () => {
    const result = calculateOverride(
      { allocatedGrossProfitCents: 100_000, sponsorRelationshipMonths: 6, recruitHaloScore: 70, reservePercent: 0.2 },
      DEFAULT_CONFIG
    );
    expect(result.grossOverrideCents).toBe(0);
  });
});

describe("Guardian Reserve", () => {
  it("releases reserve plus a no-callback quality kicker", () => {
    const result = settleGuardianReserve({ reserveAmountCents: 1000, eligibleReworkCostCents: 0, qualityBonusPercent: 0.05 });
    expect(result.releaseCents).toBe(1000);
    expect(result.bonusCents).toBe(50);
  });

  it("caps corrective-work debits at the reserve amount", () => {
    const result = settleGuardianReserve({ reserveAmountCents: 1000, eligibleReworkCostCents: 3000, qualityBonusPercent: 0.05 });
    expect(result.debitCents).toBe(1000);
    expect(result.releaseCents).toBe(0);
    expect(result.bonusCents).toBe(0);
  });
});
