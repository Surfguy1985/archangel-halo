import { describe, expect, it } from "vitest";
import { evaluateEligibility } from "@/lib/founding-wings/core/eligibility-engine";

const member = {
  status: "ACTIVE" as const,
  founderStatus: "FOUNDING_WING" as const,
  haloScore: 96,
  tier: "PLATINUM" as const,
  tradeSkills: ["cleaning", "turns"],
  certifications: [{ code: "OSHA10", verified: true }],
  activeJobCount: 0,
  maxConcurrentJobs: 2,
  isAvailable: true,
  unresolvedCriticalIncidentCount: 0,
  draftTokens: 2
};

const job = {
  requiredHaloScore: 90,
  requiredSkills: ["cleaning"],
  requiredCertifications: ["OSHA10"],
  priority: "FLAGSHIP" as const
};

describe("eligibility", () => {
  it("places qualified platinum founders in the first window", () => {
    const result = evaluateEligibility(member, job);
    expect(result.eligible).toBe(true);
    expect(result.window).toBe("PLATINUM_FIRST");
  });

  it("blocks missing certifications", () => {
    const result = evaluateEligibility({ ...member, certifications: [] }, job);
    expect(result.eligible).toBe(false);
    expect(result.missingRequirements.join(" ")).toContain("OSHA10");
  });

  it("blocks critical incidents", () => {
    const result = evaluateEligibility({ ...member, unresolvedCriticalIncidentCount: 1 }, job);
    expect(result.eligible).toBe(false);
  });
});
