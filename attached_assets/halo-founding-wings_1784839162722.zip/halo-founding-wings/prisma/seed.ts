import { FounderStatus, JobPriority, JobStatus, PrismaClient, WingTier } from "@prisma/client";
import { DEFAULT_CONFIG } from "../lib/founding-wings/config";

const prisma = new PrismaClient();

async function main() {
  const tenant = await prisma.tenant.upsert({
    where: { slug: "archangel-contractors" },
    update: {},
    create: { name: "Archangel Contractors", slug: "archangel-contractors", timezone: "America/Chicago" }
  });

  await prisma.programConfig.upsert({
    where: { tenantId: tenant.id },
    update: { config: DEFAULT_CONFIG as object },
    create: { tenantId: tenant.id, config: DEFAULT_CONFIG as object }
  });

  const founders = [
    { name: "Maria Santos", founderNumber: 1, score: 97.4, tier: WingTier.PLATINUM, skills: ["cleaning", "turns"] },
    { name: "Daniel Ruiz", founderNumber: 2, score: 93.1, tier: WingTier.GOLD, skills: ["paint", "drywall"] },
    { name: "Ana Morales", founderNumber: 3, score: 89.2, tier: WingTier.SILVER, skills: ["cleaning", "inspection"] },
    { name: "Jose Martinez", founderNumber: 4, score: 84.6, tier: WingTier.TRAINING, skills: ["turf", "fence"] }
  ];

  const created = [];
  for (const founder of founders) {
    created.push(await prisma.crewMember.upsert({
      where: { tenantId_founderNumber: { tenantId: tenant.id, founderNumber: founder.founderNumber } },
      update: {},
      create: {
        tenantId: tenant.id,
        name: founder.name,
        founderStatus: FounderStatus.FOUNDING_WING,
        founderNumber: founder.founderNumber,
        founderSince: new Date(),
        currentHaloScore: founder.score,
        currentTier: founder.tier,
        scoreConfidence: 0.92,
        scoreUpdatedAt: new Date(),
        tradeSkills: founder.skills,
        draftTokens: founder.tier === WingTier.PLATINUM ? 2 : 0
      }
    }));
  }

  await prisma.crewMember.upsert({
    where: { tenantId_externalUserId: { tenantId: tenant.id, externalUserId: "seed-recruit-1" } },
    update: {},
    create: {
      tenantId: tenant.id,
      externalUserId: "seed-recruit-1",
      name: "Luis Vega",
      sponsorId: created[0].id,
      sponsorSince: new Date(),
      currentHaloScore: 91.5,
      currentTier: WingTier.GOLD,
      scoreConfidence: 0.8,
      scoreUpdatedAt: new Date(),
      tradeSkills: ["cleaning", "turns"]
    }
  });

  const existingJob = await prisma.job.findFirst({ where: { tenantId: tenant.id, name: "Oakline 84-Unit Turn" } });
  if (!existingJob) {
    await prisma.job.create({
      data: {
        tenantId: tenant.id,
        name: "Oakline 84-Unit Turn",
        description: "Apartment turn cleaning and punch completion.",
        status: JobStatus.OPEN,
        priority: JobPriority.FLAGSHIP,
        requiredHaloScore: 90,
        requiredSkills: ["cleaning"],
        slots: 8,
        startsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        dueAt: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000)
      }
    });
  }

  console.log(`Seeded ${tenant.name} (${tenant.id})`);
}

main().finally(() => prisma.$disconnect());
