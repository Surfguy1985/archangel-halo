#!/usr/bin/env node
/**
 * npm run demo             → replays demos/tuesday.json
 * npm run demo -- blocked-paths
 *
 * Every step goes through the real engine: guards, Halo call (DRY_RUN by
 * default), emitted events and stage automations. This is the fastest way to
 * see the whole automation surface without clicking anything.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { dispatch } from '../src/engine.js';
import '../src/handlers.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const name = process.argv[2] || 'tuesday';
const file = path.join(__dirname, '..', 'demos', name + '.json');
if (!fs.existsSync(file)) { console.error('No demo called ' + name); process.exit(1); }

const demo = JSON.parse(fs.readFileSync(file, 'utf8'));
const wait = (ms) => new Promise(r => setTimeout(r, ms));

console.log('\n' + demo.name + '\n' + '─'.repeat(demo.name.length) + '\n' + demo.description + '\n');

let ok = 0, blocked = 0, failed = 0;
for (const step of demo.steps) {
  const stamp = step.at ? step.at + '  ' : '';
  console.log(stamp + step.action + '   ' + (step.note || ''));
  const res = await dispatch({
    action: step.action,
    actor: { role: 'manager', name: 'Dana Okafor', id: 'usr_dokafor' },
    property: { id: 'prop_northgate', name: 'Northgate Commons' },
    payload: step.payload
  });
  if (res.blocked) { blocked++; console.log('     BLOCKED — ' + res.reason); }
  else if (!res.ok) { failed++; console.log('     FAILED  — ' + res.error); }
  else {
    ok++;
    if (res.emitted?.length)    console.log('     emitted     ' + res.emitted.join(', '));
    if (res.automations?.length) console.log('     automations ' + res.automations.join(', '));
  }
  console.log('');
  await wait(demo.speed_ms || 300);
}
console.log('done — ' + ok + ' ran, ' + blocked + ' blocked, ' + failed + ' failed\n');
