# Halo Property-Operations Kanban

A 22-template Kanban board for property management, plus the action registry,
automation engine and webhook hooks that connect it to the Halo CRM.

Everything a manager can click on a card resolves to exactly one named action.
Every action declares the Halo endpoint it calls, the events it emits, and the
automations that fire downstream. Nothing is hard-coded in the UI.

---

## Run it

```bash
npm install
cp .env.example .env      # DRY_RUN=true logs calls instead of sending them
npm start
```

On Replit: import the folder, press **Run**. Landing page at `/`, board at `/board.html`.

```bash
npm run demo            # replay a full operating day through the engine
npm run demo:blocked    # prove every guard refuses what it should
npm run export          # write dist/cards/, dist/flows/, dist/FLOWS.md
```

| Route | What it does |
| --- | --- |
| `GET  /board.html` | the board UI |
| `POST /api/actions` | the board posts every button press here |
| `GET  /api/actions` | machine-readable catalogue of all actions |
| `GET  /api/templates` | all 22 card templates, pipelines and automations |
| `GET  /api/events` | event catalogue + who is subscribed |
| `GET  /api/audit` | last 500 dispatched actions |
| `POST /webhooks/halo` | Halo pushes events back into the board (HMAC verified) |
| `GET  /export.html` | export every card as a standalone HTML file |

---

## How a button press travels

```
[card button]
   → window 'halo:action'  { action, actor, property, payload.card }
   → public/halo-bridge.js  POST /api/actions
   → src/engine.js dispatch()
        1. resolve src/actions.js entry
        2. run its guard()            ← blocks with a reason if preconditions fail
        3. call the Halo API          ← src/halo-client.js
        4. emit the action's events   ← src/hooks.js
        5. run stage-entry automations from src/templates.js
   → src/handlers.js  your integrations (Twilio, email, GL, access control…)
```

## Wiring an integration

`src/handlers.js` is the only file you need to touch:

```js
import { on } from './hooks.js';

on('sms.resident.window', async (evt) => {
  await twilio.messages.create({
    to: evt.payload.card.resident_phone,
    body: \`Your technician arrives \${evt.payload.window}\`
  });
});
```

Subscribe to `'*'` to receive everything (audit logging, analytics, Slack).

---

## Action map — every button, every card

### Universal (all 22 cards)
| Button | Action | Emits |
| --- | --- | --- |
| card body | `card.opened` | `audit.view` |
| ✓ | *(local selection only)* | — |
| ↓ | `card.export_requested` | `export.queued` |
| next-stage chip | `card.stage_advanced` | `card.stage_changed` + template automations |
| drag between lanes | `card.moved` | `card.lane_changed` |

### Per template — primary / secondary button
| Template | Primary (approve) | Secondary (deny) |
| --- | --- | --- |
| Work Order | `maint.dispatch_tech` | `maint.hold_for_parts` |
| Make-Ready | `turn.release_for_reinspection` | `turn.hold_unit` |
| Invoice | `ap.approve_invoice` | `ap.hold_invoice` |
| Payment Run | `ap.release_payment_run` | `ap.split_payment_run` |
| Vendor Crew | `vendor.signoff_job` | `vendor.reject_job` |
| Change Order | `vendor.approve_change_order` | `vendor.deny_change_order` |
| COI / Compliance | `compliance.request_coi_renewal` | `compliance.suspend_vendor` |
| Supply Order | `purchasing.issue_po` | `purchasing.edit_draft` |
| Dispatch | `dispatch.autobalance_route` | `dispatch.assign_manually` |
| Virtual Key | `access.extend_credential` | `access.revoke_credential` |
| Resident Thread | `comms.send_suggested_reply` | `comms.open_composer` |
| Occupancy | `leasing.prioritize_gap_units` | `ops.snooze_card` |
| Tour / Lead | `leasing.confirm_tour_and_hold` | `leasing.release_unit` |
| Renewal | `leasing.send_renewal_offer` | `leasing.adjust_renewal_rate` |
| Delinquency | `collections.serve_notice` | `collections.offer_payment_plan` |
| Move-Out | `leasing.generate_deposit_statement` | `inspection.schedule_rewalk` |
| Budget Variance | `finance.send_reforecast` | `finance.absorb_variance` |
| Preventive Maint. | `maint.book_pm_service` | `maint.defer_pm` |
| Code Violation | `compliance.dispatch_and_file_packet` | `compliance.request_extension` |
| Promo | `leasing.extend_promo` | `leasing.end_promo` |
| Tech Bonus | `payroll.approve_bonus` | `payroll.send_to_review` |
| Emergency | `emergency.escalate_oncall` | `emergency.page_manager` |

### Vendor Crew card — the extra controls
| Button | Action | Payload |
| --- | --- | --- |
| **MAP VIEW** (per crew member) | `crew.locate_requested` | name, badge, status, GPS, accuracy, last ping, geofence, clock in/out, assigned units |
| **ESCALATE ›** (per finding) | `maint.create_work_order_from_finding` | severity, text, unit, reported_by → creates a work order, links it to the job, credits the vendor |
| **OPEN** (job report) | `vendor.job_report_opened` | only unlocks at the *Wrapping* stage or later |

### Board-level
| Control | Action |
| --- | --- |
| Bulk export | `bulk.export_requested` |
| Advance all | `bulk.advance_stage` |
| Assign selected | `bulk.assign` |
| Defer selected | `bulk.defer` |
| Triage A / S / D | `triage.approve` / `triage.assign` / `triage.defer` |

---

## Guards

Some actions refuse to run and return a reason instead of a 200:

- `ap.approve_invoice` — blocked unless the 3-way match passes
- `ap.release_payment_run` — blocked without owner approval
- `vendor.approve_change_order` — blocked above \$5,000 without owner sign-off
- `vendor.signoff_job` — blocked with zero after-photos
- `compliance.dispatch_and_file_packet` — blocked on an incomplete evidence packet
- `leasing.send_renewal_offer` — blocked while work orders are open
- `leasing.generate_deposit_statement` — blocked unless photos are paired per charge
- `maint.defer_pm` — blocked when deferral voids the warranty inside 30 days

Add your own: put a `guard(ctx)` on any entry in `src/actions.js`.

---

## Inbound: Halo → board

`POST /webhooks/halo` with `{ "event": "crew.clock_in", "data": { ... } }` and an
`x-halo-signature` HMAC-SHA256 header over the raw body using `HALO_WEBHOOK_SECRET`.
Useful inbound events: `crew.clock_in`, `crew.clock_out`, `crew.geofence_enter`,
`crew.geofence_exit`, `payment.received`, `coi.uploaded`, `inspection.completed`.

---

## What is in the box

| | |
| --- | --- |
| **Board** | `public/board.html` — the running prototype, all 22 templates live |
| **Cards** | `src/cards.js` — every card record and module payload; `npm run export` splits it into `dist/cards/<template>.json` |
| **Flows** | `src/templates.js` — pipelines, module grammar, stage automations; exported to `dist/flows/<template>.json` and `dist/FLOWS.md` |
| **Actions** | `src/actions.js` — 60+ actions, one per button, with endpoints, payload builders, guards |
| **Demos** | `demos/tuesday.json` — a full operating day; `demos/blocked-paths.json` — every guard |
| **Hooks** | `src/hooks.js` event bus + `src/handlers.js` for your integrations |
| **Server** | `server/index.js` — REST API and the Halo webhook receiver |
| **Card export** | `public/export.html` — writes each template out as standalone HTML |

## Demos

`npm run demo` replays `demos/tuesday.json` — crew clock-in, route balancing, an AC
dispatch, a crew finding escalated into a work order, a change order approved, a vendor
suspended for lapsed workers comp, a resident answered inside SLA, invoices approved,
the AP run released, a job signed off, a turn re-inspected, and a 9:41pm gas call.
Each step prints the guard result, the events emitted and the automations fired.

`npm run demo:blocked` runs the eight actions that are supposed to refuse, and shows
the reason each one gives back.

## Files

```
server/index.js        Express app, REST + webhook receiver
src/cards.js           all 22 card records + module payloads
scripts/export-all.js  writes dist/cards, dist/flows, dist/FLOWS.md
scripts/demo.js        replays a demo scenario through the engine
demos/*.json           scenario scripts
src/actions.js         the action registry — every button lives here
src/templates.js       the 22 card templates: pipelines, modules, automations
src/engine.js          dispatch(): guard → API call → events → automations
src/hooks.js           the event bus and the full event catalogue
src/halo-client.js     Halo API fetch wrapper (DRY_RUN aware)
src/handlers.js        >>> your integrations go here <<<
public/board.html      board loader + bridge
public/board.dc.html   the board UI
public/OpsCard.dc.html the card renderer
public/halo-bridge.js  forwards every UI action to /api/actions
```
