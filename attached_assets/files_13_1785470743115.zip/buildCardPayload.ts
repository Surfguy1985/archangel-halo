/**
 * buildCardPayload.ts — server side of the card contract.
 *
 * Turns a Halo card row + its waybill stages into the exact JSON the renderer
 * consumes (schema/falkon-card.schema.json). Two rules make this file the
 * boundary it needs to be:
 *
 *   1. AUDIENCE-AWARE ACTIONS. The same card produces different payloads for
 *      the sender and the recipient. Never emit an action the viewer can't
 *      take — the renderer trusts this list completely.
 *   2. AMOUNTS STAY INTEGER CENTS. This file never formats currency. The
 *      renderer does that with Intl, in the viewer's locale.
 *
 * The waybill needs no special handling: stages are read from the append-only
 * `waybill_stages` table (sealed-card pack) and the SSE stream pushes new ones
 * as the OTHER party moves the card. Payload and stream share one vocabulary.
 */

import type { FalkonCardData, Stage } from './FalkonCard';

const STAGE_ORDER: Stage[] = ['sealed', 'routed', 'delivered', 'opened', 'in_review', 'settled'];

/* Enterprise brand registry — one row per org on the network. Publishing a
   branded card program is this object plus a manifest (Ecosystem pack). */
export interface BrandRow {
  orgId: string;
  name: string;
  logoUrl?: string | null;
  monogram?: string | null;
  gradientFrom?: string | null;
  gradientTo?: string | null;
  accent?: string | null;
  onDark?: boolean | null;
}

export interface CardRow {
  code: string;
  kind: string;
  title: string;
  subtitle?: string | null;
  senderOrgId: string;
  recipientLabel?: string | null;
  amountCents?: number | null;
  currency?: string | null;
  slaHours?: number | null;
  sealed?: boolean;
}

export interface StageRow { stage: Stage; at: Date | string; note?: string | null; byLabel?: string | null }
export interface LineRow { label: string; valueCents?: number | null; valueText?: string | null; emphasis?: boolean }

export type Audience = 'sender' | 'recipient' | 'office';

/* ── Action vocabulary per module kind, per audience ──────────────────────── */
type ActionDef = { id: string; label: string; style?: 'primary' | 'secondary' | 'danger'; advancesTo?: Stage | null };

const ACTIONS: Record<string, Partial<Record<Audience, (c: CardRow, cur: Stage) => ActionDef[]>>> = {
  invoice: {
    recipient: (c, cur) => {
      if (cur === 'settled') return [];
      if (cur === 'in_review') return [{ id: 'pay', label: `Pay ${fmtHint(c.amountCents)}`, advancesTo: 'settled' }];
      return [
        { id: 'approve', label: 'Approve invoice', advancesTo: 'in_review' },
        { id: 'dispute', label: 'Dispute', style: 'danger' as const },
      ];
    },
    sender: (_c, cur) => (cur === 'settled' ? [] : [{ id: 'remind', label: 'Send reminder', style: 'secondary' as const }]),
  },
  work_order: {
    recipient: (_c, cur) => (cur === 'settled' ? [] : [{ id: 'authorize', label: 'Authorize work', advancesTo: 'in_review' }]),
    sender: () => [{ id: 'update', label: 'Post update', style: 'secondary' as const }],
  },
  change_order: {
    recipient: (c) => [
      { id: 'sign', label: `Sign — ${fmtHint(c.amountCents)}`, advancesTo: 'in_review' },
      { id: 'reject', label: 'Reject', style: 'danger' as const },
    ],
  },
  live_order: {
    recipient: (c) => [{ id: 'order', label: `Order — ${fmtHint(c.amountCents)}`, advancesTo: 'in_review' }],
  },
  loan_file: {
    recipient: () => [{ id: 'approve_loan', label: 'Approve loan', advancesTo: 'settled' }],
  },
  ticket: {
    recipient: () => [{ id: 'transfer', label: 'Transfer ticket', style: 'secondary' as const }],
  },
};

function fmtHint(cents?: number | null): string {
  // A label hint only — real formatting happens client-side with Intl.
  return cents == null ? '' : '$' + Math.round(cents / 100).toLocaleString();
}

export function currentStage(stages: StageRow[]): Stage {
  const done = new Set(stages.map((s) => s.stage));
  return [...STAGE_ORDER].reverse().find((s) => done.has(s)) ?? 'sealed';
}

function holderFor(cur: Stage): 'sender' | 'network' | 'recipient' | 'done' {
  if (cur === 'settled') return 'done';
  if (cur === 'sealed') return 'sender';
  if (cur === 'routed') return 'network';
  return 'recipient';
}

function stalledHours(stages: StageRow[], slaHours?: number | null, cur?: Stage): number | null {
  if (!slaHours || cur === 'settled' || !stages.length) return null;
  const last = stages.reduce((a, s) => Math.max(a, new Date(s.at).getTime()), 0);
  const idle = (Date.now() - last) / 3_600_000;
  return idle > slaHours ? Math.round(idle * 10) / 10 : null;
}

/* ── The builder ─────────────────────────────────────────────────────────── */
export function buildCardPayload(input: {
  card: CardRow;
  brand: BrandRow;
  stages: StageRow[];
  lines?: LineRow[];
  meta?: Array<{ label: string; value: string }>;
  media?: Array<{ url: string; alt?: string | null; caption?: string | null }>;
  audience: Audience;
  amountLabel?: string;
}): FalkonCardData {
  const { card, brand, stages, audience } = input;
  const cur = currentStage(stages);

  const build = ACTIONS[card.kind]?.[audience];
  const actions = (build ? build(card, cur) : []).map((a) => ({
    id: a.id, label: a.label, style: a.style ?? ('primary' as const), advancesTo: a.advancesTo ?? null,
  }));

  return {
    code: card.code,
    kind: card.kind,
    title: card.title,
    subtitle: card.subtitle ?? null,
    brand: {
      name: brand.name,
      logoUrl: brand.logoUrl ?? null,
      monogram: brand.monogram ?? null,
      ...(brand.gradientFrom ? { gradientFrom: brand.gradientFrom } : {}),
      ...(brand.gradientTo ? { gradientTo: brand.gradientTo } : {}),
      ...(brand.accent ? { accent: brand.accent } : {}),
      onDark: brand.onDark !== false,
    },
    sealed: card.sealed !== false,
    recipientLabel: audience === 'recipient' ? null : (card.recipientLabel ?? null),
    waybill: {
      stages: stages
        .slice()
        .sort((a, b) => STAGE_ORDER.indexOf(a.stage) - STAGE_ORDER.indexOf(b.stage))
        .map((s) => ({
          stage: s.stage,
          at: new Date(s.at).toISOString(),
          note: s.note ?? null,
          byLabel: s.byLabel ?? null,
        })),
      slaHours: card.slaHours ?? null,
      stalledHours: stalledHours(stages, card.slaHours, cur),
      holder: holderFor(cur),
      live: true,
    },
    amount: card.amountCents == null ? null : {
      cents: card.amountCents,
      currency: card.currency ?? 'USD',
      label: input.amountLabel ?? 'Total due',
    },
    lines: input.lines ?? [],
    meta: input.meta ?? [],
    media: input.media ?? [],
    actions,
    footnote: card.sealed === false
      ? null
      : 'Envelope-encrypted. Falkon routes this card; Falkon cannot read it.',
  };
}

/* ── SSE frame the renderer listens for ──────────────────────────────────────
   Emit this from recordStage() (sealed-card pack) so both boards light the
   same dot within a second of the move. */
export interface WaybillFrame { code: string; stage: Stage; at: string; note?: string | null; byLabel?: string | null }

export function waybillFrame(code: string, stage: Stage, byLabel?: string | null, note?: string | null): string {
  const payload: WaybillFrame = { code, stage, at: new Date().toISOString(), byLabel: byLabel ?? null, note: note ?? null };
  return `event: waybill\ndata: ${JSON.stringify(payload)}\n\n`;
}
