# Halo Card Template — the schema, the render, the live dots

This is the deck's card as a drop-in for Halo. One JSON contract, one React
component, one SSE frame — the same payload renders on the sender's board,
the recipient's board, and the back office, and the six green dots light in
real time as the *other* party moves the card.

**What's in the pack**

```
schema/falkon-card.schema.json          → JSON Schema 2020-12 (the contract)
src/FalkonCard.tsx                       → the full-bleed renderer
src/buildCardPayload.ts                  → server-side payload builder
```

Ships to `lib/board-ui/src/components/card/` in the Halo repo.

---

## The design, encoded

The card renders exactly as it does on slide 3 of the deck: colored brand
header, `Sealed to you` chip, `FLK-XXXXX` waybill code, and six green dots
connected by lines that light left-to-right as stages complete. Below the
strip: line items, total, action buttons, and the sealed-footer disclosure.

The dots are always **volt green** (`#B4FF44`), never the brand accent —
every card in the network reads the same progress. Brand owns the header;
the network owns status.

## The contract (`schema/falkon-card.schema.json`)

One payload, six top-level pieces:

- **`code`** — `FLK-XXXXX`, Crockford base32, no ambiguous glyphs. Also the
  key the SSE stream uses to route updates to this card instance.
- **`brand`** — name, `logoUrl` or `monogram`, gradient, accent, `onDark`.
  This is the entire enterprise-branding surface. Change these five fields
  and the card is Ticketmaster's card, or Halo's, or Gulp's.
- **`waybill`** — `stages[]` (an append-only log with `at` timestamps and
  optional `byLabel`), plus `slaHours`, `stalledHours`, `holder`, `live`.
- **`amount`** — **always integer cents** (`{ cents: 482000 }`), never
  formatted. The renderer does the currency formatting client-side with
  `Intl.NumberFormat` in the viewer's locale.
- **`lines[]`, `meta[]`, `media[]`** — line items, key/value chips,
  full-bleed photo strip. All optional.
- **`actions[]`** — computed per audience, max 3. Never emit an action the
  viewer can't take.

`additionalProperties: false` throughout. The schema has an embedded example
(the invoice from the deck) plus tests that reject float cents, malformed
codes (rejects `FLK-1234` and codes containing I/L/O/U), unknown stages,
extra properties, and un-hashed hex colors.

## The renderer (`src/FalkonCard.tsx`)

```tsx
import { FalkonCard } from '@workspace/board-ui';

<FalkonCard
  data={card}                                                // matches the schema exactly
  streamUrl={`/api/client/${token}/board/events`}            // omit for static/print
  onAction={(id) => act(card.code, id)}
/>
```

**What makes the dots feel live:**

1. `useLiveStages(code, streamUrl, seed)` subscribes to the board's SSE
   stream (the same one from the hardening pack — no new endpoint), filters
   `waybill` events by `code`, and merges any new stage. Reconnect uses the
   pack's exponential-backoff pattern.
2. When a stage arrives that wasn't in the seed, its dot fires a one-shot
   `ping` animation (scale + ring). Already-lit dots don't re-animate on
   re-render.
3. Actions with `advancesTo` light their target dot **optimistically** at
   half opacity the moment you tap. When the server's echo arrives, the
   opacity fills. If it never does, the optimistic dot decays after 8s so a
   dropped update doesn't leave a lie on screen.
4. `stalledHours` (server-computed against `slaHours`) turns the leading dot
   amber and pulses it — the "your move" alarm without a modal.
5. Every dot carries a hover tooltip with the stage, the timestamp, and the
   `byLabel` — "R. Chen, Riverside PM · Jul 30, 4:41 PM". That's what
   makes it feel like you're watching their board.

Every prop the schema declares is used. Every schema stage matches the
renderer's `STAGE_ORDER` — verified programmatically.

## The server (`src/buildCardPayload.ts`)

`buildCardPayload({ card, brand, stages, audience, ... })` turns Halo rows
into the exact JSON the renderer consumes. Two rules make this the boundary
it needs to be:

1. **Audience-aware actions.** Sender, recipient, and office get different
   `actions[]` from the same card. `ACTIONS['invoice'].recipient(card, cur)`
   returns Approve→Pay→(none once settled); `ACTIONS['invoice'].sender` only
   ever returns "Send reminder." The renderer trusts this list completely,
   because the server owns permission.
2. **Amounts stay integer cents.** This file never formats currency; the
   payload carries `{ cents: 482000 }` and the renderer formats it in the
   viewer's locale.

The waybill needs no special handling: `stages` come from the append-only
`waybill_stages` table (sealed-card pack), and the SSE stream pushes new
ones as the other party moves the card. Payload and stream share one
vocabulary.

## The SSE frame

`waybillFrame(code, stage, byLabel, note)` returns an already-formatted SSE
frame. Emit it from `recordStage()` in the sealed-card pack — one line
change wires the live sync:

```ts
// server/sealed-cards.ts — recordStage(), after the INSERT
sseHub.broadcast(payerOrgId, waybillFrame(code, stage, byLabel));
sseHub.broadcast(payeeOrgId, waybillFrame(code, stage, byLabel));
```

That's the whole live-sync mechanism. Because `waybill_stages` has a
`PRIMARY KEY (code, stage)`, a duplicate stage insert is a no-op, and the
frame is idempotent for the same reason — the renderer merges by stage, not
by timestamp.

## Enterprise branding — how a new logo enters the network

An enterprise on the network has one row in a `brands` table with the eight
`BrandRow` fields (name, logoUrl, monogram, gradientFrom/To, accent, onDark).
Look it up by `card.senderOrgId` in the payload builder. Halo's brand is
seeded first-party; Ticketmaster's ships with their publisher registration
(Ecosystem pack). Filling in that row IS onboarding a branded card program.

## Verified before shipping

- Schema is JSON Schema 2020-12; embedded example validates; **rejects**:
  float cents, `FLK-1234`, ambiguous glyphs, unknown stages, extra props,
  un-hashed hex. All schema stages match the renderer's `STAGE_ORDER`.
- Renderer + builder pass strict `tsc` with zero errors.
- Example's line-item cents sum equals the total (`182,000 + 214,000 + 84,000 = 482,000`).

## Two failure modes worth naming

- **Server broadcasts a stage but the client already has it.** The renderer's
  `useLiveStages` de-dupes by stage; the ping doesn't fire; the dot stays
  lit. Nothing to fix.
- **Client shows an optimistic dot that never confirms.** Server didn't echo
  within 8 seconds. The dot fades back. Log the action id — usually a
  permissions gap (the audience received an action they shouldn't have) or a
  webhook that hasn't landed yet.

## Not here on purpose

- **No polling fallback in the renderer.** SSE reconnects itself; TanStack
  Query's `refetchInterval` on the parent list is the catch-all. Don't add
  another timer to this file.
- **No brand overrides for the dot color.** If a brand asks, the answer is
  no. Progress is a network property.
- **No inline decrypt.** Actions call your existing endpoints; unsealing is
  the client's job, not the card's. This file is a renderer, not a wallet.
