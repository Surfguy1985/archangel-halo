import React, { useEffect, useMemo, useRef, useState } from 'react';

/**
 * FalkonCard — the full-bleed card render, with a live waybill.
 *
 * One `FalkonCardData` object in, one card out. The six dots in the strip are
 * the whole point: they light as the OTHER party moves the card on THEIR
 * board, pushed over SSE, so both sides watch the same progress in real time.
 *
 * Drop-in:
 *   import { FalkonCard } from '@workspace/board-ui';
 *   <FalkonCard data={card} streamUrl={`/api/client/${token}/board/events`}
 *               onAction={(id) => act(card.code, id)} />
 *
 * Contract: schema/falkon-card.schema.json. The server builds this payload
 * per audience — never send an action the viewer can't take.
 *
 * Design notes that matter:
 *   - The dots are ALWAYS volt (#B4FF44), never the brand accent. Progress
 *     must read identically on every card in the network; brand owns the
 *     header, not the status.
 *   - A newly-lit dot animates once. Arriving stages ping; already-lit ones
 *     don't re-animate on re-render.
 *   - Optimistic advance: an action with `advancesTo` lights its dot at half
 *     opacity immediately, then the server's echo confirms it. If the echo
 *     never comes, the optimistic dot decays after 8s.
 */

/* ── Contract types (generated equivalents exist in orval; these mirror the schema) ── */
export const STAGE_ORDER = ['sealed', 'routed', 'delivered', 'opened', 'in_review', 'settled'] as const;
export type Stage = (typeof STAGE_ORDER)[number];

const STAGE_LABEL: Record<Stage, string> = {
  sealed: 'Sealed', routed: 'Routed', delivered: 'Delivered',
  opened: 'Opened', in_review: 'In review', settled: 'Settled',
};

export interface StageEntry { stage: Stage; at: string; note?: string | null; byLabel?: string | null }
export interface FalkonCardData {
  code: string;
  kind: string;
  title: string;
  subtitle?: string | null;
  brand: {
    name: string; logoUrl?: string | null; monogram?: string | null;
    gradientFrom?: string; gradientTo?: string; accent?: string; onDark?: boolean;
  };
  sealed?: boolean;
  recipientLabel?: string | null;
  waybill: {
    stages: StageEntry[]; slaHours?: number | null; stalledHours?: number | null;
    holder?: 'sender' | 'network' | 'recipient' | 'done'; live?: boolean;
  };
  amount?: { cents: number; currency?: string; label?: string } | null;
  lines?: Array<{ label: string; valueCents?: number | null; valueText?: string | null; emphasis?: boolean }>;
  meta?: Array<{ label: string; value: string }>;
  media?: Array<{ url: string; alt?: string | null; caption?: string | null }>;
  actions?: Array<{ id: string; label: string; style?: 'primary' | 'secondary' | 'danger'; advancesTo?: Stage | null; confirm?: string | null }>;
  footnote?: string | null;
}

const VOLT = '#B4FF44', INK = '#101C33', DEEP = '#0B1428', AMBER = '#FBBF24';

/* Module defaults — used when a brand doesn't override the gradient. */
const KIND_GRADIENT: Record<string, [string, string]> = {
  invoice: ['#2C7BF2', '#1B57C4'], payment: ['#2C7BF2', '#1B57C4'],
  work_order: ['#F97316', '#C2410C'], change_order: ['#E11D48', '#9F0F33'],
  check_in: ['#12B981', '#0B7F58'], loan_file: ['#8B5CF6', '#6023CE'],
  ticket: ['#DB2777', '#9D174D'], consult: ['#047857', '#065F46'],
  live_order: ['#1C1917', '#3A3430'], formation: ['#16294B', '#0D1B33'],
};

const money = (cents: number, currency = 'USD') =>
  new Intl.NumberFormat(undefined, { style: 'currency', currency, maximumFractionDigits: 0 }).format(cents / 100);

const HOLDER_CHIP: Record<string, string> = {
  sender: 'Your move', network: 'In transit', recipient: 'Their move', done: 'Complete',
};

/* ── Live stage subscription ─────────────────────────────────────────────────
   Listens to the board SSE stream and merges stage events for THIS code.
   Falls back silently when no streamUrl is given (static render, print, PDF). */
function useLiveStages(code: string, streamUrl: string | null, seed: StageEntry[]) {
  const [stages, setStages] = useState<StageEntry[]>(seed);
  const [pinged, setPinged] = useState<Stage | null>(null);
  const seenRef = useRef(new Set(seed.map((s) => s.stage)));

  // Re-seed when the server payload changes (query refetch).
  useEffect(() => {
    setStages((prev) => {
      const merged = new Map<Stage, StageEntry>();
      for (const s of [...prev, ...seed]) merged.set(s.stage, s);
      return [...merged.values()];
    });
    for (const s of seed) seenRef.current.add(s.stage);
  }, [seed]);

  useEffect(() => {
    if (!streamUrl) return;
    let es: EventSource | null = null;
    let stopped = false;
    let backoff = 1000;

    const open = () => {
      if (stopped) return;
      es = new EventSource(streamUrl, { withCredentials: true });
      es.onopen = () => { backoff = 1000; };
      es.addEventListener('waybill', (ev) => {
        try {
          const d = JSON.parse((ev as MessageEvent).data) as { code: string } & StageEntry;
          if (d.code !== code || !STAGE_ORDER.includes(d.stage)) return;
          setStages((prev) => (prev.some((s) => s.stage === d.stage)
            ? prev
            : [...prev, { stage: d.stage, at: d.at, note: d.note, byLabel: d.byLabel }]));
          if (!seenRef.current.has(d.stage)) {
            seenRef.current.add(d.stage);
            setPinged(d.stage);
            setTimeout(() => setPinged((p) => (p === d.stage ? null : p)), 1400);
          }
        } catch { /* ignore malformed frames */ }
      });
      es.onerror = () => {
        es?.close();
        if (stopped) return;
        setTimeout(open, backoff);
        backoff = Math.min(backoff * 2, 30_000);
      };
    };
    open();
    return () => { stopped = true; es?.close(); };
  }, [code, streamUrl]);

  return { stages, pinged };
}

/* ── The waybill strip ───────────────────────────────────────────────────── */
export function WaybillStrip({
  stages, pinged, optimistic, stalled, holder, live,
}: {
  stages: StageEntry[]; pinged?: Stage | null; optimistic?: Stage | null;
  stalled?: number | null; holder?: string; live?: boolean;
}) {
  const byStage = useMemo(() => {
    const m = new Map<Stage, StageEntry>();
    for (const s of stages) m.set(s.stage, s);
    return m;
  }, [stages]);

  const currentIdx = STAGE_ORDER.reduce((acc, s, i) => (byStage.has(s) ? i : acc), -1);

  return (
    <div className="fk-way" role="group" aria-label={`Waybill progress: ${STAGE_ORDER[Math.max(0, currentIdx)]}`}>
      <div className="fk-way-track">
        {STAGE_ORDER.map((s, i) => {
          const done = byStage.has(s);
          const isOptimistic = !done && optimistic === s;
          const isLead = i === currentIdx;
          const amber = isLead && !!stalled;
          const e = byStage.get(s);
          const tip = [
            STAGE_LABEL[s],
            e ? new Date(e.at).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : 'pending',
            e?.byLabel || e?.note || '',
          ].filter(Boolean).join(' · ');
          return (
            <React.Fragment key={s}>
              <span
                className={
                  'fk-dot' + (done ? ' on' : '') + (isOptimistic ? ' opt' : '') +
                  (amber ? ' amber' : '') + (pinged === s ? ' ping' : '')
                }
                title={tip}
                aria-label={tip}
              />
              {i < STAGE_ORDER.length - 1 && (
                <span className={'fk-line' + (i < currentIdx ? ' on' : '')} />
              )}
            </React.Fragment>
          );
        })}
      </div>
      <span className={'fk-way-stage' + (stalled ? ' stalled' : '')}>
        {stalled
          ? `Stalled ${stalled < 24 ? Math.round(stalled) + 'h' : Math.round(stalled / 24) + 'd'}`
          : STAGE_LABEL[STAGE_ORDER[Math.max(0, currentIdx)]]}
      </span>
      {holder && <span className={'fk-holder' + (holder === 'sender' ? ' you' : '')}>{HOLDER_CHIP[holder]}</span>}
      {live && <span className="fk-livedot" title="Live — updates as the other board moves" />}
    </div>
  );
}

/* ── The card ────────────────────────────────────────────────────────────── */
export function FalkonCard({
  data, streamUrl = null, onAction, className,
}: {
  data: FalkonCardData;
  streamUrl?: string | null;
  onAction?: (actionId: string) => void | Promise<void>;
  className?: string;
}) {
  const { stages, pinged } = useLiveStages(data.code, data.waybill.live === false ? null : streamUrl, data.waybill.stages);
  const [optimistic, setOptimistic] = useState<Stage | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  // Optimistic dot decays if the server never echoes.
  useEffect(() => {
    if (!optimistic) return;
    if (stages.some((s) => s.stage === optimistic)) { setOptimistic(null); return; }
    const t = setTimeout(() => setOptimistic(null), 8000);
    return () => clearTimeout(t);
  }, [optimistic, stages]);

  const g = (KIND_GRADIENT[data.kind] ?? ['#2C7BF2', '#1B57C4']);
  const from = data.brand.gradientFrom ?? g[0];
  const to = data.brand.gradientTo ?? g[1];
  const accent = data.brand.accent ?? VOLT;
  const onDark = data.brand.onDark !== false;

  const run = async (a: NonNullable<FalkonCardData['actions']>[number]) => {
    if (a.confirm && !window.confirm(a.confirm)) return;
    if (a.advancesTo) setOptimistic(a.advancesTo);
    setBusy(a.id);
    try { await onAction?.(a.id); } finally { setBusy(null); }
  };

  return (
    <article className={'fk-card' + (className ? ' ' + className : '')} data-code={data.code}>
      <style>{CARD_CSS}</style>

      <header
        className={'fk-head' + (onDark ? '' : ' light')}
        style={{ backgroundImage: `linear-gradient(135deg, ${from}, ${to})` }}
      >
        <div className="fk-head-top">
          {data.brand.logoUrl
            ? <img className="fk-logo" src={data.brand.logoUrl} alt={data.brand.name} />
            : <span className="fk-mono" style={{ borderColor: accent, color: accent }}>
                {data.brand.monogram ?? data.brand.name.slice(0, 2).toUpperCase()}
              </span>}
          <span className="fk-kind">{data.kind.replace(/_/g, ' ')}</span>
          {data.sealed !== false && (
            <span className="fk-seal" style={{ color: accent }}>
              <LockGlyph /> Sealed to {data.recipientLabel ?? 'you'}
            </span>
          )}
        </div>
        <h3 className="fk-title">{data.title}</h3>
        {data.subtitle && <p className="fk-sub">{data.subtitle}</p>}
      </header>

      <div className="fk-strip">
        <span className="fk-code">{data.code}</span>
        <WaybillStrip
          stages={stages}
          pinged={pinged}
          optimistic={optimistic}
          stalled={data.waybill.stalledHours}
          holder={data.waybill.holder}
          live={data.waybill.live !== false && !!streamUrl}
        />
      </div>

      {!!data.media?.length && (
        <div className="fk-media">
          {data.media.slice(0, 8).map((m, i) => (
            <figure key={i}>
              <img src={m.url} alt={m.alt ?? ''} loading="lazy" />
              {m.caption && <figcaption>{m.caption}</figcaption>}
            </figure>
          ))}
        </div>
      )}

      <div className="fk-body">
        {!!data.lines?.length && (
          <div className="fk-lines">
            {data.lines.map((l, i) => (
              <div className={'fk-line-row' + (l.emphasis ? ' em' : '')} key={i}>
                <span>{l.label}</span>
                <b>{l.valueCents != null ? money(l.valueCents, data.amount?.currency) : (l.valueText ?? '')}</b>
              </div>
            ))}
          </div>
        )}

        {data.amount && (
          <div className="fk-total">
            <span>{data.amount.label ?? 'Total due'}</span>
            <b>{money(data.amount.cents, data.amount.currency)}</b>
          </div>
        )}

        {!!data.meta?.length && (
          <div className="fk-meta">
            {data.meta.map((m, i) => (
              <span key={i}><i>{m.label}</i>{m.value}</span>
            ))}
          </div>
        )}

        {!!data.actions?.length && (
          <div className="fk-actions">
            {data.actions.map((a) => (
              <button
                key={a.id}
                className={'fk-btn fk-' + (a.style ?? 'primary')}
                onClick={() => run(a)}
                disabled={busy !== null}
              >
                {busy === a.id ? 'Working…' : a.label}
              </button>
            ))}
          </div>
        )}

        {data.footnote && <p className="fk-foot"><LockGlyph /> {data.footnote}</p>}
      </div>
    </article>
  );
}

function LockGlyph() {
  return (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth="2.4" strokeLinecap="round" aria-hidden="true" style={{ verticalAlign: '-1px' }}>
      <rect x="4" y="11" width="16" height="10" rx="2" /><path d="M8 11V7a4 4 0 0 1 8 0v4" />
    </svg>
  );
}

/* ── Styles. Scoped to .fk-*; safe beside Tailwind. Tokens mirror web/tokens.css ── */
const CARD_CSS = `
.fk-card{--fk-volt:${VOLT};--fk-ink:${INK};--fk-deep:${DEEP};--fk-amber:${AMBER};
  --fk-line:#E4E7EC;--fk-slate:#4A5568;--fk-mute:#8A94A6;
  display:flex;flex-direction:column;background:#fff;border-radius:16px;overflow:hidden;
  font-family:Inter,system-ui,-apple-system,sans-serif;color:var(--fk-ink);
  box-shadow:0 1px 2px rgba(16,28,51,.07),0 12px 32px rgba(16,28,51,.10);
  font-feature-settings:'tnum' 1;contain:content}
.fk-card *{box-sizing:border-box}

.fk-head{padding:14px 16px 15px;color:#fff}
.fk-head.light{color:var(--fk-ink)}
.fk-head-top{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.fk-logo{height:22px;max-width:96px;width:auto;object-fit:contain;background:rgba(255,255,255,.93);
  border-radius:6px;padding:3px 6px}
.fk-mono{width:24px;height:24px;border-radius:7px;border:1.5px solid;display:grid;place-items:center;
  font-size:10px;font-weight:800;letter-spacing:-.02em;flex-shrink:0}
.fk-kind{font-size:9px;font-weight:800;letter-spacing:.09em;text-transform:uppercase;
  background:rgba(255,255,255,.2);padding:3px 8px;border-radius:6px}
.fk-head.light .fk-kind{background:rgba(16,28,51,.1)}
.fk-seal{display:inline-flex;align-items:center;gap:4px;margin-left:auto;font-size:9px;font-weight:750;
  background:rgba(11,20,40,.42);padding:3px 8px;border-radius:6px;white-space:nowrap}
.fk-title{font-size:16px;font-weight:700;letter-spacing:-.02em;line-height:1.25;margin:11px 0 0}
.fk-sub{font-size:11px;line-height:1.4;opacity:.85;margin:3px 0 0}

.fk-strip{display:flex;align-items:center;gap:10px;padding:9px 16px;background:var(--fk-deep);color:#fff;
  flex-wrap:wrap}
.fk-code{font-family:ui-monospace,'SF Mono',Menlo,monospace;font-size:10px;font-weight:700;
  letter-spacing:.08em;color:var(--fk-volt);flex-shrink:0}
.fk-way{display:flex;align-items:center;gap:9px;flex:1;min-width:190px}
.fk-way-track{display:flex;align-items:center;flex:1;min-width:110px}
.fk-dot{width:7px;height:7px;border-radius:50%;background:#26344F;flex-shrink:0;cursor:help;
  transition:background .45s ease,box-shadow .45s ease}
.fk-dot.on{background:var(--fk-volt);box-shadow:0 0 8px rgba(180,255,68,.55)}
.fk-dot.opt{background:var(--fk-volt);opacity:.45}
.fk-dot.amber{background:var(--fk-amber);box-shadow:0 0 8px rgba(251,191,36,.5);animation:fkblink 1.3s infinite}
.fk-dot.ping{animation:fkping 1.3s ease-out 1}
.fk-line{flex:1;height:1.5px;min-width:6px;background:#26344F;margin:0 2px;transition:background .45s ease}
.fk-line.on{background:var(--fk-volt)}
@keyframes fkping{0%{transform:scale(1);box-shadow:0 0 0 0 rgba(180,255,68,.85)}
  70%{transform:scale(1.6);box-shadow:0 0 0 9px rgba(180,255,68,0)}
  100%{transform:scale(1);box-shadow:0 0 8px rgba(180,255,68,.55)}}
@keyframes fkblink{0%,100%{opacity:1}50%{opacity:.4}}
.fk-way-stage{font-size:9px;font-weight:800;letter-spacing:.07em;text-transform:uppercase;color:#93A5CB;
  white-space:nowrap}
.fk-way-stage.stalled{color:var(--fk-amber)}
.fk-holder{font-size:8.5px;font-weight:800;letter-spacing:.05em;text-transform:uppercase;color:#93A5CB;
  background:rgba(255,255,255,.08);padding:2px 7px;border-radius:8px;white-space:nowrap}
.fk-holder.you{color:var(--fk-ink);background:var(--fk-volt)}
.fk-livedot{width:6px;height:6px;border-radius:50%;background:var(--fk-volt);flex-shrink:0;
  animation:fkblink 2s infinite}

.fk-media{display:flex;gap:2px;overflow-x:auto;scroll-snap-type:x mandatory}
.fk-media figure{margin:0;flex:0 0 44%;scroll-snap-align:start;position:relative;min-width:0}
.fk-media img{display:block;width:100%;height:112px;object-fit:cover}
.fk-media figcaption{position:absolute;left:0;right:0;bottom:0;padding:12px 8px 5px;font-size:9px;
  font-weight:650;color:#fff;background:linear-gradient(transparent,rgba(11,20,40,.8))}

.fk-body{padding:14px 16px 15px}
.fk-lines{display:flex;flex-direction:column}
.fk-line-row{display:flex;justify-content:space-between;gap:14px;padding:7px 0;font-size:12.5px;
  color:var(--fk-slate);border-bottom:.5px solid var(--fk-line)}
.fk-line-row b{color:var(--fk-ink);font-weight:650;letter-spacing:-.015em;white-space:nowrap}
.fk-line-row.em{font-weight:650;color:var(--fk-ink)}
.fk-total{display:flex;justify-content:space-between;align-items:baseline;gap:14px;padding:11px 0 4px}
.fk-total span{font-size:12.5px;font-weight:700}
.fk-total b{font-size:19px;font-weight:750;letter-spacing:-.028em}
.fk-meta{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
.fk-meta span{font-size:10px;font-weight:650;background:#F4F6F9;border-radius:7px;padding:5px 9px;
  color:var(--fk-slate)}
.fk-meta i{font-style:normal;color:var(--fk-mute);margin-right:5px;text-transform:uppercase;
  letter-spacing:.05em;font-size:8.5px;font-weight:800}
.fk-actions{display:flex;gap:8px;margin-top:14px}
.fk-btn{flex:1;padding:12px;border:none;border-radius:11px;font-family:inherit;font-size:13px;
  font-weight:750;cursor:pointer;transition:transform .14s ease,opacity .14s ease}
.fk-btn:hover:not(:disabled){transform:translateY(-1px)}
.fk-btn:disabled{opacity:.55;cursor:default}
.fk-btn:focus-visible{outline:2px solid #2C7BF2;outline-offset:2px}
.fk-primary{background:var(--fk-ink);color:#fff}
.fk-secondary{background:#F4F6F9;color:var(--fk-ink)}
.fk-danger{background:#FDECF0;color:#9F0F33}
.fk-foot{display:flex;align-items:flex-start;gap:6px;font-size:9.5px;line-height:1.45;color:var(--fk-mute);
  font-weight:600;margin:12px 0 0}
.fk-foot svg{flex-shrink:0;margin-top:2px}

@media (prefers-reduced-motion: reduce){
  .fk-card *{animation:none !important;transition:none !important}
}
@media print{
  .fk-card{box-shadow:none;border:1px solid var(--fk-line)}
  .fk-livedot,.fk-actions{display:none}
}
`;

export default FalkonCard;
