# Halo — Master Build Spec

Everything in one place: the daily-run wizards, the client board, the design system, the backend, and the density split between surfaces.

Companion file: `BoardCard.jsx` — the production card and rail components with containment rules.

---

## The thesis

Halo is not a CRM with a client portal bolted on. It's **one loop, rendered at three densities.**

A property manager requests work. A coordinator assigns or broadcasts it. A crew does it. An invoice generates itself from that property's SOP, carrying the PO and the right line items. The client approves and pays. Every state change moves a card on both boards at the same time.

The product's entire value is that this loop has no gaps a human has to bridge with a phone call. The design's entire job is to make each participant's slice of it feel like the only thing on screen.

---

## Three surfaces, one system

| Surface | Who | Session | Density | Primitive |
|---|---|---|---|---|
| **Ops board** | Your coordinator | All day | Compact | Row, 52px, status spine |
| **Client board** | Property manager | 3 min/week | Comfortable | Tile, 144px, artwork panel |
| **Crew app** | Crew on site | Per job | Comfortable | One job, full screen, 3 buttons |

Identical across all three: color tokens, type scale, tabular numerals, motion curve, copy voice, status vocabulary, and the detail sheet.

Different: density, primitive, keyboard support, and bulk actions.

That split — same system, different density — is the single most important architectural decision in this document. Implement it as one `data-density` switch on the root, not as two component libraries.

---

## The seven rules everything else derives from

1. **One decision per screen.** Never two questions on one card.
2. **Nothing starts blank.** Every field arrives pre-filled. The user confirms; they don't type.
3. **Three depths maximum.** Board → sheet → wizard step. There is no fourth.
4. **One primary button per surface.** Two dark buttons means one is wrong.
5. **Color encodes status and nothing else.** Brand color is the primary button and the logo.
6. **Cards move themselves.** The work moves the card, not the user. No drag and drop.
7. **If you deleted one element, would anyone notice?** If no — delete it. Run this on every screen, twice.

---

## Unified build order

Across all the parts below, in dependency order. Each step is shippable.

**Foundation**
1. Extract the shared token layer — color, type, motion, density — into one file both sides read
2. `board_cards` denormalized projection + `GET /board/:propertyId`
3. Event log + server-side state machine

**Client side**
4. Rails renderer, phone layout first, desktop as a flex-direction swap
5. Card sheet with prefetched payload
6. The four client actions with optimistic writes
7. SSE deltas patching the query cache
8. Request wizard, three steps

**Ops side**
9. `<Row>` at compact density from the same tokens as `<Tile>`
10. Ops board: filter chips + one list, kills the view switcher
11. Keyboard map
12. Run-a-Job wizard, Steps 1–3

**The hard one**
13. Invoice generator — SOP → price list → PO → branded template, four output surfaces
14. Change order mini-wizard
15. Bulk invoice on the ops side

**Finish**
16. Offline + service worker
17. Notification service with the four-alert cap
18. Crew app
19. Personalized rail ordering

Step 13 is the product. Steps 1–12 are the surface it lives on. If the SOP → invoice chain doesn't work, nothing else matters; if it does, the rest is plumbing you already know how to build.

---

## Master ship checklist

No screen goes live until all ten pass.

1. Can a first-time user complete this without instruction?
2. Is there exactly one primary button?
3. Does every field arrive pre-filled?
4. Is the deepest path three levels or fewer?
5. Does the card transition into the sheet, not fade?
6. Are there three or fewer colors on screen?
7. Does it hold at 320px with a 40-character property name and a `$104,280.00` amount?
8. Does every number use tabular figures?
9. Does it work in dark mode and at 200% text zoom?
10. If you deleted one element, would anyone notice?

---
---


# PART ONE — RUNNING A JOB (OPS WIZARD)

Two wizards. One for your crew side (Ops Board), one for the client side (Client Board). Everything after setup is done inside these two.

---

### Design rules (non-negotiable)

1. **One decision per screen.** Never two questions on one card.
2. **Nothing starts blank.** Every field arrives pre-filled from the property, the SOP, or the last job. The user is confirming, not typing.
3. **Max 4 taps to done.** If a path takes 5, kill a step.
4. **One primary button.** Big, dark, bottom-right. Secondary is text-only. No third option.
5. **Back is always free.** No confirm dialogs to go back. Nothing saves destructively until "Send."
6. **The wizard never blocks.** If something's missing (PO, price list, COI), the step still completes and the missing item shows as a single amber chip you can resolve later. Only *Send Invoice* hard-blocks.
7. **No modals inside modals.** The wizard is one full-height sheet that slides. Steps slide left/right within it.

---

## WIZARD A — Run a Job (Ops side)

Entry point: one button on the Ops Board header. **`Run a Job`**

---

#### Step 1 — Open or New

Single screen, two big cards.

**`Open a Job`**
Opens a list, sectioned:
- **New Requests** — inbound from connected properties (badge count, red dot). These already carry PO, units, scope, deadline, budget from the client.
- **Active Jobs** — anything in flight, sorted by deadline.
- **Needs Invoice** — completed, not yet billed.

Tap a row → jumps straight to the step that job is actually on. A new request lands on Step 3 (crew). A completed job lands on Step 5 (invoice). **Never make them walk steps they've already passed.**

**`Create New Job`**
→ Step 2.

---

#### Step 2 — Pick the Property *(new jobs only)*

Search-first list of active properties. Recent 5 pinned at top.

Selecting a property silently loads, in the background:
- its uploaded SOP + extracted rules
- its price list / line-item catalog
- its open PO numbers
- its approved crew list and any exclusions
- its invoice branding template

Then one compact scope card:
- **Units** — chip input, pulls that property's unit roster (`204`, `310`, `Bldg C Common`)
- **Scope** — dropdown of SOP-defined service types, plus free text
- **Deadline** — date, defaulted from the SOP's standard turn time
- **PO Number** — dropdown of that property's open POs, or manual. If empty, an amber chip: *"PO needed before invoicing."* Does not block.

Primary: **`Next`**

---

#### Step 3 — Crew

Two cards again. This is the fork.

**`Assign Directly`**
Your bench for this property, each row: name, trade, distance, current load, rating, COI status. Tap one → assigned. Done.

**`Broadcast`**
Filter sheet, all toggles pre-set to sane defaults:
- Trade (from scope)
- Radius (default 25 mi)
- Rating floor (default 4.0)
- COI valid (on, locked if SOP requires it)
- Available before deadline (on)
- Price ceiling (defaults to the property's price-list rate for that scope)

Live counter under the filters: **"Matches 14 crews."** Adjust filters, number moves.

Then pick one:
- **First to accept wins** — instant, good for turns and make-readies
- **Collect bids, 2 hr window** — you pick the winner; good for big scope

Primary: **`Broadcast to 14`**

Once broadcast, the job card sits in *Awaiting Crew* and you get pushed the moment someone accepts or bids land.

---

#### Step 4 — Job Runs

No wizard here. The job card on the board is the interface. It shows live GPS, before/after photos, crew messages, and a completion checklist derived from the SOP scope.

The **only** thing that matters: when the crew marks complete + required photos are in, the card flips to **`Ready to Invoice`** and a chip appears on it. That chip is the entry into Step 5.

---

#### Step 5 — Invoice (the branded wizard)

This screen should feel like it did the work already, because it did.

Auto-generated on open, from the SOP rule for that property:
- Correct branded template (their required format, your colors/logo where allowed)
- **PO number stamped in the header** — the field their AP system keys on
- **Line items pulled from that property's price list**, matched to the scope performed and the units serviced
- Quantities from the completion checklist
- Any SOP-mandated fields: work order ref, unit numbers, date of service, tech name, before/after photo attachments
- Totals validated against the SOP's caps — anything over shows a single amber line: *"Exceeds SOP cap for Paint — needs change order."*

The user's entire job on this screen is: scroll, tap a line if it's wrong, confirm.

Edits allowed: quantity, remove a line, add a line (from the price list only — no free-typed prices, this is what keeps invoices clean).

Hard blocks on send (only these three):
1. Missing PO number
2. A line item with no price-list match
3. A required SOP photo missing

Each block is a tappable chip that jumps straight to the fix.

Primary: **`Send Invoice`**

---

#### Step 6 — Automatic

Nothing for the user to do. On send:

1. Invoice posts to that client's Kanban board in the **Awaiting Approval** column
2. Client gets alerted — push, email, and a board badge
3. Your board card moves to **Invoiced**
4. Payment rail is armed and waiting on their approval
5. Job, photos, invoice, and PO archive together under that property

Confirmation screen: green check, invoice number, PO number, amount, "Sent to [Property] · [Contact]." One button: **`Done`**.

---

## WIZARD B — Client Board

Same design language, mirrored. Three things they ever do.

---

### B1 — Request Work

One button on their board: **`Request Work`**

**Screen 1 — What & Where**
- **Units** — chip input from their own unit roster (`204`, `310`, `Bldg C`). Required.
- **Scope** — service type list (matches your SOP categories) + free text + photo attach. Required.

**Screen 2 — When & How Much**
- **Deadline** — date picker, with quick chips: *Today · 48 hrs · This week · Pick a date*. Required.
- **Budget** — amount, pre-filled with the price-list estimate for that scope × those units, editable. Required.

**Screen 3 — PO**
- **PO Number** — dropdown of their open POs or manual entry. Required.
- Everything above shown as a compact summary to confirm.

Primary: **`Send Request`**

That request lands in your **New Requests** queue with PO, units, scope, deadline, and budget already attached — which is exactly why Step 2 on your side is skippable for inbound work.

---

### B2 — Approve an Invoice

The invoice card arrives in **Awaiting Approval**. Tap it.

One screen, top to bottom:
- PO number, invoice number, amount — large
- Line items with unit numbers
- Before/after photos, swipeable
- Original request shown side-by-side, so they can see scope requested vs. scope billed
- A green check if the total is at or under the budget they set; amber note with the delta if it's over

Two buttons only:
- **`Approve`** — primary
- **`Dispute`** — text button, opens a one-field sheet: *what's wrong?* → routes straight back to your board as a flagged card, no email chain

---

### B3 — Pay

Approval and payment are one continuous motion, not two errands.

On approve, the card slides to **Pay** and shows:
- Amount, PO number, due date from their terms
- Their saved payment method
- One button: **`Pay $4,280`**
- Text link: *Schedule for [due date]*

On payment: card moves to **Paid**, receipt attaches to the PO, your board card moves to **Paid**, funds route through your rails.

---

## Automation map

| Trigger | What fires |
|---|---|
| Client sends request | Card lands in your New Requests with PO/units/scope/deadline/budget; you're alerted |
| You broadcast | Matching crews pushed; first-accept or bid window opens |
| Crew accepts | Card → Assigned; client's board card updates to *Scheduled* |
| Crew marks complete + photos in | Card → Ready to Invoice; invoice pre-generates from SOP |
| You send invoice | Client board → Awaiting Approval; client alerted; rail armed |
| Client approves | Card → Pay on their side, Approved on yours |
| Client pays | Both boards → Paid; receipt attaches to PO; funds route |

---

## Build order — the wizards

1. **Step 5, the invoice generator.** It's the hardest and everything else is plumbing around it. If the SOP → price list → PO → branded template chain works, the product works.
2. **Wizard B1, the request form.** Five required fields. It's what makes your Step 2 disappear for inbound work.
3. **Step 1 routing** — the "jump to the step this job is actually on" logic. This is what makes it feel Apple instead of feeling like a form.
4. **Step 3 broadcast + filters.**
5. **B2/B3 approve-and-pay.**
6. **The automation map** — wire it last, once each stage is solid on its own.

---

## Microcopy

Short, plain, no exclamation marks. A few to set the tone:

- `Run a Job`
- `3 new requests from Ridgeview`
- `Matches 14 crews`
- `Broadcast to 14`
- `Ready to invoice`
- `PO needed before invoicing`
- `Exceeds SOP cap for Paint — needs change order`
- `Sent to Ridgeview Apartments · Dana M.`
- `Paid · Receipt attached to PO 88214`

---


# PART TWO — THE POLISH LAYER

Part One covers *what happens*. This covers *why it feels like Apple built it.*

The premise: your CRM is busy. Nothing below adds a feature. Most of it removes one.

---

### 1. The subtraction pass — do this first

Apple's product method is deletion. Before building anything new, run your CRM through these five cuts.

**Cut the sidebar to four items.** Whatever your nav is now, it's too long. It becomes: `Board · Properties · Crews · Money`. Everything else is a destination *inside* one of those four, reached by tapping an object — not by a nav link. If someone asks "where did Reports go?", the answer is: it's a card on the board now.

**Cut the board to one view.** Not "My Jobs / All Jobs / Team View / Calendar." One board, with a filter chip row. Filters are chips, not views.

**Three lines per card, maximum.** Line 1: property + units. Line 2: scope. Line 3: status + owner avatar. Everything else lives in the sheet. Your cards are almost certainly carrying 6–8 lines today and it's why the board feels heavy.

**One primary action per surface.** If a screen has two dark buttons, one of them is wrong. Demote it to a text link or move it into the overflow.

**Delete every count badge that isn't actionable.** "47 properties" is decoration. "3 new requests" is a job. Keep the second, kill the first.

---

### 2. One home, three depths

Never more than three levels deep, ever. This is the single biggest driver of "it feels simple."

- **Depth 1 — the board.** Cards. Always the home. The only full page.
- **Depth 2 — the peek.** Tap a card, a sheet slides up covering ~85%. Everything about that job: photos, GPS, messages, timeline, invoice. Swipe down to dismiss. The board is still visible behind it, so you never feel lost.
- **Depth 3 — the wizard.** A step sequence *inside* the sheet, sliding left/right.

There is no depth 4. If you need one, you've designed the sheet wrong.

**No page navigations after login.** The URL can change, but the board never unmounts. This is what makes it feel like an app instead of a website.

---

### 3. Motion

Motion is 80% of "expensive." Get these five right and it reads as premium before a single pixel changes.

- **One easing curve everywhere.** Spring, roughly `cubic-bezier(0.32, 0.72, 0, 1)`. Never linear, never ease-in-out.
- **Shared element transitions.** When a card opens, the card *becomes* the sheet — it grows from its position on the board. It does not fade out and a new panel fade in. This one detail does more than any other for the Apple feel.
- **240ms for sheets, 180ms for steps, 120ms for state changes.** Anything over 300ms feels sluggish. Anything under 100ms feels broken.
- **Everything is interruptible.** If someone swipes down mid-open, it reverses from where it is. No animation that must finish.
- **Haptics only on commit.** Broadcast sent, invoice sent, payment made. Not on taps, not on scroll, not on step transitions. Rarity is what makes it feel meaningful.

---

### 4. Type, space, color

- **One type scale, five sizes.** 28 / 20 / 16 / 14 / 12. Nothing else exists.
- **Two weights.** Regular and medium. Never bold.
- **8pt grid.** Every margin and padding is a multiple of 8. No 13px, no 22px.
- **Color carries exactly one job: status.** Your brand color is for the primary button and the logo. Everything else is black, gray, white — plus green for done, amber for needs-attention, red for blocked. A card with three colors on it is a broken card.
- **Hairline borders, no shadows.** Shadows on cards read as 2014. Use a 0.5px border and let whitespace do the separating.
- **Numbers are the loudest thing on any money screen.** The invoice total at 32px, everything else at 13–15px. That hierarchy is why the approval screen above reads instantly.

---

### 5. Defaults — the "it already knows" layer

This is where you actually beat Trello and Monday. They're generic. You're not.

Per property, remember and pre-fill:
- Last crew used for each scope type → the "Assign" list is sorted by who's done this here before
- Standard turn time from the SOP → the deadline picker defaults correctly
- Typical unit set for recurring work
- Usual PO pattern
- Their preferred contact for invoice delivery

Then add one button on the job creation screen: **`Same as last time`**. For turns and make-readies — which is most of your volume — it fills everything in one tap. The user's whole job becomes changing the unit number.

Rule: if the system has seen a value twice, it should never ask for it a third time.

---

### 6. Command bar

One input, ⌘K on desktop and a search field at the top of the board on mobile. It does everything:

- Type a unit number → jumps to that job
- Type a property name → filters the board
- Type "invoice 4417" → opens it
- Type "new job Ridgeview" → starts the wizard, property pre-selected

This is what lets you cut the nav to four items without losing anyone. Power users stop touching the UI entirely; new users never discover it and don't need to.

---

### 7. Notification discipline

The fastest way to make your client feel like your software is heavy is to send them things. Cap it hard.

**The client gets exactly four push alerts, ever:**
1. Your request was accepted — crew scheduled for [date]
2. Work complete — photos ready
3. Invoice ready to approve — $X on PO Y
4. Payment due in 3 days

**Everything else becomes one Monday morning digest card** that appears on their board: what happened last week, what's open, what's owed. Not an email. A card, on the board they already use.

Same discipline on your side: alerts for crew accepted, crew stuck/no-show, client disputed, payment received. Nothing else.

---

### 8. Zero-training client onboarding

A property manager should never attend a training call. First time they open their board:

- The board is **not empty.** Their first request from you is already staged as a card, or a sample card that says "This is what a job looks like. Tap it."
- **One coach mark, one time:** an arrow at the `Request Work` button. Dismissed forever after first tap.
- **No settings on day one.** Their branding, contacts, and PO list come pre-populated from your setup. If they need a settings screen in week one, you configured it wrong.

Target: first request submitted within 90 seconds of first login, with no help.

---

### 9. Optimistic and offline

Your crews are in basements, stairwells, and parking garages.

Every action commits to the UI **instantly** and syncs in the background. Photo upload, status change, message — all show as done immediately, with a tiny sync indicator that only appears if it's taking more than 3 seconds. Failures retry silently and surface only after three attempts.

Never a spinner blocking the screen. Never "saving…" as a modal.

---

### 10. One invoice object, four surfaces

The invoice must look **identical** on the board card, in the PDF, in the email, and printed. Same layout, same branding, same field order. Property managers forward these into AP systems and staple them to POs — any drift between surfaces creates a support call and, worse, a rejected invoice.

Build the invoice as one render target with four output modes. Not four templates.

---

### 11. Change order mini-wizard

When Step 5 hits an SOP cap, the amber chip needs a path. Three screens, same design rules:

1. **What changed** — pre-filled with the overage line and the delta. Free text for why. Photos attach automatically from the job.
2. **New total** — old total, change amount, new total. One line each.
3. **Confirm** — one button: `Request approval`.

It pushes a **change order card** to the client board, above the invoice, with a single Approve/Decline. On approve, the invoice unblocks and sends automatically. The client never sees an invoice they didn't already agree to — which is the entire reason invoices get sat on for 45 days.

---

### 12. Status language

Kill every internal string. Status is a plain phrase, present tense, that a human would say out loud.

| Never show | Show instead |
|---|---|
| `PENDING_ASSIGNMENT` | Finding a crew |
| `IN_PROGRESS` | Crew on site |
| `COMPLETED_UNBILLED` | Ready to invoice |
| `INV_SENT_AWAITING_APPROVAL` | Waiting on Ridgeview |
| `PAYMENT_SETTLED` | Paid |
| `EXCEPTION_SOP_VIOLATION` | Over the SOP cap |

Note the fourth one — on your board, name the person or property you're waiting on, not the abstract state. It's the difference between a status and an answer.

---

### 13. Empty states teach

No blank screens. Ever. Each empty column says what belongs there and offers the one action that fills it.

- Awaiting crew, empty → "Nothing waiting on a crew. Nice." (no button)
- New requests, empty → "No new requests. Create a job instead." + button
- Client board, no invoices → "Invoices land here when work is done."

Tone: short, plain, no exclamation marks, no illustrations of empty boxes.

---

### 14. The money moment

Payment is the emotional peak of your product. Treat it like Apple Pay does.

On payment success: a single check mark animation, one haptic, the amount, and the PO number. No confetti, no modal to dismiss — it auto-dismisses after 1.5 seconds back to the board, where the card has already moved to Paid.

On your side: same moment, arriving as a live board update. Money landing should be something you *see happen*, not something you discover in a report.

---

### 15. Mobile is the client's primary device

Property managers are walking units, not sitting at a desk. Their board is mobile-first.

- Every primary action in the bottom third of the screen, reachable by thumb
- Approve and Pay are never side-by-side small buttons — full-width, stacked, 48px tall minimum
- Photos are swipeable full-bleed, not a grid of thumbnails
- The board scrolls vertically as one column on phone. Kanban columns become a segmented chip row at the top.

---

### Ship checklist — the short form

The master checklist at the top of this document is the full version. Day to day, these seven catch almost everything:

1. Can a first-time user complete this without instruction?
2. Is there exactly one primary button?
3. Does every field arrive pre-filled?
4. Is the deepest path three levels or fewer?
5. Does the card transition into the sheet, not fade?
6. Are there three or fewer colors on screen?
7. If you deleted one element, would anyone notice? If no — delete it.

Number seven is the whole method. Run it on every screen, twice.

---


# PART THREE — THE CLIENT BOARD (DESIGN + BACKEND)

The property manager's entire experience. Trello's model, Netflix's surface, a phone's ergonomics. Front to back.

---

## The surface

### 1. The core move: rails, not columns

A Trello column and a Netflix rail hold the same thing — an ordered set of cards in one state. Trello stacks them vertically and scrolls sideways; Netflix lays them horizontally and scrolls down. **The Netflix orientation is the one that works on a phone**, because thumbs scroll down naturally and sideways only within a rail.

So:

- **Phone (their primary device):** horizontal rails, stacked vertically. Scroll down through states, swipe sideways within one.
- **Desktop:** the exact same data, rendered as vertical columns. Same components, different flex direction.

This is one board with two layouts, not two products. Rail order = pipeline order.

### 2. The five rails

In this order, always:

1. **Needs you** — invoices to approve, change orders, disputes, anything blocked on them. *This rail is the entire point of the product.*
2. **In progress** — crew scheduled or on site
3. **Requested** — submitted, not yet accepted
4. **Done** — completed, invoiced, unpaid
5. **Paid** — collapses to a single summary tile after 30 days

**Needs you is always first and never hidden.** When it's empty, it shows one line — "Nothing needs you right now" — and the rail collapses to that line's height. Empty rails collapse; they don't disappear (position teaches the pipeline).

**Netflix personalization, applied honestly:** rail *order* below Needs you adapts to what this user actually touches. A regional manager who lives in invoices sees Done before In progress. A site manager who watches crews sees the reverse. Learned from tap counts over 30 days, recalculated weekly, never announced.

### 3. The card is a tile

Netflix cards are image-first, and yours can be too — you already have photos.

- **Top 60%: artwork.** The most recent job photo. Before/after work has real imagery; use it. No photo yet → a flat status tint with a single icon, never a gray placeholder box.
- **Bottom 40%: two lines only.** Line 1 is the object (unit number, or dollar amount for money cards). Line 2 is the state plus the one number that matters (`Crew on site · 2 hrs`, `Approve · PO 88214`).
- **172×144 on phone**, two-and-a-bit visible per rail so the third peeks — the peek is what tells the thumb it can swipe.
- **The accent border is reserved.** Only cards in Needs you get `border-accent`. Everywhere else, hairline gray. Accent means "this one is on you."

No badges, no avatars, no due-date pills, no labels. Trello's card is dense because Trello doesn't know what's on it. Yours does.

### 4. Three gestures, total

- **Tap** → card grows into the detail sheet
- **Swipe down** → dismiss the sheet
- **Swipe sideways** → move along a rail

That's it. **No drag-to-move-column.** This is the big departure from Trello and it's correct: the client doesn't move cards, the *work* moves cards. Drag-and-drop is a power-user affordance that creates anxiety about whether you've broken something. Cards move themselves; the client only ever acts, and acting is a button.

### 5. Zero chrome

What is *not* on the client's screen:

- No sidebar
- No settings gear (settings live one level into their profile avatar, and contain four things: contacts, payment method, PO list, notifications)
- No filters or sort controls (search covers it)
- No view switcher
- No "boards" plural — they have one board per property, switched by tapping the property name in the header
- No help button, no onboarding checklist, no progress meter, no tour

Header is: property name, search icon. Footer is: one button, `Request work`. That's the whole frame.

### 6. Four screens exist. That's all.

1. **The board** (rails)
2. **The card sheet** (detail — job, invoice, or change order; same sheet, different content)
3. **The request wizard** (3 steps, from the wizard spec)
4. **Profile** (four settings)

If you find yourself designing a fifth, it belongs inside one of these.

### 7. Netflix's real lesson

It isn't the rails. It's that Netflix opens to *content*, not to a dashboard. No summary stats, no charts, no "welcome back." The first thing on screen is a thing you can act on.

Your client board opens to the Needs you rail. If they have an invoice waiting, it is the first pixel they see. Nothing above it.

---

## The backend

Built for the existing stack: Drizzle, orval/OpenAPI, TanStack Query, SSE.

### 8. The read model — one query per board

Do not assemble the board from six endpoints on the client. That's where "overwhelming" comes from — six loading states, six failure modes, waterfall latency.

Maintain a **denormalized board projection**: one row per card, holding everything the tile and its sheet need. Updated by the event handler on every state change, read by a single query.

```
board_cards
  id, property_id, job_id, invoice_id
  rail            -- needs_you | in_progress | requested | done | paid
  rail_position   -- integer, for stable ordering
  title           -- "Unit 204" or "$4,280"
  subtitle        -- "Crew on site · 2 hrs"
  artwork_url     -- latest job photo, pre-resized
  accent          -- boolean, drives the border
  action          -- null | approve_invoice | approve_change_order | pay
  po_number
  amount_cents
  updated_at
  payload         -- jsonb, everything the sheet renders
```

One index on `(property_id, rail, rail_position)`. The entire board is one query, sub-50ms, no joins at read time. All the expensive work happens on write, which is rare; reads are constant.

### 9. Event log is the source of truth

Every state change is an append-only event. The projection is derived and rebuildable.

```
job_events
  id, job_id, type, actor_id, actor_role, payload jsonb, created_at
```

Event types: `requested · accepted · scheduled · crew_arrived · work_completed · photos_uploaded · invoice_generated · invoice_sent · change_order_raised · change_order_approved · invoice_approved · invoice_disputed · payment_initiated · payment_settled`

Why this matters beyond engineering hygiene: it gives the client a **timeline** in the card sheet for free, and it gives you dispute evidence, SLA metrics, and the benchmark data your card-network strategy depends on. Build it once, use it four ways.

### 10. State machine, enforced server-side

```
requested → accepted → scheduled → in_progress → completed
         → invoiced → approved → paid

completed → change_order_pending → completed   (loop)
invoiced  → disputed → invoiced                (loop)
```

Legal transitions live in one server-side table. The client never sends a state — it sends an *intent* (`approve`, `dispute`, `pay`), and the server decides what that means. This is what makes the UI safe to make simple: no client-side rule can be wrong, because the client has no rules.

### 11. API surface — nine endpoints

Small on purpose. Every one of these is a card in the OpenAPI spec and codegens through orval.

```
GET  /board/:propertyId              → all rails, one payload
GET  /cards/:cardId                  → sheet detail
POST /requests                       → create work request
POST /invoices/:id/approve
POST /invoices/:id/dispute
POST /change-orders/:id/decide       → approve | decline
POST /payments                       → initiate
GET  /search?q=                      → units, POs, invoices, jobs
GET  /stream/:propertyId             → SSE
```

If a tenth endpoint is needed for the client board, the design is wrong. This constraint is load-bearing — it's what keeps the surface small.

### 12. Realtime

SSE on `/stream/:propertyId`, one connection per open board. It pushes **projection deltas**, not raw events:

```json
{ "type": "card.moved", "cardId": "…", "rail": "needs_you", "position": 0 }
{ "type": "card.updated", "cardId": "…", "subtitle": "Crew on site · 2 hrs" }
{ "type": "card.added", "card": { … } }
```

The client patches its TanStack Query cache directly from these — no refetch. The card animates to its new rail while they're looking at it. That live movement is a large part of why it will feel like an app rather than a web page.

Reconnect with exponential backoff; on reconnect, refetch `/board/:propertyId` once and replace the cache wholesale. Don't try to replay missed events on the client.

### 13. Optimistic writes and idempotency

Every mutating endpoint takes an `Idempotency-Key` header (client-generated UUID). Retries are free and safe — critical for payment.

TanStack Query optimistic pattern on all four client actions:

1. Cancel in-flight queries for that card
2. Snapshot, then patch the cache immediately (card visibly moves rails)
3. Fire the mutation
4. On error, roll back and surface a single inline line on the card — never a toast, never a modal
5. On settle, let SSE reconcile the truth

The client sees zero latency on approve, dispute, and change-order decisions. Payment is the one exception — see below.

### 14. Payment

Payment is the only place a spinner is allowed, because a fake-instant payment is a lie.

1. `POST /payments` with idempotency key → returns `pending` immediately
2. Card shows an inline progress state, board stays interactive
3. Cybrid webhook (HMAC-verified) settles it
4. Projection updates → SSE pushes `card.moved` to Paid
5. Receipt attaches to the PO, both boards update

Never block the UI waiting on settlement. Never let a double-tap create a double-payment — the idempotency key handles it, and disable the button for 3 seconds as belt-and-braces.

### 15. Permissions

Row-level, one rule: a user sees `board_cards` where `property_id` is in their granted set. No client-side filtering ever. A regional manager's granted set is several properties; the header property switcher lists exactly those.

Roles are three, not ten: **View · Request · Approve & Pay**. Every property manager org will try to ask for more granularity. Don't. Three roles is what keeps their settings screen at four items.

### 16. Performance budgets

Treat these as build failures, not aspirations:

- Board first paint: **under 400ms** on 4G
- Card sheet open: **under 100ms** (prefetch the sheet payload on rail render — it's already in `payload`)
- Any tap → visible response: **under 50ms**, always, via optimistic UI
- Board payload: **under 60KB** gzipped for 40 cards
- Artwork: pre-resized to 344×148 on upload, WebP, served from CDN, lazy past the first two per rail

The prefetch line is the important one. Because the sheet's content already rides in the projection's `payload`, opening a card requires zero network. That's what makes it feel native.

### 17. Offline

Service worker caches the last board payload and its artwork. Opening the app offline shows the board instantly, marked with one small line at the top: `Showing last update · 9:14am`.

Actions taken offline queue locally with their idempotency keys and flush on reconnect. Approve and dispute queue safely. **Payment does not queue** — it's the one action that requires connectivity, and it says so plainly.

### 18. Notifications service

Four alerts, enforced at the service layer so no future feature can add a fifth without a code review:

```
ALLOWED_CLIENT_ALERTS = [
  'request_accepted',
  'work_complete',
  'invoice_ready',
  'payment_due_3d'
]
```

Everything else routes to the Monday digest card, which is generated as a `board_cards` row in Needs you — not an email, not a report page. Same object, same rail, same tap.

### 19. What not to build

Explicit non-goals for the client board. Each one is a thing every competitor has and every property manager will eventually ask for. Say no.

- Drag and drop between rails
- Custom rails or a rail editor
- Comments threads on cards (messages live in the job sheet, one thread, chronological)
- Labels, tags, or custom fields
- A reports section (the digest card replaces it)
- Bulk actions (if they need to approve 20 invoices at once, your invoicing is wrong — consolidate upstream)
- Email as a primary channel

Every one of these adds a control to a screen whose entire value proposition is that it has almost no controls.

---

### Build order — the client board

1. `board_cards` projection + `GET /board/:propertyId` — everything hangs off this
2. Rails renderer, phone layout first, desktop as a flex-direction swap
3. Card sheet with prefetched payload
4. The four actions with optimistic writes
5. SSE deltas
6. Request wizard
7. Offline + service worker
8. Personalized rail ordering (last — it's the only thing here that's a nice-to-have)

---


# PART FOUR — THE CARD COMPONENT

Read alongside `BoardCard.jsx`. Every rule below has caused a real bug in a real board.

---

### Why cards bleed off screen

It's never the card's width. It's five specific things, in rough order of how often they bite:

**1. `min-width: auto` on flex and grid children.**
The default. A long property name or a wide number forces the container past its column. Fix: `min-w-0` on the card, on its text wrapper, and on the rail's `<section>`. This one rule fixes roughly 70% of bleed.

**2. The overflow container isn't the one you think.**
An `overflow-x-auto` rail inside a flex parent that lacks `min-w-0` won't scroll — the *page* scrolls instead. The symptom looks like the card bleeding; the cause is two levels up.

**3. Fixed pixel widths.**
`w-[172px]` looks right on a 390px iPhone and overflows a 320px SE. Use `clamp(150px, 44vw, 190px)` so the card breathes with the viewport and still keeps the third-card peek.

**4. Images without a box.**
A raw `<img>` with a 4032px photo expands its parent. Always `absolute inset-0 h-full w-full object-cover` inside a fixed-height relative container.

**5. Edge padding lost at scroll end.**
`px-4 -mx-4` on the scroller is the pattern — full-bleed scroll, but the last card still stops 16px from the edge instead of jammed against it. Add `scroll-px-4` so snapping respects the same inset.

**Backstop:** `overflow-x-clip` on the board root. If something ever escapes, the page still doesn't scroll sideways. Never use `overflow-x-hidden` on a scroll ancestor — it silently breaks `position: sticky` on the footer button.

---

### The premium details

These are what separate "fine" from "expensive." All cheap, all specific.

**Tabular numerals on everything numeric.** `font-variant-numeric: tabular-nums`. Money and unit numbers stop jittering as cards update live. This is the most under-used typographic trick in software and it's a large part of why Klarna's numbers feel solid.

**16px radius, not 8 and not 24.** 8 reads utilitarian, 24 reads toy. 16 with a 12px inner chip radius gives you the Klarna softness without losing Apple's precision. The pill chip at `999px` is the one place full rounding is correct.

**0.5px hairline borders, no shadows.** Shadows on cards date a product instantly. A half-pixel border plus real whitespace does the separation.

**The accent border is 2px and rare.** Only Needs you cards get it. If more than three cards on screen have it, it means nothing.

**Chip sits on the artwork, bottom-left.** Not floating above the title, not a badge in the corner. It reads as a label on the image, which is how Netflix, Klarna, and Apple TV all handle state.

**One press state: `scale(0.98)`, 150ms.** No hover lift, no color change, no ring. On a touch device the scale is the entire feedback vocabulary, and it should be identical on every tappable thing in the product.

**`prefers-reduced-motion` respected.** `motion-reduce:transition-none`. Non-negotiable for the quality floor.

---

### Text rules

- **Title: one line, truncate.** Never wrap. `Unit 204` and `$4,280` both fit; a truncated long title is better than a card that grows taller than its neighbors and breaks the rail's rhythm.
- **Subtitle: one line, truncate.** Same reason.
- **Never `line-clamp-2` in a rail.** Variable card heights are what make a rail look homemade.
- **The chip truncates too** — `max-w-[calc(100%-24px)]`. A long status string overlapping the artwork edge is the giveaway that nobody tested it.

---

### Card content, by rail

| Rail | Title | Subtitle | Chip | Tone |
|---|---|---|---|---|
| Needs you — invoice | `$4,280` | `PO 88214 · 4 items` | Approve | action |
| Needs you — change order | `Unit 118` | `Change order · +$340` | Review | warning |
| In progress | `Unit 204` | `Crew on site · 2 hrs` | On site | active |
| Requested | `Unit 310` | `Submitted Tue · due Thu` | Pending | active |
| Done | `$1,940` | `Completed Jul 28` | Invoiced | active |
| Paid | `$1,940` | `Jul 28 · PO 88190` | Paid | done |

Money cards lead with the amount. Work cards lead with the unit. That's the whole rule — the title is whatever the person is actually looking for on that rail.

---

### Test matrix before shipping

Run every one of these. Each has broken a board before.

1. **320px viewport** (iPhone SE) — third card still peeks, nothing clips
2. **A 40-character property name** — truncates, doesn't push
3. **`$104,280.00`** — doesn't wrap, doesn't overflow the card
4. **A 4032×3024 photo** — stays inside its 92px panel
5. **One card in a rail** — no dead space, no stretch
6. **Twelve cards in a rail** — scrolls smoothly, last card has its 16px edge gap
7. **Swipe past the end of a rail on iOS** — does not trigger back-navigation
8. **Dark mode** — every border and chip still visible
9. **200% text zoom** — card grows, layout survives, nothing overlaps
10. **Landscape phone** — rails still work, cards don't stretch to absurd widths

If 1, 3, and 7 pass, the hard ones are done.

---


# PART FIVE — THE OPS SIDE (DENSITY)

The ops side uses **the same design system, rendered at a different density.** Not the same layout.

---

### Why not just copy it

| | Client board | Ops board |
|---|---|---|
| Session length | ~3 min, weekly | All day, daily |
| Objects on screen | 4–12 | 40–200 |
| Device | Phone | Desktop, second monitor |
| User | Untrained, occasional | Trained, expert, fast |
| Failure mode to avoid | Overwhelm | Slowness |

Those are opposite optimization targets. Tiles solve overwhelm by showing less per screen. Rows solve slowness by showing more. Using tiles on the ops side would mean your coordinator scrolls four screens to see what one screen should hold — and the artwork that makes a client's card feel warm is noise to someone who already knows what a make-ready looks like.

**This is the standard Apple split.** Photos on iPhone is a tile grid; Finder on Mac is a dense list with a column view. Same typography, same materials, same motion, same vocabulary. Nobody mistakes them for different companies, and nobody would want them swapped.

---

### Three surfaces, one system

You actually have three, and it's worth naming the third explicitly because it's usually the one that gets designed last and worst.

| Surface | Density | Primitive | Optimized for |
|---|---|---|---|
| **Client board** | Comfortable | Tile in a rail | Clarity, zero training |
| **Ops board** | Compact | Row in a list | Throughput, keyboard |
| **Crew app** | Comfortable | One job, full screen | Gloves, sunlight, one hand |

The crew app is the extreme: a crew member sees exactly one job at a time, with three buttons — `On my way`, `Arrived`, `Complete`. No list, no board, no nav. If a crew member ever has to *choose* something on screen, the design failed. That surface should be finishable in an afternoon precisely because it does so little.

---

### What is identical across all three

Do not fork any of these. This is what makes them feel like one company.

- **Color tokens** — same palette, same semantic roles, same dark mode
- **Type scale** — 28 / 20 / 16 / 14 / 12, two weights
- **Tabular numerals** on every number, everywhere
- **Motion** — one spring curve, 240 / 180 / 120ms, shared element transitions
- **Copy voice** — sentence case, plain verbs, no exclamation marks
- **Status vocabulary** — `Crew on site` means the same words on all three screens. This one matters more than it sounds: when your coordinator says "it's ready to invoice" on the phone, the property manager is looking at those exact words.
- **The card sheet** — tap any object anywhere and you get the same detail sheet, same layout, same order

### What differs

| | Client | Ops |
|---|---|---|
| Primitive | Tile, 16px radius, artwork panel | Row, 0 radius, 3px status spine |
| Row height | 144px | 52px |
| Grouping | Rails, scroll | Filter chips, one list |
| Density token | `comfortable` | `compact` |
| Bulk actions | None | Yes — shift-click, batch invoice |
| Keyboard | None | Everything |
| Photos | Hero artwork | A count, opens on demand |
| Drag and drop | No | No |

Note that bulk actions flip. On the client side they're forbidden; on the ops side they're the whole point. A coordinator invoicing nine completed jobs on Friday afternoon should do it in one gesture.

Implement density as **one switch**, not two component sets. Same `<Row>` and `<Tile>` primitives reading `data-density` off the root, exactly like your token layer already handles dark mode.

---

### The ops row

Fixed columns, left to right. Never reorderable, never customizable — a stable layout is what lets an expert scan without reading.

1. **Status spine** — 3px vertical bar, semantic color. This is the scan target. Amber, blue, green, gray. A coordinator reads the spine column top to bottom and knows the state of forty jobs in two seconds.
2. **Object** — property · units, with scope and deadline beneath. Two lines, both truncate.
3. **Owner** — crew name, or `Unassigned`, or `Broadcast · 3 bids`
4. **Status** — the plain phrase, colored to match the spine
5. **Amount** — right-aligned, tabular

**Square corners on rows, not rounded.** Rounded rectangles stacked in a dense list read as a pile of cards and create visual gaps that make scanning harder. Hairline dividers, sharp edges. This is the one place your client-side 16px radius does not carry over.

**No hover lift, no shadow, no scale.** Hover is a background tint only. In a dense list, motion on hover is nausea.

---

### Keyboard

The ops board is keyboard-first. This is the largest single throughput win available to you and it costs almost nothing.

- `⌘K` — command bar (from the polish spec)
- `J` / `K` — move down / up the list
- `Enter` — open the sheet
- `Esc` — close
- `A` — assign crew
- `B` — broadcast
- `I` — invoice
- `Shift+click` — range select
- `⌘Enter` — commit the current wizard step

Show the shortcut in the button label, right-aligned and muted: `Broadcast  B`. That's how people learn them without a tutorial, and it's a detail that reads as expert software.

---

### What stays the same on purpose

Three things from the client side carry over exactly, and they're the three that make it feel premium:

**Tabular numerals.** Same reason — live-updating amounts shouldn't jitter, and a column of right-aligned figures should line up on the decimal.

**The card sheet.** Both sides open the same detail sheet with the same sections in the same order. Your coordinator and the property manager are looking at identical information architecture, which eliminates an entire category of phone call.

**The `CONTAIN` rules.** Every `min-w-0` and `truncate` from the card component applies to rows too. A long property name overflowing a row column is the same bug in a different coat.

---

### Migration order

1. Extract the shared token layer — color, type, motion, density — into one place both sides read
2. Build `<Row>` at compact density using the same tokens as `<Tile>`
3. Convert the ops board to filter chips + one list (kills the view switcher)
4. Wire the keyboard map
5. Move bulk invoice to the ops side
6. Unify the detail sheet so both sides render from the same component

Step 1 is the one that pays off repeatedly. Once both sides read one token file, every future polish pass — a radius change, a new dark mode value, a motion tweak — happens once instead of twice and can never drift.

---
