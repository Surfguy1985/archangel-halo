/**
 * Halo — BoardCard + Rail
 * React 19 + Tailwind v4. Drop into lib/board-ui.
 *
 * Every line marked CONTAIN exists to stop horizontal bleed.
 * Do not remove them during a styling pass — they are load-bearing.
 */

import { memo } from "react";

/* ---------------------------------------------------------------
   Tokens — Apple restraint, Klarna warmth.
   16px radius, pill chips, tabular numerals, one accent.
   Add to your Tailwind v4 @theme block.
   --------------------------------------------------------------- */

const TONE = {
  action:  { panel: "bg-sky-50   dark:bg-sky-950/50",   chip: "text-sky-800   dark:text-sky-200" },
  active:  { panel: "bg-stone-100 dark:bg-stone-800",   chip: "text-stone-700 dark:text-stone-300" },
  done:    { panel: "bg-emerald-50 dark:bg-emerald-950/50", chip: "text-emerald-800 dark:text-emerald-200" },
  warning: { panel: "bg-amber-50 dark:bg-amber-950/50", chip: "text-amber-900 dark:text-amber-200" },
};

/* ---------------------------------------------------------------
   Card
   --------------------------------------------------------------- */

export const BoardCard = memo(function BoardCard({
  title,          // "Unit 204" or "$4,280"
  subtitle,       // "PO 88214 · 4 items"
  chip,           // "Approve" | "On site" | "Paid"
  tone = "active",
  artworkUrl,
  accent = false, // true only for cards in the Needs you rail
  onOpen,
}) {
  const t = TONE[tone] ?? TONE.active;

  return (
    <button
      type="button"
      onClick={onOpen}
      className={[
        // CONTAIN — shrink-0 stops flex from squeezing; clamp stops fixed px
        // from overflowing a 320px viewport. Never a bare w-[172px].
        "shrink-0 w-[clamp(150px,44vw,190px)] snap-start",
        // CONTAIN — min-w-0 lets children truncate instead of pushing wider
        "min-w-0 text-left",
        "rounded-2xl overflow-hidden bg-white dark:bg-stone-900",
        accent
          ? "border-2 border-sky-600 dark:border-sky-400"
          : "border-[0.5px] border-stone-200 dark:border-stone-700",
        "transition-transform duration-150 ease-out active:scale-[0.98]",
        "motion-reduce:transition-none motion-reduce:active:scale-100",
        "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600",
      ].join(" ")}
    >
      <div className={`relative h-[92px] ${t.panel}`}>
        {artworkUrl && (
          <img
            src={artworkUrl}
            alt=""
            loading="lazy"
            decoding="async"
            /* CONTAIN — object-cover + absolute inset keeps any aspect ratio
               inside the box. A bare <img> with a wide photo blows the card out. */
            className="absolute inset-0 h-full w-full object-cover"
          />
        )}
        {chip && (
          <span
            className={[
              "absolute bottom-3 left-3 max-w-[calc(100%-24px)] truncate",
              "rounded-full bg-white/95 dark:bg-stone-900/95 px-2.5 py-1",
              "text-[11px] font-medium", t.chip,
            ].join(" ")}
          >
            {chip}
          </span>
        )}
      </div>

      {/* CONTAIN — min-w-0 again; a flex/grid child defaults to min-width:auto */}
      <div className="min-w-0 px-3.5 pb-4 pt-3">
        <p className="truncate text-[22px] font-medium leading-tight text-stone-900 dark:text-stone-50 tabular-nums">
          {title}
        </p>
        <p className="mt-1 truncate text-[13px] text-stone-500 dark:text-stone-400">
          {subtitle}
        </p>
      </div>
    </button>
  );
});

/* ---------------------------------------------------------------
   Rail — Netflix orientation on phone, column on desktop
   --------------------------------------------------------------- */

export function Rail({ label, cards, emptyMessage, onOpenCard }) {
  if (!cards?.length) {
    return (
      <section className="px-4 py-3">
        <h2 className="text-[13px] font-medium text-stone-900 dark:text-stone-50">{label}</h2>
        <p className="mt-1 text-[13px] text-stone-500 dark:text-stone-400">{emptyMessage}</p>
      </section>
    );
  }

  return (
    /* CONTAIN — min-w-0 on the section. Without it, an overflow-x child inside
       a flex/grid parent scrolls the whole page instead of the rail. This is
       the single most common cause of "the board bleeds off screen." */
    <section className="min-w-0 py-3">
      <div className="flex items-baseline justify-between px-4">
        <h2 className="text-[13px] font-medium text-stone-900 dark:text-stone-50">{label}</h2>
        <span className="text-[13px] tabular-nums text-stone-400">{cards.length}</span>
      </div>

      <div
        className={[
          "mt-2 flex gap-2.5",
          // CONTAIN — px-4 + -mx-4 gives full-bleed scroll with edge padding
          // that survives to the last card. scroll-px matches so snapping
          // doesn't clip the first card under the edge.
          "overflow-x-auto px-4 -mx-4 scroll-px-4",
          "snap-x snap-mandatory",
          // CONTAIN — stops the horizontal swipe from triggering iOS
          // back-navigation when the rail hits its end.
          "overscroll-x-contain",
          // Hide the scrollbar without killing scrollability
          "[scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
          // Respect the notch/home indicator on the last card
          "pr-[max(1rem,env(safe-area-inset-right))]",
          // Desktop: rails become a vertical column, same components
          "lg:flex-col lg:overflow-x-visible lg:overflow-y-auto lg:mx-0 lg:px-4 lg:max-h-[70vh]",
        ].join(" ")}
      >
        {cards.map((c) => (
          <BoardCard
            key={c.id}
            {...c}
            onOpen={() => onOpenCard(c.id)}
          />
        ))}
      </div>
    </section>
  );
}

/* ---------------------------------------------------------------
   Board shell
   --------------------------------------------------------------- */

export function ClientBoard({ rails, onOpenCard, onRequestWork }) {
  return (
    /* CONTAIN — overflow-x-clip on the root is the backstop. If one card ever
       escapes, the page still won't scroll sideways. Belt and braces. */
    <div className="min-h-dvh overflow-x-clip bg-stone-50 dark:bg-stone-950">
      <div className="mx-auto w-full max-w-[1200px]">
        <header className="flex items-center justify-between px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-2">
          <h1 className="min-w-0 truncate text-[20px] font-medium text-stone-900 dark:text-stone-50">
            {rails.propertyName}
          </h1>
          <button aria-label="Search" className="shrink-0 p-2 text-stone-500">
            {/* your search icon */}
          </button>
        </header>

        <div className="lg:grid lg:grid-cols-[repeat(auto-fit,minmax(0,1fr))] lg:gap-4">
          {rails.items.map((r) => (
            <Rail key={r.id} {...r} onOpenCard={onOpenCard} />
          ))}
        </div>

        <div className="sticky bottom-0 px-4 pt-3 pb-[max(1rem,env(safe-area-inset-bottom))] bg-stone-50 dark:bg-stone-950">
          <button
            onClick={onRequestWork}
            className="w-full rounded-xl bg-stone-900 dark:bg-stone-50 py-3.5 text-[15px] font-medium text-white dark:text-stone-900 transition-transform active:scale-[0.99]"
          >
            Request work
          </button>
        </div>
      </div>
    </div>
  );
}
