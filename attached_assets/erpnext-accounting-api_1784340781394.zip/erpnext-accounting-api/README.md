# ERPNext Accounting API

A secure, multi-tenant TypeScript API gateway for the complete open-source
ERPNext/Frappe accounting engine.

This project does **not** replace ERPNext. It gives your website, SaaS platform,
mobile app, or Replit project a clean API while keeping ERPNext API secrets on
the server.

## What is included

- Multi-tenant ERPNext site routing with `x-tenant-id`
- Gateway API-key authentication
- Customers, suppliers, and items
- Sales invoices and purchase invoices
- Payments and payment allocation
- Balanced journal entries
- Profit and loss, balance sheet, cash flow, and general ledger reports
- Generic CRUD access to any permitted Frappe DocType
- Submit and cancel workflows
- Swagger/OpenAPI documentation at `/docs`
- Docker support, rate limiting, CORS, security headers, request IDs, validation,
  secret redaction, and consistent errors

## Architecture

```text
Web / iOS / Android / Replit / Next.js
                 |
      x-api-key + x-tenant-id
                 |
      ERPNext Accounting Gateway
                 |
   Frappe token authentication per tenant
                 |
          ERPNext / MariaDB
```

## 1. Start ERPNext locally

The official Frappe Docker project provides the complete ERPNext source and
container configuration.

```bash
chmod +x scripts/start-erpnext-demo.sh
./scripts/start-erpnext-demo.sh
```

Then open `http://localhost:8080`.

Demo credentials:

```text
Username: Administrator
Password: admin
```

The official `pwd.yml` deployment is disposable and should only be used for
evaluation. Use the official production deployment documentation before
handling real financial data.

## 2. Create an ERPNext API user

Inside ERPNext:

1. Create a dedicated user for the gateway.
2. Assign only the roles and DocType permissions the gateway needs.
3. Open the user and generate an API key and API secret.
4. Copy `.env.example` to `.env`.
5. Put the site URL, API key, API secret, company, and currency in
   `TENANTS_JSON`.

Example:

```env
TENANTS_JSON={"ur-founders":{"baseUrl":"http://localhost:8080","apiKey":"abc123","apiSecret":"secret123","company":"UR Founders LLC","currency":"USD"}}
```

For a SaaS product, each tenant can point to a different ERPNext site. This is
safer than placing unrelated companies into one shared permission boundary.

## 3. Run the gateway

```bash
cp .env.example .env
npm install
npm run dev
```

Open:

```text
API:  http://localhost:3000
Docs: http://localhost:3000/docs
```

Or use Docker:

```bash
docker compose up --build
```

## Required request headers

```http
x-api-key: your-gateway-key
x-tenant-id: ur-founders
Content-Type: application/json
```

## Main endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Gateway health |
| GET | `/v1/erpnext/health` | Verify ERPNext authentication |
| GET/POST | `/v1/customers` | List or create customers |
| GET/POST | `/v1/suppliers` | List or create suppliers |
| GET/POST | `/v1/items` | List or create products/services |
| GET/POST | `/v1/invoices` | List or create sales invoices |
| POST | `/v1/invoices/:name/submit` | Post a draft invoice |
| POST | `/v1/invoices/:name/cancel` | Cancel a posted invoice |
| GET/POST | `/v1/bills` | List or create vendor bills |
| POST | `/v1/payments` | Create and allocate payments |
| POST | `/v1/journal-entries` | Create balanced journal entries |
| GET | `/v1/reports/profit-and-loss` | P&L report |
| GET | `/v1/reports/balance-sheet` | Balance sheet |
| GET | `/v1/reports/cash-flow` | Cash-flow report |
| GET | `/v1/reports/general-ledger` | General ledger |
| ALL | `/v1/resources/:doctype` | Generic permitted DocType CRUD |

## Example: create a customer

```bash
curl -X POST http://localhost:3000/v1/customers \
  -H "x-api-key: replace-with-a-long-random-key" \
  -H "x-tenant-id: demo" \
  -H "content-type: application/json" \
  --data @examples/create-customer.json
```

## Example: create and submit an invoice

First create the customer and item referenced by the invoice. ERPNext account,
item group, territory, UOM, and naming values must match the selected company's
configuration.

```bash
curl -X POST http://localhost:3000/v1/invoices \
  -H "x-api-key: replace-with-a-long-random-key" \
  -H "x-tenant-id: demo" \
  -H "content-type: application/json" \
  --data @examples/create-invoice.json
```

## Example: run a report

ERPNext financial reports generally require a fiscal date range and may require
additional filters depending on the installed ERPNext version and company
configuration.

```bash
curl --get http://localhost:3000/v1/reports/profit-and-loss \
  -H "x-api-key: replace-with-a-long-random-key" \
  -H "x-tenant-id: demo" \
  --data-urlencode 'filters={"from_fiscal_year":"2026","to_fiscal_year":"2026","period_start_date":"2026-01-01","period_end_date":"2026-12-31","periodicity":"Monthly"}'
```

## Generic Frappe resource API

The generic route lets you use any DocType allowed by the ERPNext integration
user.

```bash
curl "http://localhost:3000/v1/resources/Account?limit=100" \
  -H "x-api-key: replace-with-a-long-random-key" \
  -H "x-tenant-id: demo"
```

Do not grant broad System Manager permissions to the API user in production.

## Direct Frappe API equivalents

The gateway internally uses the standard Frappe API:

```http
GET    /api/resource/{DocType}
POST   /api/resource/{DocType}
GET    /api/resource/{DocType}/{name}
PUT    /api/resource/{DocType}/{name}
DELETE /api/resource/{DocType}/{name}

POST /api/method/frappe.client.submit
POST /api/method/frappe.client.cancel
GET  /api/method/frappe.desk.query_report.run
```

Frappe token authentication:

```http
Authorization: token API_KEY:API_SECRET
```

## Production requirements

Before processing real money or official books:

- Use HTTPS everywhere.
- Put ERPNext and the gateway on private networks.
- Store secrets in a cloud secret manager, not source code.
- Use a separate API user per tenant/site with least-privilege roles.
- Back up both database and site files.
- Add immutable audit-log export.
- Configure accounting periods, taxes, accounts, fiscal years, cost centers,
  currencies, and numbering series with an accountant.
- Add idempotency storage before accepting payment-provider webhooks.
- Validate webhook signatures and retain raw webhook evidence.
- Add bank-feed integrations separately; ERPNext is the accounting system, not a
  universal bank-data provider.
- Obtain tax, accounting, security, and licensing review for the exact product.

## Licensing

This gateway is MIT licensed.

ERPNext is distributed under GPLv3, Frappe Framework under MIT, and Frappe
Docker under MIT at the time this starter was prepared. Review the current
licenses in each upstream repository before distributing modified upstream
software.
