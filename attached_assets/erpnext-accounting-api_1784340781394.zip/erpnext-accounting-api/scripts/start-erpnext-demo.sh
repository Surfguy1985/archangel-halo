#!/usr/bin/env sh
set -eu

TARGET_DIR="${1:-frappe_docker}"

if [ ! -d "$TARGET_DIR/.git" ]; then
  git clone https://github.com/frappe/frappe_docker "$TARGET_DIR"
fi

cd "$TARGET_DIR"
docker compose -f pwd.yml up -d

printf "\nERPNext demo is starting at http://localhost:8080\n"
printf "Login: Administrator / admin\n"
printf "This official pwd.yml setup is disposable and is not for production.\n"
