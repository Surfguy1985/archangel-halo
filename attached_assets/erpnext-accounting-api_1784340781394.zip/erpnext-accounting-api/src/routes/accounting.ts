import type { FastifyInstance } from "fastify";
import {
  journalEntryInput,
  paginationQuery,
  paymentInput,
  purchaseInvoiceInput,
  salesInvoiceInput
} from "../lib/schemas.js";
import {
  clientFor,
  createAndMaybeSubmit,
  parseWith
} from "../lib/route-helpers.js";

function withTenantDefaults(
  input: Record<string, unknown>,
  company: string,
  currency: string
): Record<string, unknown> {
  return {
    ...input,
    company: input.company ?? company,
    currency: input.currency ?? currency
  };
}

export async function accountingRoutes(app: FastifyInstance): Promise<void> {
  app.get("/v1/invoices", async (request) => {
    const query = parseWith(paginationQuery, request.query);
    const data = await clientFor(request).list("Sales Invoice", {
      fields: [
        "name",
        "customer",
        "posting_date",
        "due_date",
        "currency",
        "grand_total",
        "outstanding_amount",
        "status",
        "docstatus",
        "modified"
      ],
      filters: [["company", "=", request.tenant.company]],
      orderBy: "modified desc",
      limitStart: query.offset,
      limitPageLength: query.limit
    });
    return { data };
  });

  app.post("/v1/invoices", async (request, reply) => {
    const input = parseWith(salesInvoiceInput, request.body);
    await createAndMaybeSubmit(
      request,
      reply,
      "Sales Invoice",
      withTenantDefaults(
        input,
        request.tenant.company,
        request.tenant.currency
      )
    );
  });

  app.get<{ Params: { name: string } }>(
    "/v1/invoices/:name",
    async (request) => ({
      data: await clientFor(request).get("Sales Invoice", request.params.name)
    })
  );

  app.post<{ Params: { name: string } }>(
    "/v1/invoices/:name/submit",
    async (request) => ({
      data: await clientFor(request).submit(
        "Sales Invoice",
        request.params.name
      )
    })
  );

  app.post<{ Params: { name: string } }>(
    "/v1/invoices/:name/cancel",
    async (request) => ({
      data: await clientFor(request).cancel(
        "Sales Invoice",
        request.params.name
      )
    })
  );

  app.get("/v1/bills", async (request) => {
    const query = parseWith(paginationQuery, request.query);
    const data = await clientFor(request).list("Purchase Invoice", {
      fields: [
        "name",
        "supplier",
        "posting_date",
        "due_date",
        "bill_no",
        "currency",
        "grand_total",
        "outstanding_amount",
        "status",
        "docstatus",
        "modified"
      ],
      filters: [["company", "=", request.tenant.company]],
      orderBy: "modified desc",
      limitStart: query.offset,
      limitPageLength: query.limit
    });
    return { data };
  });

  app.post("/v1/bills", async (request, reply) => {
    const input = parseWith(purchaseInvoiceInput, request.body);
    await createAndMaybeSubmit(
      request,
      reply,
      "Purchase Invoice",
      withTenantDefaults(
        input,
        request.tenant.company,
        request.tenant.currency
      )
    );
  });

  app.post<{ Params: { name: string } }>(
    "/v1/bills/:name/submit",
    async (request) => ({
      data: await clientFor(request).submit(
        "Purchase Invoice",
        request.params.name
      )
    })
  );

  app.post("/v1/payments", async (request, reply) => {
    const input = parseWith(paymentInput, request.body);
    await createAndMaybeSubmit(
      request,
      reply,
      "Payment Entry",
      withTenantDefaults(
        input,
        request.tenant.company,
        request.tenant.currency
      )
    );
  });

  app.post<{ Params: { name: string } }>(
    "/v1/payments/:name/submit",
    async (request) => ({
      data: await clientFor(request).submit(
        "Payment Entry",
        request.params.name
      )
    })
  );

  app.post("/v1/journal-entries", async (request, reply) => {
    const input = parseWith(journalEntryInput, request.body);
    await createAndMaybeSubmit(
      request,
      reply,
      "Journal Entry",
      withTenantDefaults(
        input,
        request.tenant.company,
        request.tenant.currency
      )
    );
  });

  app.post<{ Params: { name: string } }>(
    "/v1/journal-entries/:name/submit",
    async (request) => ({
      data: await clientFor(request).submit(
        "Journal Entry",
        request.params.name
      )
    })
  );
}
