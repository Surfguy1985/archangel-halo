import type { FastifyInstance } from "fastify";
import {
  customerInput,
  itemInput,
  paginationQuery,
  supplierInput
} from "../lib/schemas.js";
import { clientFor, parseWith } from "../lib/route-helpers.js";

export async function masterRoutes(app: FastifyInstance): Promise<void> {
  app.get("/v1/customers", async (request) => {
    const query = parseWith(paginationQuery, request.query);
    const data = await clientFor(request).list("Customer", {
      fields: [
        "name",
        "customer_name",
        "customer_type",
        "customer_group",
        "territory",
        "tax_id",
        "disabled",
        "modified"
      ],
      orderBy: "modified desc",
      limitStart: query.offset,
      limitPageLength: query.limit
    });
    return { data };
  });

  app.post("/v1/customers", async (request, reply) => {
    const body = parseWith(customerInput, request.body);
    const data = await clientFor(request).create("Customer", body);
    reply.code(201).send({ data });
  });

  app.get<{ Params: { name: string } }>(
    "/v1/customers/:name",
    async (request) => ({
      data: await clientFor(request).get("Customer", request.params.name)
    })
  );

  app.get("/v1/suppliers", async (request) => {
    const query = parseWith(paginationQuery, request.query);
    const data = await clientFor(request).list("Supplier", {
      fields: [
        "name",
        "supplier_name",
        "supplier_group",
        "supplier_type",
        "tax_id",
        "disabled",
        "modified"
      ],
      orderBy: "modified desc",
      limitStart: query.offset,
      limitPageLength: query.limit
    });
    return { data };
  });

  app.post("/v1/suppliers", async (request, reply) => {
    const body = parseWith(supplierInput, request.body);
    const data = await clientFor(request).create("Supplier", body);
    reply.code(201).send({ data });
  });

  app.get("/v1/items", async (request) => {
    const query = parseWith(paginationQuery, request.query);
    const data = await clientFor(request).list("Item", {
      fields: [
        "name",
        "item_code",
        "item_name",
        "item_group",
        "stock_uom",
        "is_stock_item",
        "disabled",
        "modified"
      ],
      orderBy: "modified desc",
      limitStart: query.offset,
      limitPageLength: query.limit
    });
    return { data };
  });

  app.post("/v1/items", async (request, reply) => {
    const body = parseWith(itemInput, request.body);
    const data = await clientFor(request).create("Item", body);
    reply.code(201).send({ data });
  });
}
