import type { FastifyInstance } from "fastify";
import { clientFor } from "../lib/route-helpers.js";

export async function healthRoutes(app: FastifyInstance): Promise<void> {
  app.get("/health", async () => ({
    ok: true,
    service: "erpnext-accounting-api",
    timestamp: new Date().toISOString()
  }));

  app.get("/v1/erpnext/health", async (request) => {
    const user = await clientFor(request).ping();
    return {
      ok: true,
      tenant: request.tenantId,
      erpnextUser: user
    };
  });
}
