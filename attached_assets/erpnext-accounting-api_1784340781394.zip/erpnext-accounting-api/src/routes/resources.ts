import type { FastifyInstance } from "fastify";
import {
  genericResourceBody,
  paginationQuery
} from "../lib/schemas.js";
import { clientFor, parseWith } from "../lib/route-helpers.js";

interface ResourceParams {
  doctype: string;
}

interface NamedResourceParams extends ResourceParams {
  name: string;
}

export async function resourceRoutes(app: FastifyInstance): Promise<void> {
  app.get<{ Params: ResourceParams }>(
    "/v1/resources/:doctype",
    async (request) => {
      const query = parseWith(paginationQuery, request.query);
      const data = await clientFor(request).list(request.params.doctype, {
        limitStart: query.offset,
        limitPageLength: query.limit
      });
      return { data };
    }
  );

  app.post<{ Params: ResourceParams }>(
    "/v1/resources/:doctype",
    async (request, reply) => {
      const body = parseWith(genericResourceBody, request.body);
      const data = await clientFor(request).create(
        request.params.doctype,
        body
      );
      reply.code(201).send({ data });
    }
  );

  app.get<{ Params: NamedResourceParams }>(
    "/v1/resources/:doctype/:name",
    async (request) => ({
      data: await clientFor(request).get(
        request.params.doctype,
        request.params.name
      )
    })
  );

  app.put<{ Params: NamedResourceParams }>(
    "/v1/resources/:doctype/:name",
    async (request) => {
      const body = parseWith(genericResourceBody, request.body);
      return {
        data: await clientFor(request).update(
          request.params.doctype,
          request.params.name,
          body
        )
      };
    }
  );

  app.delete<{ Params: NamedResourceParams }>(
    "/v1/resources/:doctype/:name",
    async (request, reply) => {
      await clientFor(request).delete(
        request.params.doctype,
        request.params.name
      );
      reply.code(204).send();
    }
  );

  app.post<{ Params: NamedResourceParams }>(
    "/v1/resources/:doctype/:name/submit",
    async (request) => ({
      data: await clientFor(request).submit(
        request.params.doctype,
        request.params.name
      )
    })
  );

  app.post<{ Params: NamedResourceParams }>(
    "/v1/resources/:doctype/:name/cancel",
    async (request) => ({
      data: await clientFor(request).cancel(
        request.params.doctype,
        request.params.name
      )
    })
  );
}
