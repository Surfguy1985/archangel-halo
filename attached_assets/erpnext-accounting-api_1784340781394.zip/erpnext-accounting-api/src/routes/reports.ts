import type { FastifyInstance } from "fastify";
import { reportQuery } from "../lib/schemas.js";
import { clientFor, parseWith } from "../lib/route-helpers.js";

function companyFilters(
  company: string,
  filters: Record<string, unknown>
): Record<string, unknown> {
  return { company, ...filters };
}

export async function reportRoutes(app: FastifyInstance): Promise<void> {
  app.get("/v1/reports/profit-and-loss", async (request) => {
    const query = parseWith(reportQuery, request.query);
    const data = await clientFor(request).runReport(
      "Profit and Loss Statement",
      companyFilters(request.tenant.company, query.filters)
    );
    return { data };
  });

  app.get("/v1/reports/balance-sheet", async (request) => {
    const query = parseWith(reportQuery, request.query);
    const data = await clientFor(request).runReport(
      "Balance Sheet",
      companyFilters(request.tenant.company, query.filters)
    );
    return { data };
  });

  app.get("/v1/reports/cash-flow", async (request) => {
    const query = parseWith(reportQuery, request.query);
    const data = await clientFor(request).runReport(
      "Cash Flow",
      companyFilters(request.tenant.company, query.filters)
    );
    return { data };
  });

  app.get("/v1/reports/general-ledger", async (request) => {
    const query = parseWith(reportQuery, request.query);
    const data = await clientFor(request).runReport(
      "General Ledger",
      companyFilters(request.tenant.company, query.filters)
    );
    return { data };
  });

  app.get<{ Params: { reportName: string } }>(
    "/v1/reports/custom/:reportName",
    async (request) => {
      const query = parseWith(reportQuery, request.query);
      const data = await clientFor(request).runReport(
        request.params.reportName,
        companyFilters(request.tenant.company, query.filters)
      );
      return { data };
    }
  );
}
