import type { TenantConfig } from "./config.js";

declare module "fastify" {
  interface FastifyRequest {
    tenantId: string;
    tenant: TenantConfig;
  }
}

export interface FrappeListResponse<T> {
  data: T[];
}

export interface FrappeSingleResponse<T> {
  data: T;
}

export interface FrappeMethodResponse<T> {
  message: T;
}
