import Fastify from "fastify";
import { ZodError } from "zod";
import { AppError } from "./lib/errors.js";
import { registerPlugins } from "./plugins.js";
import { accountingRoutes } from "./routes/accounting.js";
import { healthRoutes } from "./routes/health.js";
import { masterRoutes } from "./routes/masters.js";
import { reportRoutes } from "./routes/reports.js";
import { resourceRoutes } from "./routes/resources.js";

export async function buildApp() {
  const app = Fastify({
    logger: {
      level: process.env.NODE_ENV === "production" ? "info" : "debug",
      redact: [
        "req.headers.authorization",
        "req.headers.x-api-key",
        "headers.authorization",
        "headers.x-api-key"
      ]
    },
    requestIdHeader: "x-request-id"
  });

  await registerPlugins(app);
  await app.register(healthRoutes);
  await app.register(masterRoutes);
  await app.register(accountingRoutes);
  await app.register(reportRoutes);
  await app.register(resourceRoutes);

  app.setErrorHandler((error, request, reply) => {
    const normalizedError =
      error instanceof Error ? error : new Error(String(error));

    request.log.error({ err: normalizedError }, normalizedError.message);

    if (normalizedError instanceof AppError) {
      reply.code(normalizedError.statusCode).send({
        error: normalizedError.name,
        message: normalizedError.message,
        details: normalizedError.details,
        requestId: request.id
      });
      return;
    }

    if (normalizedError instanceof ZodError) {
      reply.code(400).send({
        error: "ValidationError",
        message: "Invalid request.",
        details: normalizedError.flatten(),
        requestId: request.id
      });
      return;
    }

    const maybeStatusCode = (normalizedError as Error & {
      statusCode?: unknown;
    }).statusCode;
    const statusCode =
      typeof maybeStatusCode === "number" ? maybeStatusCode : 500;

    reply.code(statusCode).send({
      error: "InternalServerError",
      message:
        statusCode >= 500
          ? "An unexpected error occurred."
          : normalizedError.message,
      requestId: request.id
    });
  });

  return app;
}
