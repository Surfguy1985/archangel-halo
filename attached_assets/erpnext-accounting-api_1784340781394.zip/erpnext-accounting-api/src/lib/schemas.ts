import { z } from "zod";

export const paginationQuery = z.object({
  limit: z.coerce.number().int().min(1).max(500).default(20),
  offset: z.coerce.number().int().min(0).default(0)
});

export const customerInput = z
  .object({
    customer_name: z.string().min(1),
    customer_type: z.enum(["Individual", "Company"]).default("Company"),
    customer_group: z.string().default("All Customer Groups"),
    territory: z.string().default("All Territories"),
    tax_id: z.string().optional(),
    email_id: z.string().email().optional(),
    mobile_no: z.string().optional()
  })
  .passthrough();

export const supplierInput = z
  .object({
    supplier_name: z.string().min(1),
    supplier_group: z.string().default("All Supplier Groups"),
    supplier_type: z.enum(["Company", "Individual"]).default("Company"),
    tax_id: z.string().optional()
  })
  .passthrough();

export const itemInput = z
  .object({
    item_code: z.string().min(1),
    item_name: z.string().min(1),
    item_group: z.string().default("All Item Groups"),
    stock_uom: z.string().default("Nos"),
    is_stock_item: z.coerce.number().int().min(0).max(1).default(0),
    description: z.string().optional(),
    standard_rate: z.coerce.number().nonnegative().optional()
  })
  .passthrough();

const invoiceItem = z
  .object({
    item_code: z.string().min(1),
    qty: z.coerce.number().positive(),
    rate: z.coerce.number().nonnegative(),
    description: z.string().optional(),
    income_account: z.string().optional(),
    expense_account: z.string().optional(),
    cost_center: z.string().optional()
  })
  .passthrough();

export const salesInvoiceInput = z
  .object({
    customer: z.string().min(1),
    posting_date: z.string().date().optional(),
    due_date: z.string().date().optional(),
    currency: z.string().length(3).optional(),
    company: z.string().optional(),
    items: z.array(invoiceItem).min(1),
    taxes_and_charges: z.string().optional(),
    taxes: z.array(z.record(z.string(), z.unknown())).optional(),
    remarks: z.string().optional(),
    submit: z.boolean().default(false)
  })
  .passthrough();

export const purchaseInvoiceInput = z
  .object({
    supplier: z.string().min(1),
    posting_date: z.string().date().optional(),
    due_date: z.string().date().optional(),
    bill_no: z.string().optional(),
    bill_date: z.string().date().optional(),
    currency: z.string().length(3).optional(),
    company: z.string().optional(),
    items: z.array(invoiceItem).min(1),
    taxes_and_charges: z.string().optional(),
    taxes: z.array(z.record(z.string(), z.unknown())).optional(),
    remarks: z.string().optional(),
    submit: z.boolean().default(false)
  })
  .passthrough();

const paymentReference = z
  .object({
    reference_doctype: z.enum([
      "Sales Invoice",
      "Purchase Invoice",
      "Journal Entry",
      "Sales Order",
      "Purchase Order"
    ]),
    reference_name: z.string().min(1),
    allocated_amount: z.coerce.number().positive()
  })
  .passthrough();

export const paymentInput = z
  .object({
    payment_type: z.enum(["Receive", "Pay", "Internal Transfer"]),
    company: z.string().optional(),
    posting_date: z.string().date().optional(),
    party_type: z.enum(["Customer", "Supplier", "Employee"]).optional(),
    party: z.string().optional(),
    paid_from: z.string().min(1),
    paid_to: z.string().min(1),
    paid_amount: z.coerce.number().positive(),
    received_amount: z.coerce.number().positive(),
    reference_no: z.string().optional(),
    reference_date: z.string().date().optional(),
    mode_of_payment: z.string().optional(),
    references: z.array(paymentReference).default([]),
    submit: z.boolean().default(false)
  })
  .passthrough();

const journalAccount = z
  .object({
    account: z.string().min(1),
    debit_in_account_currency: z.coerce.number().nonnegative().default(0),
    credit_in_account_currency: z.coerce.number().nonnegative().default(0),
    party_type: z.string().optional(),
    party: z.string().optional(),
    reference_type: z.string().optional(),
    reference_name: z.string().optional(),
    cost_center: z.string().optional()
  })
  .passthrough()
  .refine(
    (row) =>
      (row.debit_in_account_currency > 0) !==
      (row.credit_in_account_currency > 0),
    "Each journal row must contain either a debit or a credit, but not both."
  );

export const journalEntryInput = z
  .object({
    voucher_type: z.string().default("Journal Entry"),
    company: z.string().optional(),
    posting_date: z.string().date().optional(),
    user_remark: z.string().optional(),
    cheque_no: z.string().optional(),
    cheque_date: z.string().date().optional(),
    accounts: z.array(journalAccount).min(2),
    submit: z.boolean().default(false)
  })
  .passthrough()
  .superRefine((value, ctx) => {
    const debit = value.accounts.reduce(
      (sum, row) => sum + row.debit_in_account_currency,
      0
    );
    const credit = value.accounts.reduce(
      (sum, row) => sum + row.credit_in_account_currency,
      0
    );
    if (Math.abs(debit - credit) > 0.005) {
      ctx.addIssue({
        code: "custom",
        message: `Journal entry is not balanced. Debit=${debit}, credit=${credit}.`,
        path: ["accounts"]
      });
    }
  });

export const genericResourceBody = z.record(z.string(), z.unknown());

export const reportQuery = z.object({
  filters: z
    .string()
    .default("{}")
    .transform((value, ctx) => {
      try {
        const parsed = JSON.parse(value) as unknown;
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
          ctx.addIssue({
            code: "custom",
            message: "filters must decode to a JSON object."
          });
          return z.NEVER;
        }
        return parsed as Record<string, unknown>;
      } catch {
        ctx.addIssue({
          code: "custom",
          message: "filters must be valid JSON."
        });
        return z.NEVER;
      }
    })
});
