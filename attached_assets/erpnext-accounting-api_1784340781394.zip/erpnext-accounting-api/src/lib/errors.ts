export class AppError extends Error {
  constructor(
    message: string,
    public readonly statusCode = 500,
    public readonly details?: unknown
  ) {
    super(message);
    this.name = "AppError";
  }
}

export function extractFrappeError(payload: unknown, fallback: string): string {
  if (!payload || typeof payload !== "object") return fallback;

  const record = payload as Record<string, unknown>;

  if (typeof record.exception === "string" && record.exception.trim()) {
    return record.exception;
  }

  if (typeof record._server_messages === "string") {
    try {
      const outer = JSON.parse(record._server_messages) as string[];
      const messages = outer.map((entry) => {
        try {
          const parsed = JSON.parse(entry) as Record<string, unknown>;
          return typeof parsed.message === "string" ? parsed.message : entry;
        } catch {
          return entry;
        }
      });
      if (messages.length) return messages.join("; ");
    } catch {
      // Use the fallback below.
    }
  }

  if (typeof record.message === "string" && record.message.trim()) {
    return record.message;
  }

  return fallback;
}
