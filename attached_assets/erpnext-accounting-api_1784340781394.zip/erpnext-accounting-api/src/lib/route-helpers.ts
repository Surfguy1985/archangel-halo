import type { FastifyReply, FastifyRequest } from "fastify";
import type { ZodType } from "zod";
import { AppError } from "./errors.js";
import { FrappeClient } from "./frappe-client.js";

export function parseWith<T>(
  schema: ZodType<T>,
  value: unknown,
  message = "Invalid request."
): T {
  const result = schema.safeParse(value);
  if (!result.success) {
    throw new AppError(message, 400, result.error.flatten());
  }
  return result.data;
}

export function clientFor(request: FastifyRequest): FrappeClient {
  return new FrappeClient(request.tenant);
}

export async function createAndMaybeSubmit(
  request: FastifyRequest,
  reply: FastifyReply,
  doctype: string,
  payload: Record<string, unknown> & { submit?: boolean }
): Promise<void> {
  const client = clientFor(request);
  const shouldSubmit = payload.submit === true;
  const { submit: _ignored, ...document } = payload;

  const created = await client.create<Record<string, unknown>>(doctype, document);
  const name = created.name;

  if (shouldSubmit && typeof name === "string") {
    const submitted = await client.submit(doctype, name);
    reply.code(201).send({ data: submitted });
    return;
  }

  reply.code(201).send({ data: created });
}
