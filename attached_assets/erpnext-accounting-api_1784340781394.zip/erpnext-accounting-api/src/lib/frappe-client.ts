import type {
  FrappeListResponse,
  FrappeMethodResponse,
  FrappeSingleResponse
} from "../types.js";
import type { TenantConfig } from "../config.js";
import { AppError, extractFrappeError } from "./errors.js";

type QueryValue = string | number | boolean | undefined;

export interface ListOptions {
  fields?: string[];
  filters?: unknown[];
  orderBy?: string;
  limitStart?: number;
  limitPageLength?: number;
}

export class FrappeClient {
  constructor(private readonly tenant: TenantConfig) {}

  private buildUrl(path: string, query?: Record<string, QueryValue>): URL {
    const base = this.tenant.baseUrl.endsWith("/")
      ? this.tenant.baseUrl
      : `${this.tenant.baseUrl}/`;
    const url = new URL(path.replace(/^\//, ""), base);

    for (const [key, value] of Object.entries(query ?? {})) {
      if (value !== undefined) url.searchParams.set(key, String(value));
    }

    return url;
  }

  private async request<T>(
    method: string,
    path: string,
    options: {
      query?: Record<string, QueryValue>;
      body?: unknown;
    } = {}
  ): Promise<T> {
    const requestInit: RequestInit = {
      method,
      headers: {
        Authorization: `token ${this.tenant.apiKey}:${this.tenant.apiSecret}`,
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      signal: AbortSignal.timeout(30_000)
    };

    if (options.body !== undefined) {
      requestInit.body = JSON.stringify(options.body);
    }

    const response = await fetch(
      this.buildUrl(path, options.query),
      requestInit
    );

    const text = await response.text();
    let payload: unknown = null;

    if (text) {
      try {
        payload = JSON.parse(text);
      } catch {
        payload = { message: text };
      }
    }

    if (!response.ok) {
      throw new AppError(
        extractFrappeError(payload, `ERPNext returned HTTP ${response.status}.`),
        response.status >= 400 && response.status < 500 ? response.status : 502,
        payload
      );
    }

    return payload as T;
  }

  async ping(): Promise<string> {
    const result = await this.request<FrappeMethodResponse<string>>(
      "GET",
      "/api/method/frappe.auth.get_logged_user"
    );
    return result.message;
  }

  async list<T = Record<string, unknown>>(
    doctype: string,
    options: ListOptions = {}
  ): Promise<T[]> {
    const result = await this.request<FrappeListResponse<T>>(
      "GET",
      `/api/resource/${encodeURIComponent(doctype)}`,
      {
        query: {
          fields: JSON.stringify(options.fields ?? ["*"]),
          filters: options.filters ? JSON.stringify(options.filters) : undefined,
          order_by: options.orderBy,
          limit_start: options.limitStart ?? 0,
          limit_page_length: options.limitPageLength ?? 20
        }
      }
    );
    return result.data;
  }

  async get<T = Record<string, unknown>>(
    doctype: string,
    name: string
  ): Promise<T> {
    const result = await this.request<FrappeSingleResponse<T>>(
      "GET",
      `/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(name)}`
    );
    return result.data;
  }

  async create<T = Record<string, unknown>>(
    doctype: string,
    data: Record<string, unknown>
  ): Promise<T> {
    const result = await this.request<FrappeSingleResponse<T>>(
      "POST",
      `/api/resource/${encodeURIComponent(doctype)}`,
      { body: data }
    );
    return result.data;
  }

  async update<T = Record<string, unknown>>(
    doctype: string,
    name: string,
    data: Record<string, unknown>
  ): Promise<T> {
    const result = await this.request<FrappeSingleResponse<T>>(
      "PUT",
      `/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(name)}`,
      { body: data }
    );
    return result.data;
  }

  async delete(doctype: string, name: string): Promise<void> {
    await this.request(
      "DELETE",
      `/api/resource/${encodeURIComponent(doctype)}/${encodeURIComponent(name)}`
    );
  }

  async call<T = unknown>(
    dottedMethod: string,
    body?: Record<string, unknown>
  ): Promise<T> {
    const result = await this.request<FrappeMethodResponse<T>>(
      "POST",
      `/api/method/${dottedMethod}`,
      { body }
    );
    return result.message;
  }

  async submit<T = Record<string, unknown>>(
    doctype: string,
    name: string
  ): Promise<T> {
    const doc = await this.get<Record<string, unknown>>(doctype, name);
    return this.call<T>("frappe.client.submit", { doc });
  }

  async cancel<T = Record<string, unknown>>(
    doctype: string,
    name: string
  ): Promise<T> {
    const doc = await this.get<Record<string, unknown>>(doctype, name);
    return this.call<T>("frappe.client.cancel", { doc });
  }

  async runReport<T = unknown>(
    reportName: string,
    filters: Record<string, unknown>
  ): Promise<T> {
    const result = await this.request<FrappeMethodResponse<T>>(
      "GET",
      "/api/method/frappe.desk.query_report.run",
      {
        query: {
          report_name: reportName,
          filters: JSON.stringify(filters)
        }
      }
    );
    return result.message;
  }
}
