import type { FastifyInstance } from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import swagger from "@fastify/swagger";
import swaggerUi from "@fastify/swagger-ui";
import { config } from "./config.js";
import { AppError } from "./lib/errors.js";

export async function registerPlugins(app: FastifyInstance): Promise<void> {
  await app.register(helmet);

  await app.register(cors, {
    origin:
      config.corsOrigins === "*"
        ? true
        : (origin, callback) => {
            if (!origin || config.corsOrigins.includes(origin)) {
              callback(null, true);
              return;
            }
            callback(new Error("Origin is not allowed."), false);
          }
  });

  await app.register(rateLimit, {
    max: config.rateLimitMax,
    timeWindow: config.rateLimitWindow
  });

  await app.register(swagger, {
    openapi: {
      info: {
        title: "ERPNext Accounting Gateway",
        description:
          "Secure multi-tenant accounting API backed by ERPNext and Frappe.",
        version: "1.0.0"
      },
      components: {
        securitySchemes: {
          GatewayApiKey: {
            type: "apiKey",
            name: "x-api-key",
            in: "header"
          },
          TenantId: {
            type: "apiKey",
            name: "x-tenant-id",
            in: "header"
          }
        }
      },
      security: [{ GatewayApiKey: [], TenantId: [] }]
    }
  });

  await app.register(swaggerUi, {
    routePrefix: "/docs"
  });

  app.addHook("onRequest", async (request) => {
    if (
      request.url === "/health" ||
      request.url.startsWith("/docs") ||
      request.url.startsWith("/documentation")
    ) {
      return;
    }

    const gatewayKey = request.headers["x-api-key"];
    if (
      typeof gatewayKey !== "string" ||
      !config.gatewayApiKeys.has(gatewayKey)
    ) {
      throw new AppError("Invalid or missing x-api-key.", 401);
    }

    const tenantId = request.headers["x-tenant-id"];
    if (typeof tenantId !== "string" || !tenantId.trim()) {
      throw new AppError("Missing x-tenant-id.", 400);
    }

    const tenant = config.tenants[tenantId];
    if (!tenant) {
      throw new AppError("Unknown tenant.", 404);
    }

    request.tenantId = tenantId;
    request.tenant = tenant;
  });
}
