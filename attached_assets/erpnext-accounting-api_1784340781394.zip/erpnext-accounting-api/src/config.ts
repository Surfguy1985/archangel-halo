import "dotenv/config";
import { z } from "zod";

const tenantSchema = z.object({
  baseUrl: z.string().url(),
  apiKey: z.string().min(1),
  apiSecret: z.string().min(1),
  company: z.string().min(1),
  currency: z.string().length(3).default("USD")
});

export type TenantConfig = z.infer<typeof tenantSchema>;

const envSchema = z.object({
  PORT: z.coerce.number().int().positive().default(3000),
  HOST: z.string().default("0.0.0.0"),
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  GATEWAY_API_KEYS: z.string().min(1),
  TENANTS_JSON: z.string().min(2),
  CORS_ORIGINS: z.string().default("*"),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(200),
  RATE_LIMIT_WINDOW: z.string().default("1 minute")
});

const raw = envSchema.parse(process.env);

let tenantJson: unknown;
try {
  tenantJson = JSON.parse(raw.TENANTS_JSON);
} catch {
  throw new Error("TENANTS_JSON must be valid JSON.");
}

const tenants = z.record(z.string(), tenantSchema).parse(tenantJson);
if (Object.keys(tenants).length === 0) {
  throw new Error("TENANTS_JSON must define at least one tenant.");
}

export const config = {
  port: raw.PORT,
  host: raw.HOST,
  nodeEnv: raw.NODE_ENV,
  gatewayApiKeys: new Set(
    raw.GATEWAY_API_KEYS.split(",").map((value) => value.trim()).filter(Boolean)
  ),
  tenants,
  corsOrigins:
    raw.CORS_ORIGINS.trim() === "*"
      ? "*"
      : raw.CORS_ORIGINS.split(",").map((value) => value.trim()).filter(Boolean),
  rateLimitMax: raw.RATE_LIMIT_MAX,
  rateLimitWindow: raw.RATE_LIMIT_WINDOW
} as const;
