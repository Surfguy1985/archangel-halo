# Integrating into an existing Replit HALO platform

## Same-repository integration

1. Copy `packages/tax-core` and `packages/sdk` into the HALO monorepo.
2. Add both folders to npm workspaces.
3. Add `@halo/tax-sdk` to the consuming app.
4. Set `HALO_TAX_API_KEY` in Replit Secrets.
5. Create a server-side client. Never expose a production API key in browser JavaScript.

```ts
import { HaloTaxClient } from "@halo/tax-sdk";
const tax = new HaloTaxClient({
  baseUrl: process.env.HALO_TAX_URL!,
  apiKey: process.env.HALO_TAX_API_KEY!,
  projectId: "halo-main"
});
```

## Separate service integration

Deploy this project once and call it from every future project. Use a different API key/project header for each application. Usage is metered per key.

## ERPNext accounting integration

Configure `ERP_GATEWAY_URL`, `ERP_GATEWAY_API_KEY`, and `ERP_TENANT_ID`. The included route can fetch the existing profit-and-loss report. Production mapping should normalize the report into gross revenue, ordinary expenses, owner wages, withholding, credits and estimated payments before calling the estimate route.

## Public share links

The customer UI serializes the entered planning inputs into the `estimate` query parameter. No taxpayer identifier is included by default. Do not put names, SSNs, EINs, bank data or uploaded documents in share URLs.
