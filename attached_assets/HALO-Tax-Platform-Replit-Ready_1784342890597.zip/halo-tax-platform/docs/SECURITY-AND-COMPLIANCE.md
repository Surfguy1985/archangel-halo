# Security and compliance boundaries

- The platform is a **planning estimator**, not tax-preparation or e-file software.
- Do not collect SSNs, EINs, banking credentials, tax-return PDFs or identity documents until encryption, access controls, retention, incident response and legal review are in place.
- API keys must remain server side. Rotate keys and use one key per project.
- Use PostgreSQL in production; in-memory usage resets when the process restarts.
- Add authentication, tenant authorization and an immutable audit trail before storing customer estimates.
- OpenFisca is AGPL-licensed. If you modify and operate OpenFisca over a network, review source-availability obligations with counsel.
- Direct IRS MeF transmission requires the applicable e-file provider roles, testing, schemas, business rules and acknowledgements. This repository does not transmit returns.
