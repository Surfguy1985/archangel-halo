# HALO Tax API — Suggested Commercial Schedule

| Plan | Monthly price | Included calls | Overage | Intended customer |
|---|---:|---:|---:|---|
| Sandbox | $0 | 250 | Disabled after allowance | Evaluation and prototypes |
| Builder | $49 | 5,000 | $0.012/call | One app or small portal |
| Growth | $149 | 25,000 | $0.007/call | Agencies and multi-client products |
| Platform | $499 | 100,000 | $0.0035/call | Embedded SaaS and white-label use |
| Enterprise | Custom | Custom | Custom | Dedicated or regulated deployments |

## Suggested implementation and professional-service fees

These are commercial recommendations, not hard-coded charges:

- Basic HALO/Replit integration: **$1,500–$3,500 one time**
- White-label portal and brand configuration: **$3,500–$7,500 one time**
- ERPNext mapping and reconciliation workflow: **$4,000–$10,000 one time**
- State-specific planning rule pack: **$2,500–$8,000 per state and tax year**, depending on scope
- CPA validation and annual rule certification: pass through at cost or **$5,000–$20,000 per annual federal pack**
- Authorized filing-provider integration: **$10,000–$40,000** plus provider transaction charges
- Dedicated environment and security review: **$500–$2,500/month** above API plan

The pricing source of truth is `packages/tax-core/src/pricing.ts`; the public API and customer pricing page read directly from that file.
