import type { FastifyRequest } from "fastify";
import { config } from "./config.js";
import { getMonthlyUsage, recordUsage } from "./db.js";
import { PRICING_PLANS } from "@halo/tax-core";
declare module "fastify" { interface FastifyRequest { haloClient?: {key:string; plan:string; project:string; usage:number} } }
export async function authenticate(request:FastifyRequest){ const key=request.headers["x-halo-api-key"]; if(typeof key!=="string"||!config.apiKeys[key]) throw Object.assign(new Error("Invalid or missing x-halo-api-key"),{statusCode:401}); const client=config.apiKeys[key]!; const usage=await getMonthlyUsage(key); const plan=PRICING_PLANS.find(p=>p.id===client.plan); if(plan?.includedCalls!==null && plan?.overagePerCall===null && usage>=plan.includedCalls) throw Object.assign(new Error("Monthly API allowance reached"),{statusCode:429}); request.haloClient={key,plan:client.plan,project:request.headers["x-halo-project"]?.toString()||client.project,usage}; await recordUsage(key,request.haloClient.project,request.routeOptions.url??request.url); }
