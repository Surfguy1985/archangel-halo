import "dotenv/config";
import { z } from "zod";
import type { PricingPlan } from "@halo/tax-core";
const schema = z.object({
  NODE_ENV: z.enum(["development","test","production"]).default("development"), PORT: z.coerce.number().default(3000), HOST: z.string().default("0.0.0.0"), PUBLIC_DEMO_MODE: z.string().default("true"), CORS_ORIGINS: z.string().default("http://localhost:5173"), API_KEYS_JSON: z.string().default("{}"), DATABASE_URL: z.string().optional(), OPENFISCA_URL: z.string().url().optional().or(z.literal("")), OPENFISCA_TOKEN: z.string().optional(), ERP_GATEWAY_URL: z.string().url().optional().or(z.literal("")), ERP_GATEWAY_API_KEY: z.string().optional(), ERP_TENANT_ID: z.string().default("demo")
});
const e=schema.parse(process.env);
let apiKeys: Record<string,{plan:PricingPlan["id"];project:string}>={};
try { apiKeys=JSON.parse(e.API_KEYS_JSON); } catch { throw new Error("API_KEYS_JSON must be valid JSON"); }
export const config={...e, publicDemoMode:e.PUBLIC_DEMO_MODE==="true", corsOrigins:e.CORS_ORIGINS.split(",").map(x=>x.trim()), apiKeys};
