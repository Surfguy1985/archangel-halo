import pg from "pg";
import { config } from "./config.js";
import { createHash } from "node:crypto";
const pool = config.DATABASE_URL ? new pg.Pool({ connectionString: config.DATABASE_URL, ssl: config.NODE_ENV === "production" ? { rejectUnauthorized: false } : undefined }) : null;
const memoryUsage = new Map<string, number>();
const memoryLeads: unknown[] = [];
export const hashKey=(key:string)=>createHash("sha256").update(key).digest("hex");
export async function initDb(){ if(!pool) return; await pool.query(`CREATE TABLE IF NOT EXISTS halo_tax_usage(id bigserial primary key, api_key_hash text not null, project text not null, endpoint text not null, created_at timestamptz default now()); CREATE INDEX IF NOT EXISTS halo_tax_usage_month_idx ON halo_tax_usage(api_key_hash, created_at); CREATE TABLE IF NOT EXISTS halo_tax_leads(id bigserial primary key, name text, email text not null, company text, message text, created_at timestamptz default now());`); }
export async function recordUsage(key:string, project:string, endpoint:string){ const h=hashKey(key); if(pool){ await pool.query("INSERT INTO halo_tax_usage(api_key_hash,project,endpoint) VALUES($1,$2,$3)",[h,project,endpoint]); } else memoryUsage.set(h,(memoryUsage.get(h)??0)+1); }
export async function getMonthlyUsage(key:string){ const h=hashKey(key); if(pool){ const r=await pool.query("SELECT count(*)::int AS count FROM halo_tax_usage WHERE api_key_hash=$1 AND created_at>=date_trunc('month',now())",[h]); return Number(r.rows[0]?.count??0); } return memoryUsage.get(h)??0; }
export async function saveLead(lead:{name?:string;email:string;company?:string;message?:string}){ if(pool){ await pool.query("INSERT INTO halo_tax_leads(name,email,company,message) VALUES($1,$2,$3,$4)",[lead.name??null,lead.email,lead.company??null,lead.message??null]); } else memoryLeads.push({...lead,createdAt:new Date().toISOString()}); }
