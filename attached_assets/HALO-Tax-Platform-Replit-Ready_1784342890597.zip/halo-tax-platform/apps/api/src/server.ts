import Fastify from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import swagger from "@fastify/swagger";
import swaggerUi from "@fastify/swagger-ui";
import fastifyStatic from "@fastify/static";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import { calculateEstimate, compareEntities, estimateInputSchema, PRICING_PLANS, RULES_2026, calculateMonthlyApiCost } from "@halo/tax-core";
import { config } from "./config.js";
import { authenticate } from "./auth.js";
import { getMonthlyUsage, initDb, saveLead } from "./db.js";
import { callOpenFisca, fetchErpSnapshot } from "./integrations.js";

const app=Fastify({logger:{level:config.NODE_ENV==="production"?"info":"debug",redact:["req.headers.x-halo-api-key"]}});
await app.register(helmet,{contentSecurityPolicy:false});
await app.register(cors,{origin:(origin,cb)=>cb(null,!origin||config.corsOrigins.includes(origin)||config.NODE_ENV==="development")});
await app.register(rateLimit,{max:300,timeWindow:"1 minute"});
await app.register(swagger,{openapi:{info:{title:"HALO Tax API",version:"1.0.0",description:"Business tax planning API. Estimates only; not electronic filing."},components:{securitySchemes:{HaloApiKey:{type:"apiKey",in:"header",name:"x-halo-api-key"}}}}});
await app.register(swaggerUi,{routePrefix:"/docs"});

app.get("/health",async()=>({ok:true,service:"halo-tax-api",version:"1.0.0",time:new Date().toISOString()}));
app.get("/public/pricing",async()=>({data:PRICING_PLANS}));
app.get("/public/rules/2026",async()=>({data:RULES_2026,notice:"Published planning parameters; not a complete tax-code implementation."}));
app.post("/public/estimate",{config:{rateLimit:{max:30,timeWindow:"1 hour"}}},async(req)=>{ if(!config.publicDemoMode) throw Object.assign(new Error("Public estimator disabled"),{statusCode:403}); const input=estimateInputSchema.parse(req.body); return {data:calculateEstimate(input)}; });
app.post("/public/compare",{config:{rateLimit:{max:15,timeWindow:"1 hour"}}},async(req)=>{ if(!config.publicDemoMode) throw Object.assign(new Error("Public comparison disabled"),{statusCode:403}); const input=estimateInputSchema.parse(req.body); return {data:compareEntities(input)}; });
app.post("/public/leads",{config:{rateLimit:{max:5,timeWindow:"1 hour"}}},async(req,reply)=>{ const lead=z.object({name:z.string().max(100).optional(),email:z.string().email(),company:z.string().max(150).optional(),message:z.string().max(1000).optional()}).parse(req.body); await saveLead(lead); reply.code(201); return {ok:true}; });
app.get("/public/cost",async(req)=>{ const q=z.object({plan:z.enum(["sandbox","builder","growth","platform","enterprise"]),calls:z.coerce.number().int().nonnegative()}).parse(req.query); return {data:calculateMonthlyApiCost(q.plan,q.calls)}; });

app.post("/v1/estimates",{preHandler:authenticate},async(req)=>({data:calculateEstimate(estimateInputSchema.parse(req.body)),meta:{project:req.haloClient!.project}}));
app.post("/v1/scenarios/compare",{preHandler:authenticate},async(req)=>({data:compareEntities(estimateInputSchema.parse(req.body)),meta:{project:req.haloClient!.project}}));
app.get("/v1/usage",{preHandler:authenticate},async(req)=>({data:{project:req.haloClient!.project,plan:req.haloClient!.plan,callsThisMonth:await getMonthlyUsage(req.haloClient!.key)}}));
app.post("/v1/openfisca/calculate",{preHandler:authenticate},async(req)=>({data:await callOpenFisca(req.body)}));
app.post("/v1/integrations/erpnext/report",{preHandler:authenticate},async(req)=>({data:await fetchErpSnapshot(z.record(z.unknown()).parse(req.body))}));

app.setErrorHandler((err,req,reply)=>{ const error = err as Error & { statusCode?: number; details?: unknown }; const status=error.statusCode??(error instanceof z.ZodError?400:500); req.log.error({err:error},error.message); reply.code(status).send({error:error.name,message:status>=500?"Request could not be completed":error.message,details:error instanceof z.ZodError?error.flatten():error.details,requestId:req.id}); });

const __dirname=dirname(fileURLToPath(import.meta.url));
const webRoot=join(__dirname,"../../web/dist");
if(config.NODE_ENV==="production"){
  await app.register(fastifyStatic,{root:webRoot,prefix:"/"});
  app.setNotFoundHandler((req,reply)=>{ if(req.url.startsWith("/v1/")||req.url.startsWith("/public/")||req.url.startsWith("/docs")) return reply.code(404).send({message:"Not found"}); return reply.sendFile("index.html"); });
}
await initDb();
await app.listen({host:config.HOST,port:config.PORT});
