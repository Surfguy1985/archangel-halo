import type { FilingStatus } from "./types.js";

export interface Bracket { cap: number; rate: number }

export const RULES_2026 = {
  standardDeduction: {
    single: 16100,
    married_joint: 32200,
    married_separate: 16100,
    head_household: 24150
  } satisfies Record<FilingStatus, number>,
  brackets: {
    single: [
      { cap: 12400, rate: 0.10 }, { cap: 50400, rate: 0.12 }, { cap: 105700, rate: 0.22 },
      { cap: 201775, rate: 0.24 }, { cap: 256225, rate: 0.32 }, { cap: 640600, rate: 0.35 },
      { cap: Infinity, rate: 0.37 }
    ],
    married_joint: [
      { cap: 24800, rate: 0.10 }, { cap: 100800, rate: 0.12 }, { cap: 211400, rate: 0.22 },
      { cap: 403550, rate: 0.24 }, { cap: 512450, rate: 0.32 }, { cap: 768700, rate: 0.35 },
      { cap: Infinity, rate: 0.37 }
    ],
    married_separate: [
      { cap: 12400, rate: 0.10 }, { cap: 50400, rate: 0.12 }, { cap: 105700, rate: 0.22 },
      { cap: 201775, rate: 0.24 }, { cap: 256225, rate: 0.32 }, { cap: 384350, rate: 0.35 },
      { cap: Infinity, rate: 0.37 }
    ],
    head_household: [
      { cap: 17700, rate: 0.10 }, { cap: 67450, rate: 0.12 }, { cap: 105700, rate: 0.22 },
      { cap: 201750, rate: 0.24 }, { cap: 256200, rate: 0.32 }, { cap: 640600, rate: 0.35 },
      { cap: Infinity, rate: 0.37 }
    ]
  } satisfies Record<FilingStatus, Bracket[]>,
  socialSecurityWageBase: 184500,
  socialSecurityCombinedRate: 0.124,
  socialSecurityEmployeeRate: 0.062,
  medicareCombinedRate: 0.029,
  medicareEmployeeRate: 0.0145,
  additionalMedicareRate: 0.009,
  additionalMedicareThreshold: {
    single: 200000,
    married_joint: 250000,
    married_separate: 125000,
    head_household: 200000
  } satisfies Record<FilingStatus, number>,
  selfEmploymentNetFactor: 0.9235,
  corporateRate: 0.21,
  quarterlyDueDates: ["2026-04-15", "2026-06-15", "2026-09-15", "2027-01-15"]
} as const;
