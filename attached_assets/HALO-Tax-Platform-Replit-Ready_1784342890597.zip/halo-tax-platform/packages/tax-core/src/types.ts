import { z } from "zod";

export const entityTypes = ["sole_proprietor", "single_member_llc", "partnership", "s_corp", "c_corp"] as const;
export const filingStatuses = ["single", "married_joint", "married_separate", "head_household"] as const;

export const estimateInputSchema = z.object({
  taxYear: z.literal(2026).default(2026),
  entityType: z.enum(entityTypes),
  filingStatus: z.enum(filingStatuses).default("single"),
  grossRevenue: z.number().finite().nonnegative(),
  ordinaryExpenses: z.number().finite().nonnegative(),
  ownershipPercent: z.number().min(0).max(100).default(100),
  ownerW2Wages: z.number().finite().nonnegative().default(0),
  otherW2Wages: z.number().finite().nonnegative().default(0),
  otherTaxableIncome: z.number().finite().default(0),
  aboveLineAdjustments: z.number().finite().nonnegative().default(0),
  itemizedDeductions: z.number().finite().nonnegative().default(0),
  qbiDeduction: z.number().finite().nonnegative().default(0),
  taxCredits: z.number().finite().nonnegative().default(0),
  federalWithholding: z.number().finite().nonnegative().default(0),
  estimatedPaymentsMade: z.number().finite().nonnegative().default(0),
  stateEffectiveRate: z.number().min(0).max(0.2).default(0),
  partnershipSEIncomePercent: z.number().min(0).max(100).default(100),
  reserveBufferRate: z.number().min(0).max(0.25).default(0.05)
});

export type EstimateInput = z.infer<typeof estimateInputSchema>;
export type EntityType = EstimateInput["entityType"];
export type FilingStatus = EstimateInput["filingStatus"];

export interface TaxComponent { key: string; label: string; amount: number; note?: string }
export interface QuarterlyPayment { label: string; dueDate: string; suggestedPayment: number }
export interface EstimateResult {
  version: string;
  taxYear: 2026;
  entityType: EntityType;
  businessProfitBeforeOwnerComp: number;
  ownerPassThroughIncome: number;
  ownerW2Wages: number;
  adjustedGrossIncomeEstimate: number;
  deductionUsed: number;
  taxableIncomeEstimate: number;
  components: TaxComponent[];
  federalTaxEstimate: number;
  stateTaxEstimate: number;
  totalProjectedTax: number;
  creditsAndPrepayments: number;
  projectedBalanceDue: number;
  effectiveRateOnBusinessProfit: number;
  reserveRecommendation: number;
  quarterlyPayments: QuarterlyPayment[];
  assumptions: string[];
  warnings: string[];
  disclaimer: string;
}

export interface EntityComparison {
  input: EstimateInput;
  scenarios: EstimateResult[];
  lowestProjectedTaxEntity: EntityType;
  spread: number;
  warning: string;
}
