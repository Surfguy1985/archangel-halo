import { calculateEstimate } from "./engine.js";
import type { EntityComparison, EstimateInput, EntityType } from "./types.js";

export function compareEntities(input: EstimateInput): EntityComparison {
  const profit = Math.max(0, input.grossRevenue - input.ordinaryExpenses);
  const scenarios: EntityType[] = ["sole_proprietor", "single_member_llc", "partnership", "s_corp", "c_corp"];
  const results = scenarios.map((entityType) => calculateEstimate({
    ...input,
    entityType,
    ownerW2Wages: entityType === "s_corp" && input.ownerW2Wages === 0 ? Math.min(profit * 0.45, 150000) : input.ownerW2Wages
  }));
  const sorted = [...results].sort((a, b) => a.totalProjectedTax - b.totalProjectedTax);
  return {
    input,
    scenarios: results,
    lowestProjectedTaxEntity: sorted[0]!.entityType,
    spread: Math.round((sorted.at(-1)!.totalProjectedTax - sorted[0]!.totalProjectedTax) * 100) / 100,
    warning: "The lowest modeled tax is not automatically the best legal entity. Formation, payroll, legal liability, benefits, basis, distributions, state law, compliance cost and exit plans must also be evaluated."
  };
}
