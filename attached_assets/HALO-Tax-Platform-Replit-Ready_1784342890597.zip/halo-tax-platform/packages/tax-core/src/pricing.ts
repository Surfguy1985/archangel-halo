export interface PricingPlan {
  id: "sandbox" | "builder" | "growth" | "platform" | "enterprise";
  name: string;
  monthlyPrice: number | null;
  includedCalls: number | null;
  overagePerCall: number | null;
  features: string[];
  recommendedFor: string;
}

export const PRICING_PLANS: PricingPlan[] = [
  { id: "sandbox", name: "Sandbox", monthlyPrice: 0, includedCalls: 250, overagePerCall: null, recommendedFor: "Testing and prototypes", features: ["2026 planning engine", "Test API key", "Community support", "No production SLA"] },
  { id: "builder", name: "Builder", monthlyPrice: 49, includedCalls: 5000, overagePerCall: 0.012, recommendedFor: "One app or small client portal", features: ["Production API key", "Usage dashboard", "Shareable estimates", "Email support"] },
  { id: "growth", name: "Growth", monthlyPrice: 149, includedCalls: 25000, overagePerCall: 0.007, recommendedFor: "Agencies and multi-client products", features: ["Five project keys", "Entity comparisons", "Accounting connectors", "Priority support"] },
  { id: "platform", name: "Platform", monthlyPrice: 499, includedCalls: 100000, overagePerCall: 0.0035, recommendedFor: "Embedded fintech and SaaS", features: ["Unlimited project keys", "White-label portal", "OpenFisca adapter", "99.9% target SLA", "Implementation support"] },
  { id: "enterprise", name: "Enterprise", monthlyPrice: null, includedCalls: null, overagePerCall: null, recommendedFor: "High-volume or regulated deployments", features: ["Custom rules package", "Dedicated environment", "Security review", "Custom SLA", "Filing-provider integration"] }
];

export function calculateMonthlyApiCost(planId: PricingPlan["id"], calls: number) {
  const plan = PRICING_PLANS.find((p) => p.id === planId);
  if (!plan) throw new Error("Unknown plan");
  if (plan.monthlyPrice === null || plan.includedCalls === null) return { plan, calls, base: null, overage: null, total: null };
  const overageCalls = Math.max(0, calls - plan.includedCalls);
  const overage = plan.overagePerCall === null ? 0 : overageCalls * plan.overagePerCall;
  return { plan, calls, base: plan.monthlyPrice, overageCalls, overage: Math.round(overage * 100) / 100, total: Math.round((plan.monthlyPrice + overage) * 100) / 100 };
}
