import test from "node:test";
import assert from "node:assert/strict";
import { calculateEstimate, progressiveTax } from "./index.js";

test("2026 single bracket calculation", () => {
  assert.equal(progressiveTax(12400, "single"), 1240);
  assert.equal(progressiveTax(50400, "single"), 5800);
});

test("sole proprietor produces a reserve", () => {
  const result = calculateEstimate({ taxYear: 2026, entityType: "sole_proprietor", filingStatus: "single", grossRevenue: 200000, ordinaryExpenses: 80000, ownershipPercent: 100, ownerW2Wages: 0, otherW2Wages: 0, otherTaxableIncome: 0, aboveLineAdjustments: 0, itemizedDeductions: 0, qbiDeduction: 0, taxCredits: 0, federalWithholding: 0, estimatedPaymentsMade: 0, stateEffectiveRate: 0, partnershipSEIncomePercent: 100, reserveBufferRate: 0.05 });
  assert.ok(result.totalProjectedTax > 0);
  assert.equal(result.quarterlyPayments.length, 4);
});
