import type { EstimateInput, EstimateResult, EntityComparison, PricingPlan } from "@halo/tax-core";

export interface HaloTaxClientOptions { baseUrl: string; apiKey: string; projectId?: string }
export class HaloTaxClient {
  constructor(private options: HaloTaxClientOptions) {}
  private async request<T>(path: string, init?: RequestInit): Promise<T> {
    const response = await fetch(`${this.options.baseUrl.replace(/\/$/, "")}${path}`, {
      ...init,
      headers: { "content-type": "application/json", "x-halo-api-key": this.options.apiKey, "x-halo-project": this.options.projectId ?? "default", ...(init?.headers ?? {}) }
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.message ?? `HALO Tax API failed with ${response.status}`);
    return payload as T;
  }
  estimate(input: EstimateInput) { return this.request<{data: EstimateResult}>("/v1/estimates", { method: "POST", body: JSON.stringify(input) }); }
  compare(input: EstimateInput) { return this.request<{data: EntityComparison}>("/v1/scenarios/compare", { method: "POST", body: JSON.stringify(input) }); }
  pricing() { return this.request<{data: PricingPlan[]}>("/public/pricing"); }
  usage() { return this.request<{data: unknown}>("/v1/usage"); }
}
export type { EstimateInput, EstimateResult, EntityComparison } from "@halo/tax-core";
