CREATE TABLE IF NOT EXISTS halo_tax_usage (
  id bigserial PRIMARY KEY,
  api_key_hash text NOT NULL,
  project text NOT NULL,
  endpoint text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS halo_tax_usage_month_idx ON halo_tax_usage(api_key_hash, created_at);
CREATE TABLE IF NOT EXISTS halo_tax_leads (
  id bigserial PRIMARY KEY,
  name text,
  email text NOT NULL,
  company text,
  message text,
  created_at timestamptz NOT NULL DEFAULT now()
);
