# HALO Tax Platform

A complete Replit-ready business tax planning product with:

- Customer-facing live estimator
- Shareable estimate links
- Five-entity comparison
- Reusable TypeScript tax engine
- Fastify REST API and interactive Swagger docs
- TypeScript SDK for future HALO projects
- API-key authentication and usage metering
- Embedded commercial pricing schedule
- Optional PostgreSQL persistence
- Optional OpenFisca pass-through adapter
- Optional ERPNext accounting gateway connector

## Critical boundary

This is a **2026 U.S. federal planning model**, not a tax return engine and not e-file software. It intentionally does not model every deduction, credit, basis rule, limitation, election, state law or taxpayer circumstance. Have a CPA/tax attorney validate calculations and annually certify rule packs before commercial reliance.

## Run in Replit or locally

```bash
cp .env.example .env
npm install
npm run dev
```

Development:

- Customer portal: `http://localhost:5173`
- API: `http://localhost:3000`
- Swagger: `http://localhost:3000/docs`

Production preview:

```bash
npm run build
NODE_ENV=production npm start
```

The API then serves the customer portal and API from port 3000.

## Publish to a live Replit URL

1. Import this ZIP into a new Replit App.
2. Add values from `.env.example` under **Secrets**.
3. Run `npm install`, then `npm run dev` once.
4. Select **Publish** and use an **Autoscale Deployment** for a variable-traffic portal/API, or Reserved VM for continuous predictable capacity.
5. Replit will assign the public URL; the app, API and `/docs` will all use that domain.

A public URL cannot be created from this package without access to your Replit workspace, but no code changes are required after import.

## Private API example

```bash
curl -X POST https://YOUR-REPLIT-URL/v1/estimates   -H 'content-type: application/json'   -H 'x-halo-api-key: halo_test_key'   -H 'x-halo-project: halo-main'   -d '{
    "taxYear": 2026,
    "entityType": "s_corp",
    "filingStatus": "single",
    "grossRevenue": 425000,
    "ordinaryExpenses": 180000,
    "ownerW2Wages": 110000
  }'
```

## API routes

### Public customer routes

- `POST /public/estimate`
- `POST /public/compare`
- `GET /public/pricing`
- `GET /public/cost?plan=platform&calls=150000`
- `GET /public/rules/2026`
- `POST /public/leads`

### Private reusable API

- `POST /v1/estimates`
- `POST /v1/scenarios/compare`
- `GET /v1/usage`
- `POST /v1/openfisca/calculate`
- `POST /v1/integrations/erpnext/report`

## Rule updates

The 2026 parameters are isolated in `packages/tax-core/src/rules-2026.ts`. Add future years as separate immutable rule packs, test them, and select by `taxYear` rather than silently changing historical calculations.

## Licensing

HALO code in this repository is MIT. OpenFisca is not bundled; its optional adapter can call a separately deployed OpenFisca service. OpenFisca Core is AGPL-3.0-or-later, so review its license before modification or network deployment.
