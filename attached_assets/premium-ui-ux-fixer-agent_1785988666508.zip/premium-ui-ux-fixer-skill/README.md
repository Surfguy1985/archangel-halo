# Premium UI/UX + Experience + Architecture Fixer for Replit

This package turns Replit Agent into an elite design + experience + architecture agent.

It can now:

- Fix and elevate **visual design** (layout, spacing, typography, color, professional glows, micro-interactions)
- **Agentically improve the entire experience and user flows** by researching top industry products
- **Pull patterns from any design system repo or architectural repo** and adapt them into your project

Result: interfaces and flows that feel like Klarna, Stripe, Linear, or Apple — backed by real production patterns.

## Capabilities

| Layer | What the agent does |
|-------|---------------------|
| Visual | 8px grid, distinctive typography, soft brand glows, depth, consistency, accessibility |
| Experience | Analyzes best-in-class products → improves full user journeys, progressive disclosure, empty/loading states, primary actions |
| Architecture & Design Systems | Identifies high-quality open-source design system / component / architecture repos → extracts and adapts the best patterns into your codebase |

## How to Install

1. Download the zip.
2. In your Replit project, extract so you have:
   ```
   .agents/skills/premium-ui-ux-fixer/
   custom_instruction/
   ```
3. (Recommended) Add a short Design section to your root `replit.md` using the example provided.

## How to Use

Talk to Agent naturally:

**Visual + Polish**
- “Fix all the UI/UX problems and make the whole app feel premium”
- “Add proper professional glows and elevate the aesthetics”

**Experience & Flows**
- “Improve the entire experience and key user flows”
- “Pull from the best products in the industry and upgrade the whole journey”

**Design Systems & Architecture**
- “Pull patterns from the best design system repos and raise the component quality”
- “Use modern architecture patterns from high-quality open-source repos”
- “Adopt better composition patterns like the ones in shadcn / Radix / [any repo]”

Or simply:
- `/premium-ui-ux-fixer`

Agent will research, diagnose across all three layers, plan, implement, and summarize what was elevated and where the inspiration came from.

## Tips

- Point it at a specific repo if you already know a good one (“use patterns from [github.com/...]”).
- Start with the main user path for biggest impact.
- Say “run another pass focusing on flows + architecture” for deeper iterations.
- The agent adapts patterns to your existing stack and brand — it does not dump foreign code.

This skill is reusable across all your projects.