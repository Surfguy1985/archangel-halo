#!/usr/bin/env node
/**
 * node install.js                     print every template key
 * node install.js invoice             print one template document
 * node install.js invoice > b.json    extract a single board template
 * node install.js --all               stream all of them as a JSON array
 *
 * Each item in templates[].template is a complete board-template document ready
 * for instantiate_board_from_template(). Nothing needs unwrapping.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const bundle = JSON.parse(fs.readFileSync(path.join(HERE, 'halo-board-templates.json'), 'utf8'));
const byKey = Object.fromEntries(bundle.templates.map(t => [t.key, t]));
const arg = process.argv[2];

if (!arg) {
  console.log(bundle.name + ' v' + bundle.version + ' — ' + bundle.summary.template_count + ' templates, ' + bundle.summary.seeded_cards + ' cards\n');
  bundle.templates.forEach(t => {
    console.log(t.key.padEnd(24) + t.pipeline.length + ' cols · ' + String(t.counts.custom_fields).padStart(2) + ' fields · ' + t.counts.seeded_cards + ' cards   ' + t.pipeline.join(' → '));
  });
  console.log('\nnode install.js <key>   node install.js --all');
  process.exit(0);
}
if (arg === '--all') { console.log(JSON.stringify(bundle.templates.map(t => t.template), null, 2)); process.exit(0); }
if (!byKey[arg]) { console.error('No template "' + arg + '". Run without arguments to list them.'); process.exit(1); }
console.log(JSON.stringify(byKey[arg].template, null, 2));
