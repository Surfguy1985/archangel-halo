#!/usr/bin/env node
/**
 * node validate.js            validate every template in templates/
 * node validate.js invoice    validate one
 *
 * Dependency-free. Enforces exactly the constraints in
 * board-template.schema.json, plus the two integrity rules the schema can only
 * describe in prose:
 *   · every card label name must be declared in the top-level labels array
 *   · custom_field keys must be unique within a template
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HEX = /^#[0-9a-fA-F]{6}$/;
const KEY = /^[a-z0-9_]{1,60}$/;
const FIELD_TYPES = ['text','number','date','checkbox','select','multi_select','user'];
const PRIORITIES  = ['none','low','medium','high','urgent'];
const ROOT_KEYS   = ['description','settings','labels','custom_fields','columns'];
const COL_KEYS    = ['name','wip_limit','color','is_done_column','cards'];
const CARD_KEYS   = ['title','description','priority','labels','checklists'];

function validate(doc, name) {
  const e = [];
  const at = (p, m) => e.push(p + ': ' + m);

  if (typeof doc !== 'object' || doc === null || Array.isArray(doc)) return ['root: must be an object'];
  Object.keys(doc).forEach(k => { if (!ROOT_KEYS.includes(k)) at('root', 'additional property "' + k + '" is not allowed'); });
  if (!Array.isArray(doc.columns)) at('columns', 'is required and must be an array');

  if (doc.description !== undefined) {
    if (typeof doc.description !== 'string') at('description', 'must be a string');
    else if (doc.description.length > 2000) at('description', 'exceeds 2000 chars (' + doc.description.length + ')');
  }
  if (doc.settings !== undefined && (typeof doc.settings !== 'object' || doc.settings === null || Array.isArray(doc.settings)))
    at('settings', 'must be an object');

  const labelNames = new Set();
  if (doc.labels !== undefined) {
    if (!Array.isArray(doc.labels)) at('labels', 'must be an array');
    else {
      if (doc.labels.length > 50) at('labels', 'more than 50 entries');
      doc.labels.forEach((l, i) => {
        const p = 'labels[' + i + ']';
        if (typeof l !== 'object' || l === null) return at(p, 'must be an object');
        Object.keys(l).forEach(k => { if (!['name','color'].includes(k)) at(p, 'additional property "' + k + '"'); });
        if (typeof l.name !== 'string' || !l.name.length) at(p + '.name', 'required, 1-60 chars');
        else if (l.name.length > 60) at(p + '.name', 'exceeds 60 chars');
        else { if (labelNames.has(l.name)) at(p + '.name', 'duplicate label "' + l.name + '"'); labelNames.add(l.name); }
        if (l.color !== undefined && !HEX.test(l.color)) at(p + '.color', 'must match #rrggbb, got "' + l.color + '"');
      });
    }
  }

  if (doc.custom_fields !== undefined) {
    if (!Array.isArray(doc.custom_fields)) at('custom_fields', 'must be an array');
    else {
      if (doc.custom_fields.length > 50) at('custom_fields', 'more than 50 entries');
      const keys = new Set();
      doc.custom_fields.forEach((f, i) => {
        const p = 'custom_fields[' + i + ']';
        if (typeof f !== 'object' || f === null) return at(p, 'must be an object');
        Object.keys(f).forEach(k => { if (!['key','label','type','options'].includes(k)) at(p, 'additional property "' + k + '"'); });
        if (!KEY.test(f.key || '')) at(p + '.key', 'must match ^[a-z0-9_]{1,60}$, got "' + f.key + '"');
        else { if (keys.has(f.key)) at(p + '.key', 'duplicate key "' + f.key + '"'); keys.add(f.key); }
        if (typeof f.label !== 'string' || !f.label.length || f.label.length > 120) at(p + '.label', 'required, 1-120 chars');
        if (!FIELD_TYPES.includes(f.type)) at(p + '.type', 'must be one of ' + FIELD_TYPES.join(', '));
        const needsOptions = f.type === 'select' || f.type === 'multi_select';
        if (needsOptions) {
          if (!Array.isArray(f.options) || !f.options.length) at(p + '.options', 'required and non-empty for ' + f.type);
          else {
            if (f.options.length > 100) at(p + '.options', 'more than 100 options');
            if (new Set(f.options).size !== f.options.length) at(p + '.options', 'must be unique');
            f.options.forEach((o, j) => { if (typeof o !== 'string' || !o.length || o.length > 120) at(p + '.options[' + j + ']', '1-120 chars'); });
          }
        } else if (f.options !== undefined) at(p + '.options', 'only valid for select / multi_select');
      });
    }
  }

  if (Array.isArray(doc.columns)) {
    if (!doc.columns.length) at('columns', 'needs at least one column');
    if (doc.columns.length > 50) at('columns', 'more than 50 columns');
    doc.columns.forEach((c, i) => {
      const p = 'columns[' + i + ']';
      if (typeof c !== 'object' || c === null) return at(p, 'must be an object');
      Object.keys(c).forEach(k => { if (!COL_KEYS.includes(k)) at(p, 'additional property "' + k + '"'); });
      if (typeof c.name !== 'string' || !c.name.length || c.name.length > 120) at(p + '.name', 'required, 1-120 chars');
      if (c.wip_limit !== undefined && c.wip_limit !== null) {
        if (!Number.isInteger(c.wip_limit)) at(p + '.wip_limit', 'must be an integer or null');
        else if (c.wip_limit < 1) at(p + '.wip_limit', 'minimum 1');
      }
      if (c.color !== undefined && !HEX.test(c.color)) at(p + '.color', 'must match #rrggbb, got "' + c.color + '"');
      if (c.is_done_column !== undefined && typeof c.is_done_column !== 'boolean') at(p + '.is_done_column', 'must be boolean');
      if (c.cards !== undefined) {
        if (!Array.isArray(c.cards)) at(p + '.cards', 'must be an array');
        else {
          if (c.cards.length > 100) at(p + '.cards', 'more than 100 cards');
          c.cards.forEach((card, j) => {
            const q = p + '.cards[' + j + ']';
            if (typeof card !== 'object' || card === null) return at(q, 'must be an object');
            Object.keys(card).forEach(k => { if (!CARD_KEYS.includes(k)) at(q, 'additional property "' + k + '"'); });
            if (typeof card.title !== 'string' || !card.title.length) at(q + '.title', 'required, 1-500 chars');
            else if (card.title.length > 500) at(q + '.title', 'exceeds 500 chars');
            if (card.description !== undefined) {
              if (typeof card.description !== 'string') at(q + '.description', 'must be a string');
              else if (card.description.length > 20000) at(q + '.description', 'exceeds 20000 chars');
            }
            if (card.priority !== undefined && !PRIORITIES.includes(card.priority)) at(q + '.priority', 'must be one of ' + PRIORITIES.join(', '));
            if (card.labels !== undefined) {
              if (!Array.isArray(card.labels)) at(q + '.labels', 'must be an array');
              else {
                if (new Set(card.labels).size !== card.labels.length) at(q + '.labels', 'must be unique');
                card.labels.forEach(n => { if (!labelNames.has(n)) at(q + '.labels', 'label "' + n + '" is not declared in the top-level labels array'); });
              }
            }
            if (card.checklists !== undefined) {
              if (!Array.isArray(card.checklists)) at(q + '.checklists', 'must be an array');
              else {
                if (card.checklists.length > 20) at(q + '.checklists', 'more than 20 checklists');
                card.checklists.forEach((cl, m) => {
                  const r = q + '.checklists[' + m + ']';
                  Object.keys(cl).forEach(k => { if (!['title','items'].includes(k)) at(r, 'additional property "' + k + '"'); });
                  if (typeof cl.title !== 'string' || !cl.title.length || cl.title.length > 200) at(r + '.title', 'required, 1-200 chars');
                  if (!Array.isArray(cl.items) || !cl.items.length) at(r + '.items', 'required, at least one item');
                  else {
                    if (cl.items.length > 100) at(r + '.items', 'more than 100 items');
                    cl.items.forEach((it, n) => { if (typeof it !== 'string' || !it.length || it.length > 1000) at(r + '.items[' + n + ']', '1-1000 chars'); });
                  }
                });
              }
            }
          });
        }
      }
    });
  }
  return e;
}

const only = process.argv[2];
const tdir = path.join(HERE, 'templates');
const files = fs.readdirSync(tdir).filter(f => f.endsWith('.json')).filter(f => !only || f === only + '.json');
let bad = 0, cards = 0;
for (const f of files) {
  const doc = JSON.parse(fs.readFileSync(path.join(tdir, f), 'utf8'));
  const errs = validate(doc, f);
  cards += (doc.columns || []).reduce((a, c) => a + (c.cards || []).length, 0);
  if (errs.length) { bad++; console.log('✗ ' + f); errs.forEach(x => console.log('    ' + x)); }
  else console.log('✓ ' + f + '  ' + doc.columns.length + ' columns · ' + (doc.custom_fields || []).length + ' fields · ' + (doc.columns.reduce((a, c) => a + (c.cards || []).length, 0)) + ' cards');
}
console.log('\n' + files.length + ' templates, ' + cards + ' cards, ' + bad + ' invalid');
process.exit(bad ? 1 : 0);

export { validate };
