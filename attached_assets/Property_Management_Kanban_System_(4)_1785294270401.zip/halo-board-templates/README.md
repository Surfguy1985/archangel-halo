# Halo board templates

23 board templates for property operations, every one validating against
`board-template.schema.json` — the blueprint your `instantiate_board_from_template()`
consumes. No oklch, no custom card payloads, no properties the schema does not allow.

```bash
node validate.js            # validate all 23
node validate.js invoice    # validate one
```

**One file with everything:** `halo-board-templates.json` — all 23 board templates
embedded whole under `templates[].template`, each one a complete, standalone
document ready for `instantiate_board_from_template()` with no unwrapping. The
top level also carries the shared label vocabulary, the card anatomy contract and
the palette. `dist/halo-board-templates.min.json` is the same thing minified.

```bash
node install.js                  # list all 23 with their pipelines
node install.js invoice          # print one template document
node install.js invoice > b.json # extract a single board
node install.js --all            # stream all 23 as a JSON array
```

```
halo-board-templates.json    ALL 23 templates in one file
install.js                   list / extract from the bundle
board-template.schema.json   your schema, for local validation
validate.js                  dependency-free validator (schema + integrity rules)
palette.json                 every colour as #rrggbb, matched to the design system
index.json                   manifest
templates/daily_operations.json      the master board a manager lives in
templates/<service>.json             22 micro-service boards
```

---

## Two levels of board

**`daily_operations`** — the one board a manager works from. Columns are decision
lanes, not services: **Signal → Needs you → In motion → Blocked → Verify → Settled**.
Every micro-service card surfaces here. `card_type` and `service_board` route each
card to its detail board. WIP limits sit on the three columns that actually clog:
Needs you 8, Blocked 5, Verify 6.

**22 service boards** — one per micro-service, where columns *are* that service's
pipeline (Invoices: Received → Coded → Approved → Scheduled → Paid). This is the
part a generic Kanban gets wrong: an invoice does not move through "In progress",
it moves through *coded* and *approved*.

| Board | Columns | Fields | Primary action |
| --- | --- | --- | --- |
| work_order | Reported → Dispatched → On Site → Parts Hold → QC → Closed | 16 | dispatch a tech |
| make_ready | Vacated → Scoped → Trades → Punch → Inspected → Rent Ready | 16 | release for re-inspection |
| invoice | Received → Coded → Approved → Scheduled → Paid | 19 | approve the invoice |
| payment_run | Assembling → Manager OK → Owner OK → Funded → Sent | 21 | release the run |
| vendor_crew_live | Dispatched → En Route → On Site → Wrapping → Signed Off | 27 | sign off the job |
| change_order | Submitted → Priced → Manager OK → Owner OK → Merged | 18 | approve the change |
| coi_compliance | Requested → Received → Verified → On File → Expiring | 19 | request a renewal |
| supply_order | Drafted → Approved → Ordered → Shipped → Received | 18 | issue the PO |
| dispatch | Draft → Balanced → Published → Running → Reconciled | 18 | auto-balance the route |
| virtual_key | Issued → Active → Used → Expired → Revoked | 19 | extend or revoke |
| resident_thread | New → Read → Replied → Resolved → Surveyed | 18 | send the suggested reply |
| occupancy_exposure | Live → Weekly → Monthly → Trailing → Forecast | 19 | prioritise the gap units |
| tour_lead | Inquiry → Contacted → Toured → Applied → Leased | 23 | confirm the tour and hold |
| lease_renewal | Eligible → Offered → Negotiating → Signed → Declined | 22 | send the offer |
| delinquency | 1-10d → 11-30d → 31-60d → Notice served → Filed | 22 | serve the notice |
| move_out_inspection | Scheduled → Walked → Priced → Statement → Refunded | 21 | generate the statement |
| budget_variance | Live → Flagged → Reforecast → Approved → Closed | 20 | send the reforecast |
| preventive_maintenance | Scheduled → Due → Assigned → Serviced → Logged | 21 | book the service |
| code_violation | Notice received → Assessed → Curing → Re-inspection → Cleared | 21 | dispatch and file the packet |
| promo_concession | Drafted → Live → Converting → Ending → Closed | 22 | extend or end |
| tech_bonus_payroll | Accruing → Reviewed → Approved → Paid → Logged | 22 | approve the bonus |
| after_hours_emergency | Called in → Escalated → Dispatched → Made safe → Reported | 20 | escalate the ladder |

---

## The uniform card

Every card in every board renders on the same **340 × 430** frame with the same
nine regions in the same order at the same heights. Nothing grows because it has
more to say — it summarises harder. `preview/Card System.dc.html` shows the
anatomy and all 22 side by side.

| # | Region | Height | Bound to |
| --- | --- | --- | --- |
| 1 | SLA rail | 3px | computed from `sla_due` ÷ `sla_target_minutes` |
| 2 | Identity row | 30px | card code · `card.priority` · `column.name` |
| 3 | Title | 42px | `card.title`, clamped to two lines |
| 4 | Context | 24px | `unit` + first line of `card.description` |
| 5 | Metric triad | 70px | `settings.card_anatomy.primary_metrics` — exactly three custom fields |
| 6 | Evidence | 130px | `settings.card_anatomy.evidence` — checklist, photo pair, crew roster or thread |
| 7 | Labels | 26px | `card.labels` |
| 8 | Decision bar | 36px | `settings.primary_action` / `settings.secondary_action` |
| 9 | Footer | 38px | assignee · `sla_due` · export |

Every template carries this contract in `settings.card_anatomy`, and
`validate.js` checks that each of the three metric keys is a declared custom
field — so a card can never bind to a field the board does not have.

### The metric triad

Three numbers, chosen per service. It is the hardest edit in the system and the
reason the cards are readable: *which three figures does this decision turn on?*

| Board | The three |
| --- | --- |
| work_order | SLA remaining · percent complete · occurrences in 30 days |
| make_ready | lost rent to date · trade sequence % · punch items open |
| invoice | amount total · amount approved · amount held |
| payment_run | run total · discount captured · disputed |
| vendor_crew_live | crew on property · percent complete · findings open |
| change_order | delta · revised amount · crew idle cost per hour |
| coi_compliance | workers comp status · GL expiry · jobs at risk |
| supply_order | order total · days of cover · emergency run cost |
| dispatch | unassigned stops · capacity used · after-hours cost if it slips |
| virtual_key | token · taps of cap · denied attempts |
| resident_thread | minutes unanswered · sentiment · review risk |
| occupancy_exposure | occupancy · 90-day forecast · gap units |
| tour_lead | conversion score · hold expiry · competing leads |
| lease_renewal | renewal probability · annual gain · turn cost if lost |
| delinquency | balance · days past due · eviction all-in |
| move_out_inspection | damage charged · refund due · statement due |
| budget_variance | percent consumed · unencumbered · variance |
| preventive_maintenance | failure risk · service cost · failure cost |
| code_violation | fine per day · cure cost remaining · evidence items filed |
| promo_concession | units redeemed · cost per incremental lease · concession spent |
| tech_bonus_payroll | bonus earned · bonus forfeited · progress to next tier |
| after_hours_emergency | escalates at · tech ETA · ladder stage |

### Colour is derived, never authored

A card declares no colours. It takes `settings.accent_color` and derives every
surface from it: card background at 7% on white, border 20%, rail track 22%,
unit chip 16%, footer 11%, hairlines 12%. Eight category hues, one lightness.
Urgency is carried by the rail, the priority chip and the alert labels — never
by re-colouring a card.

---

## How each design module maps onto the schema

The schema gives a card exactly five properties: `title`, `description`,
`priority`, `labels`, `checklists`. There is no place for custom-field *values*.
So the design puts the decision in the title, the numbers in a fixed
`description` layout, the work in checklists, and the state in labels and priority.

| Card module in the design | How it lands in the schema |
| --- | --- |
| SLA clock / heat bar | `sla_due` + `sla_target_minutes` fields; `settings.heat_source` tells the renderer to compute the bar from them. Overdue also gets the **Overdue** label and `priority: urgent`. |
| Money (amount + state split) | `amount_total`, `amount_approved`, `amount_pending`, `amount_held`, `due_date` — plus a **Snapshot** line in the description. |
| Decision economics (A vs B) | a **Decision** paragraph naming both options and their costs, backed by paired number fields (`service_cost` / `failure_cost`, `eviction_all_in_cost` / `plan_monthly`). |
| Checklist | a `checklists` entry. FLAGGED items are written in caps inside the item text. |
| Crew findings | a `checklists` entry titled *Crew findings — escalate to maintenance*, one item per finding prefixed HIGH / MED / LOW, with unit, reporter, time and photo count. `findings_open` and `findings_escalated` carry the counts. |
| Crew roster with clock in/out and GPS | `crew_on_property`, `clock_in_first`, `clock_out_last`, `crew_hours_billable`, `assigned_units`, `geofence_status`, `gps_last_ping` — and a **Crew on property** block in the description, one line per member. |
| Photo pairs | `before_photos` / `after_photos` counts, the **Photo required** label, and a sign-off checklist item that blocks completion. |
| Progress bar | `percent_complete`. |
| Probability / risk score | a single number field (`renewal_probability`, `failure_risk_percent`, `conversion_score`). |
| Comparison bars | one number field per row, named for the row. |
| Documents with expiry | one field per document status (`gl_expires`, `wc_status`, `w9_on_file`) plus a *Documents required* checklist. |
| Credential panel | `credential_token`, `holder_name`, `valid_from`, `valid_until`, `doors_granted`, `tap_count`. |
| Message thread | `suggested_reply`, `sentiment`, `minutes_unanswered`, plus a **Thread** block in the description. |
| Event log | a `checklists` entry (access log, payment behaviour, escalation ladder) — chronological, one item per event. |
| Approve / deny buttons | `settings.primary_action` and `settings.secondary_action` hold the action ids; the **Decision** paragraph states what each one does. |
| Auto-generated report | `job_report_ready` checkbox + `job_report_url`. |
| Smart stack | `linked_cards` plus a **Linked** block in the description. |
| Stage automations | `settings.automations_on_enter` — a map of column name to the automation ids that fire when a card enters it. |

### The description layout, on every card

```
{one line of context — unit, source, reference numbers}

**Snapshot**
- the three to six numbers that drive the decision

**Decision**
what the primary action does, what the secondary does, and any gate

**Fires on {action}**
- the automations that run downstream

**Linked**
- related card ids
```

Consistent across all 44 seeded cards, so a manager reads one card and can read
every card.

### Labels

An identical 18-label vocabulary on every board, so cards stay legible when they
move between boards: eight service categories, then **Sev 1**, **Overdue**,
**At risk**, **Blocked**, **Waiting on vendor**, **Auto-generated**,
**Owner approval**, **Resident-facing**, **Photo required**, **Escalated**.

Colour means category. Urgency is carried by `priority`, the heat bar and the
alert labels — never by re-colouring the card.

### Priority

| `priority` | Used for |
| --- | --- |
| `urgent` | life safety, SLA already breached, money leaving today, a crew going idle |
| `high` | a decision that must happen this shift |
| `medium` | this week |
| `low` | standing metrics and long-horizon items |
| `none` | reference cards |

---

## Adding a service board

1. Copy the closest `templates/<service>.json`.
2. Set `settings.board_name`, `template_key`, `category`, `accent_color` from `palette.json`.
3. Replace `columns` with that service's real pipeline. Mark the last column `is_done_column`.
4. Keep the eight core custom fields; add the ones that drive *this* decision.
5. Put WIP limits only where work genuinely piles up.
6. `node validate.js <key>`.
