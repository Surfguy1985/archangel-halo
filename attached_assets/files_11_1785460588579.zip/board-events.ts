/**
 * board-events.ts — SSE hub + transactional outbox for board events.
 *
 * NOTE ON SCOPE: the uploaded zip contains the frontend and libs only, so this
 * file is a reference implementation written against Express (the typical
 * Replit backend for this stack) and node-postgres/Drizzle-compatible SQL.
 * The wire format matches the hardened openapi.yaml (`BoardEvent` schema and
 * the two `/board/events` paths) exactly — adapt the two marked seams
 * (`resolvePropertyIdForToken`, `db.query`) to your server and everything the
 * frontend expects will hold.
 *
 * WHY AN OUTBOX, NOT INLINE EMITS
 * If the API handler writes the card and then emits the event, a crash or
 * disconnect between the two produces a card the client never hears about —
 * which presents as "the board is flaky" and is unfindable in logs. Instead:
 *
 *   1. The mutation writes the card AND an event row in the SAME transaction.
 *   2. A single publisher tails the table and fans out to SSE + the existing
 *      outbound webhook.
 *
 * A commit therefore guarantees a notification, eventually. At-least-once:
 * consumers refetch on event, so duplicates are harmless.
 */

import type { Request, Response } from 'express';

// ---------------------------------------------------------------------------
// Types — mirror #/components/schemas/BoardEvent
// ---------------------------------------------------------------------------

export type BoardEventName =
  | 'card_pushed'
  | 'card_moved'
  | 'card_action'
  | 'card_commented'
  | 'card_removed'
  | 'inbox_raised'
  | 'inbox_responded';

export interface BoardEvent {
  event: BoardEventName;
  propertyId: string;
  cardId?: string | null;
  cardKey?: string | null;
  actor?: 'client' | 'office' | 'crew' | 'system' | null;
  at: string; // ISO
}

// ---------------------------------------------------------------------------
// Outbox table (run once; Drizzle users: mirror in schema.ts)
// ---------------------------------------------------------------------------

export const OUTBOX_DDL = `
CREATE TABLE IF NOT EXISTS board_events (
  id           BIGSERIAL PRIMARY KEY,
  property_id  TEXT NOT NULL,
  event        TEXT NOT NULL,
  card_id      TEXT,
  card_key     TEXT,
  actor        TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS board_events_unpublished
  ON board_events (id) WHERE published_at IS NULL;
CREATE INDEX IF NOT EXISTS board_events_property
  ON board_events (property_id, id DESC);
`;

/**
 * Call INSIDE the same transaction as the card mutation.
 *
 *   await tx.execute(insertBoardEventSQL, [propertyId, 'card_moved', cardId, cardKey, 'client']);
 */
export const insertBoardEventSQL = `
INSERT INTO board_events (property_id, event, card_id, card_key, actor)
VALUES ($1, $2, $3, $4, $5)
`;

// ---------------------------------------------------------------------------
// SSE hub — per-property channels, heartbeats, bounded fan-out
// ---------------------------------------------------------------------------

const HEARTBEAT_MS = 25_000; // under common 30s proxy idle timeouts
const MAX_SUBSCRIBERS_PER_PROPERTY = 50;

interface Subscriber {
  res: Response;
  heartbeat: ReturnType<typeof setInterval>;
}

const channels = new Map<string, Set<Subscriber>>();

function subscribe(propertyId: string, res: Response): () => void {
  let set = channels.get(propertyId);
  if (!set) {
    set = new Set();
    channels.set(propertyId, set);
  }
  if (set.size >= MAX_SUBSCRIBERS_PER_PROPERTY) {
    // Refuse rather than let one property exhaust connections for everyone.
    res.status(503).end();
    return () => {};
  }

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no', // nginx/replit proxy: do not buffer the stream
  });
  res.write(`retry: 3000\n\n`);

  const sub: Subscriber = {
    res,
    heartbeat: setInterval(() => {
      // Comment frame — keeps proxies from idling the connection out.
      res.write(`: hb ${Date.now()}\n\n`);
    }, HEARTBEAT_MS),
  };
  set.add(sub);

  return () => {
    clearInterval(sub.heartbeat);
    set!.delete(sub);
    if (set!.size === 0) channels.delete(propertyId);
  };
}

function fanOut(evt: BoardEvent & { id: number }) {
  const set = channels.get(evt.propertyId);
  if (!set) return;
  const frame =
    `id: ${evt.id}\n` +
    `event: board\n` +
    `data: ${JSON.stringify({
      event: evt.event,
      propertyId: evt.propertyId,
      cardId: evt.cardId ?? null,
      cardKey: evt.cardKey ?? null,
      actor: evt.actor ?? null,
      at: evt.at,
    })}\n\n`;
  for (const sub of set) {
    try {
      sub.res.write(frame);
    } catch {
      /* connection died; its close handler will unsubscribe */
    }
  }
}

// ---------------------------------------------------------------------------
// Publisher — tails the outbox. One instance per server process.
// ---------------------------------------------------------------------------

export interface Db {
  query: (sql: string, params?: unknown[]) => Promise<{ rows: any[] }>;
}

const POLL_MS = 500; // fast enough to feel instant, cheap on the partial index

export function startBoardEventPublisher(db: Db): () => void {
  let running = true;

  (async () => {
    while (running) {
      try {
        // Claim-and-mark in one statement so a second process (or a restart
        // mid-batch) never double-claims. SKIP LOCKED keeps publishers from
        // serializing on each other.
        const { rows } = await db.query(`
          UPDATE board_events SET published_at = now()
          WHERE id IN (
            SELECT id FROM board_events
            WHERE published_at IS NULL
            ORDER BY id
            LIMIT 100
            FOR UPDATE SKIP LOCKED
          )
          RETURNING id, property_id, event, card_id, card_key, actor, created_at
        `);
        for (const r of rows) {
          fanOut({
            id: Number(r.id),
            event: r.event,
            propertyId: r.property_id,
            cardId: r.card_id,
            cardKey: r.card_key,
            actor: r.actor,
            at: new Date(r.created_at).toISOString(),
          });
          // Seam: this is also where the existing outbound webhook mirror
          // should be triggered, so SSE and webhook can never disagree about
          // what happened. Queue it; do not await it inline.
        }
        await sleep(rows.length === 100 ? 0 : POLL_MS); // drain bursts immediately
      } catch (err) {
        console.error('[board-events] publisher error:', err);
        await sleep(2_000);
      }
    }
  })();

  return () => {
    running = false;
  };
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// Route handlers — mount these two
// ---------------------------------------------------------------------------

/** GET /api/admin/accounts/:propertyId/board/events  (behind requireAdmin) */
export function officeBoardEventsHandler(req: Request, res: Response) {
  const { propertyId } = req.params;
  const unsubscribe = subscribe(propertyId, res);
  req.on('close', unsubscribe);
}

/**
 * GET /api/client/:token/board/events
 * Seam: swap in your real token->property lookup (same one the feed uses).
 */
export function clientBoardEventsHandler(
  resolvePropertyIdForToken: (token: string) => Promise<string | null>,
) {
  return async (req: Request, res: Response) => {
    const propertyId = await resolvePropertyIdForToken(req.params.token);
    if (!propertyId) {
      res.status(404).json({ error: 'Invalid link' });
      return;
    }
    const unsubscribe = subscribe(propertyId, res);
    req.on('close', unsubscribe);
  };
}
