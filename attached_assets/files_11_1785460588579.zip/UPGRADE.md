# HALO Kanban Hardening Pack — UPGRADE GUIDE

Fixes every board-layer issue from the audit, in dependency order. Files in
this pack mirror your repo layout — copy each over the matching path, then
apply the three small find-and-replace patches below (given as exact
old/new blocks against your current source).

**What's fixed**

| # | Issue | Fix |
|---|---|---|
| 1 | Enums living in prose descriptions → orval emits `string` | `openapi.yaml`: real `enum`s for `kind`, `column` |
| 2 | `module: additionalProperties: true` → `unknown` everywhere | `openapi.yaml`: `ClientCardModule` oneOf + discriminator (11 module schemas, fields audited from your renderers) |
| 3 | Action god-object (7 fields, mostly nullable) | `openapi.yaml`: 5-way discriminated union — **same wire JSON**, server keeps working |
| 4 | Stale/contradictory kind lists across 4 places | one canonical enum; `flag`→`flags` legacy mismatch documented in-spec instead of ambient |
| 5 | SSE endpoint absent from the contract | both `/board/events` paths specced, `BoardEvent` schema |
| 6 | Client board on 15s polling while office gets SSE | client SSE path + shared `useBoardEvents` hook (reconnect, backoff, catch-up, visibility pause) |
| 7 | Lost events between commit and emit | `server/board-events.ts` — transactional outbox + publisher |
| 8 | PM/Vendor template key collision (`unit_turnover`, `blank`) | `templates.ts` — audience-aware `resolveTemplate`, stored keys untouched, boot-time duplicate guard |
| 9 | Malformed/unknown module payloads render blank or crash | `moduleSchemas.ts` + `ModuleBoundary.tsx` — validate, degrade gracefully, error-boundary per card |
| 10 | Token-in-URL on a payment surface | `server/session-auth.ts` — one-time exchange → httpOnly cookie, zero-breakage migration, log-redaction snippet |
| 11 | No `securitySchemes`; nothing rate limited | schemes in spec + `security` on all 33 admin ops; `server/rate-limit.ts` presets for pay/action/login/session/bank |

**What this pack deliberately does NOT do:** rewrite `BoardCardModules.tsx`
or introduce the module-registry kernel. This is the hardening of what exists;
the kernel migration stays a separate step so you can ship this first.

**Honest scope note:** the zip contains frontend + libs only, so the three
`server/` files are reference implementations (Express + Postgres, the usual
Replit shape). Wire formats match the spec exactly; each has its two
integration seams marked `// Seam:`.

---

## Step 0 — Copy files

```
lib/api-spec/openapi.yaml                                → replace (validated: 261 paths, 389 schemas, YAML-parses clean)
lib/board-ui/src/components/apple-board/templates.ts     → replace (your arrays byte-identical; resolver appended)
lib/board-ui/src/components/kanban/moduleSchemas.ts      → new
lib/board-ui/src/components/kanban/ModuleBoundary.tsx    → new
lib/board-ui/src/hooks/useBoardEvents.ts                 → new
server/board-events.ts                                   → new (adapt seams)
server/session-auth.ts                                   → new (adapt seams)
server/rate-limit.ts                                     → new
```

`lib/board-ui` needs `zod` (it's already in your workspace catalog):

```jsonc
// lib/board-ui/package.json → dependencies
"zod": "catalog:"
```

And export the new modules — append to `lib/board-ui/src/index.ts`:

```ts
export * from './components/kanban/moduleSchemas';
export * from './components/kanban/ModuleBoundary';
export * from './hooks/useBoardEvents';
```

## Step 1 — Regenerate the client

```bash
pnpm --filter @workspace/api-spec exec orval --config orval.config.ts
pnpm typecheck
```

Expect new compile errors — **that's the pack working.** Every place that
treated `kind`/`column` as arbitrary strings or reached into `module` untyped
now has to say what it means. Two you'll hit immediately:

- anywhere comparing `card.kind` to a typo'd string → now an error
- action call sites building the old flat object → still valid JSON on the
  wire, but narrow them as you touch them (`satisfies` the generated union)

## Step 2 — Patch AppleCard.tsx (template collision)

**2a.** Replace line 2:

```ts
// OLD
import { APPLE_CATEGORY_COLORS, PM_TEMPLATES, VENDOR_TEMPLATES } from './templates';
// NEW
import { APPLE_CATEGORY_COLORS, resolveTemplate, type BoardAudience } from './templates';
```

**2b.** In `AppleCardProps`, after `token?: string;` add:

```ts
  audience?: BoardAudience;
```

and add `audience` to the destructuring in the `AppleCard(...)` signature.

**2c.** Replace the lookup:

```ts
// OLD
  // Find template across both PM and Vendor
  let template = PM_TEMPLATES.find(t => t.key === card.template) 
              || VENDOR_TEMPLATES.find(t => t.key === card.template);
// NEW
  // Resolve against the viewer's own catalog first — `unit_turnover` and
  // `blank` exist in both PM and Vendor with different styling.
  let template = resolveTemplate(card.template, audience);
```

## Step 3 — Patch AppleBoard.tsx (pass the audience)

In the `<AppleCard` call (~line 418), after `token={token}` add:

```tsx
                      audience={isPm ? 'pm' : 'vendor'}
```

## Step 4 — Patch ClientBoardOffice.tsx (typed, resilient SSE)

Add to imports:

```ts
import { useBoardEvents } from "@workspace/board-ui";
```

Replace this exact block (~line 1810):

```ts
  useEffect(() => {
    if (!propertyId) return;
    // Manual /api URLs must be absolute — never BASE_URL-prefixed.
    const es = new EventSource(`/api/admin/accounts/${propertyId}/board/events`);
    const refetch = () => {
      queryClient.invalidateQueries({ queryKey: getGetOfficeClientBoardQueryKey(propertyId!) });
      queryClient.invalidateQueries({ queryKey: getGetOfficeBoardFullQueryKey(propertyId!) });
      queryClient.invalidateQueries({ queryKey: getGetClientBoardInboxQueryKey(propertyId!) });
    };
    es.addEventListener("board", refetch);
    // On reconnect after a drop, catch up on anything missed.
    es.onopen = refetch;
    return () => es.close();
  }, [propertyId, queryClient]);
```

with:

```ts
  // Live push with reconnect/backoff/catch-up; 15s poll remains the fallback.
  useBoardEvents(
    propertyId ? `/api/admin/accounts/${propertyId}/board/events` : null,
    () => {
      queryClient.invalidateQueries({ queryKey: getGetOfficeClientBoardQueryKey(propertyId!) });
      queryClient.invalidateQueries({ queryKey: getGetOfficeBoardFullQueryKey(propertyId!) });
      queryClient.invalidateQueries({ queryKey: getGetClientBoardInboxQueryKey(propertyId!) });
    },
  );
```

(If `useEffect` becomes unused in that file's imports, remove it from the
import list.)

## Step 5 — Wrap the module renderers (graceful degradation)

In `AppleCard.tsx`, wrap the three module surfaces (~lines 181–186):

```tsx
import { ModuleBoundary } from '../kanban/ModuleBoundary';

<ModuleBoundary module={card.module} surface="metrics" links={card.links}>
  <ModuleMetrics module={card.module} tint={{ bd: '#f5f5f7' }} />
</ModuleBoundary>
<ModuleBoundary module={card.module} surface="evidence">
  <ModuleEvidence module={card.module} tint={{ bg: '#fafafa', border: '#e8e8ed', hairline: '#e8e8ed', bd: '#e8e8ed' }} />
</ModuleBoundary>
<ModuleBoundary module={card.module} surface="decision">
  <ModuleDecision cardKey={card.cardKey} token={token} module={card.module} readOnly={!!readOnly} onReadOnlyClick={onReadOnlyClick} tint={{ bd: '#e8e8ed' }} />
</ModuleBoundary>
```

Nothing inside `BoardCardModules.tsx` changes; valid payloads render pixel-
identical. What changes: an unknown module type shows an "update available"
face instead of nothing, a malformed payload logs loudly instead of silently
half-rendering, and a renderer crash takes out one card strip instead of the
board.

## Step 6 — Server wiring (the three reference files)

```ts
// bootstrap
import { OUTBOX_DDL, startBoardEventPublisher, officeBoardEventsHandler, clientBoardEventsHandler } from './server/board-events';
import { clientSessionExchangeHandler, clientAuth } from './server/session-auth';
import { limits } from './server/rate-limit';

await db.query(OUTBOX_DDL);
startBoardEventPublisher(db);

app.get('/api/admin/accounts/:propertyId/board/events', requireAdmin, officeBoardEventsHandler);
app.get('/api/client/:token/board/events', clientBoardEventsHandler(resolvePropertyIdForToken));
app.post('/api/client/:token/session', limits.session, clientSessionExchangeHandler(resolvePropertyIdForToken));

app.use('/api/client/:token', clientAuth(resolvePropertyIdForToken));
app.post('/api/client/:token/board/login', limits.login, /* existing handler */);
app.post('/api/client/:token/board/cards/:cardId/action', limits.cardAction, /* existing handler */);
app.use('/api/pay/:token', limits.pay);
```

Then in every board mutation handler (push, lane move, action, comment,
remove, inbox respond), inside the existing transaction:

```ts
await tx.query(insertBoardEventSQL, [propertyId, 'card_moved', cardId, cardKey, 'client']);
```

Client board bootstrap (one line, starts the token→cookie migration):

```ts
useEffect(() => {
  fetch(`/api/client/${token}/session`, { method: 'POST', credentials: 'include' }).catch(() => {});
}, [token]);
```

And add client-side live sync next to the existing query:

```ts
useBoardEvents(`/api/client/${token}/board/events`, () =>
  queryClient.invalidateQueries({ queryKey: getGetClientBoardFeedQueryKey(token) }),
);
```

## Step 7 — Verify (the triple-check, on your machine)

```bash
pnpm typecheck                     # must be green before shipping
```

Runtime checklist:

1. Office pushes a card → client board updates in ~1s without a manual reload
   (watch the Network tab: one `board` SSE frame, then the refetch).
2. Kill the server for 10s with both boards open → both show reconnect
   behavior, then catch up on resume (the backoff means no request storm).
3. Drag a vendor-board `unit_turnover` card → paintbrush icon + vendor
   styling (previously PM's).
4. `curl -X POST .../board/login` 6 times fast → 6th returns 429.
5. After the session exchange lands: request logs show `<redacted>` where the
   token was; DevTools shows `halo_client_session` httpOnly cookie.
6. Push a card with a made-up module type from a REST client → client shows
   the "update available" face, console clean, board alive.

---

### What was validated before packaging

- Patched `openapi.yaml` parses clean (PyYAML): 261 paths, 389 schemas;
  `ClientCardModule` = 11-way discriminated oneOf; `ClientCardActionInput` =
  5-way; `BoardColumn` enum; `security` present on 33/33 admin operations.
- Module schema fields were extracted from your actual renderers
  (`BoardCardModules.tsx`) field-by-field, not guessed — every property each
  branch reads is in its schema; `.passthrough()` covers anything the server
  adds later.
- All old-code blocks in Steps 2–4 are byte-exact matches against your
  uploaded source, so find-and-replace will hit first try.
- TS files typecheck standalone (strict mode; externals stubbed).
